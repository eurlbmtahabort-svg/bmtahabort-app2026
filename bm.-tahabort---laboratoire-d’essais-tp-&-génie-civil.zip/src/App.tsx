import React, { useState, useEffect } from 'react';
import { 
  Project, 
  Client, 
  Chantier, 
  Sample, 
  LabTest, 
  ConcreteFormulation, 
  CompressionPV, 
  LabReport, 
  UserRole 
} from './types';
import { dataService } from './services/dataService';
import { saveExportFile } from './utils/fileExportUtils';
import { Navbar } from './components/Navbar';
import { Sidebar, NavTab } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { ProjectsView } from './components/ProjectsView';
import { ClientsView } from './components/ClientsView';
import { ChantiersView } from './components/ChantiersView';
import { SamplesView } from './components/SamplesView';
import { TestsView } from './components/TestsView';
import { FormulationView } from './components/FormulationView';
import { CompressionPVView } from './components/CompressionPVView';
import { Tracking14DaysWidget } from './components/Tracking14DaysWidget';
import { ReportsView } from './components/ReportsView';
import { StatisticsView } from './components/StatisticsView';
import { HistoryView } from './components/HistoryView';
import { SettingsView } from './components/SettingsView';

export default function App() {
  // Navigation & View State
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentRole, setCurrentRole] = useState<UserRole>('DIRECTEUR');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedPV, setSelectedPV] = useState<CompressionPV | null>(null);

  // Quick Action Triggers
  const [quickCreateAction, setQuickCreateAction] = useState<string | null>(null);

  // Core Data loaded from dataService
  const [projects, setProjects] = useState<Project[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [chantiers, setChantiers] = useState<Chantier[]>([]);
  const [samples, setSamples] = useState<Sample[]>([]);
  const [tests, setTests] = useState<LabTest[]>([]);
  const [formulations, setFormulations] = useState<ConcreteFormulation[]>([]);
  const [compressionPVs, setCompressionPVs] = useState<CompressionPV[]>([]);
  const [reports, setReports] = useState<LabReport[]>([]);
  const [activityLogs, setActivityLogs] = useState(dataService.getActivityLogs());
  const [settings, setSettings] = useState(dataService.getSettings());

  // Reload all data from service
  const reloadData = () => {
    setProjects(dataService.getProjects());
    setClients(dataService.getClients());
    setChantiers(dataService.getChantiers());
    setSamples(dataService.getSamples());
    setTests(dataService.getTests());
    setFormulations(dataService.getFormulations());
    setCompressionPVs(dataService.getCompressionPVs());
    setReports(dataService.getReports());
    setActivityLogs(dataService.getActivityLogs());
    setSettings(dataService.getSettings());
  };

  useEffect(() => {
    reloadData();
  }, []);

  // Quick action from dashboard or sidebar
  const handleQuickAction = (action: 'project' | 'formulation' | 'pv' | 'test' | 'report') => {
    setQuickCreateAction(action);
    if (action === 'project') setActiveTab('projects');
    else if (action === 'formulation') setActiveTab('formulations');
    else if (action === 'pv') setActiveTab('compression_pvs');
    else if (action === 'test') setActiveTab('tests');
    else if (action === 'report') setActiveTab('reports');
  };

  // Direct navigation from 14-day widget
  const handleSelectProjectFromTracking = (project: Project) => {
    setSelectedProject(project);
    setActiveTab('projects');
  };

  const handleSelectPVFromTracking = (pv: CompressionPV) => {
    setSelectedPV(pv);
    setActiveTab('compression_pvs');
  };

  // CRUD Handlers
  const handleSaveProject = (p: Project) => {
    dataService.saveProject(p);
    reloadData();
  };

  const handleDeleteProject = (id: string) => {
    dataService.deleteProject(id);
    reloadData();
  };

  const handleSaveClient = (c: Client) => {
    dataService.saveClient(c);
    reloadData();
  };

  const handleDeleteClient = (id: string) => {
    dataService.deleteClient(id);
    reloadData();
  };

  const handleSaveChantier = (ch: Chantier) => {
    dataService.saveChantier(ch);
    reloadData();
  };

  const handleDeleteChantier = (id: string) => {
    dataService.deleteChantier(id);
    reloadData();
  };

  const handleSaveSample = (s: Sample) => {
    dataService.saveSample(s);
    reloadData();
  };

  const handleDeleteSample = (id: string) => {
    dataService.deleteSample(id);
    reloadData();
  };

  const handleSaveTest = (t: LabTest) => {
    dataService.saveTest(t);
    reloadData();
  };

  const handleDeleteTest = (id: string) => {
    dataService.deleteTest(id);
    reloadData();
  };

  const handleSaveFormulation = (f: ConcreteFormulation) => {
    dataService.saveFormulation(f);
    reloadData();
  };

  const handleDuplicateFormulation = (id: string) => {
    dataService.duplicateFormulation(id);
    reloadData();
  };

  const handleDeleteFormulation = (id: string) => {
    dataService.deleteFormulation(id);
    reloadData();
  };

  const handleSaveCompressionPV = (pv: CompressionPV) => {
    dataService.saveCompressionPV(pv);
    reloadData();
  };

  const handleDeleteCompressionPV = (id: string) => {
    dataService.deleteCompressionPV(id);
    reloadData();
  };

  const handleSaveReport = (r: LabReport) => {
    dataService.saveReport(r);
    reloadData();
  };

  const handleDeleteReport = (id: string) => {
    dataService.deleteReport(id);
    reloadData();
  };

  const handleSaveSettings = (newSettings: any) => {
    dataService.saveSettings(newSettings);
    reloadData();
  };

  const handleResetDemoData = () => {
    dataService.resetToDemoData();
    reloadData();
    alert('Les données de démonstration du laboratoire BM. TAHABORT ont été réinitialisées avec succès.');
  };

  const handleExportBackup = async () => {
    try {
      const { backupJson, summary } = dataService.compileFullLocalStorageBackup();
      const filename = `bmtahabort_sauvegarde_complete_${summary.date}.json`;
      const res = await saveExportFile(backupJson, filename, 'application/json');
      return {
        success: res.success,
        message: res.success
          ? `Sauvegarde complète exportée avec succès (${summary.totalRecords} enregistrements : ${summary.projects} projets, ${summary.compressionPVs} PV d'écrasement, ${summary.formulations} formulations, ${summary.tests} essais).`
          : res.message,
        summary
      };
    } catch (err: any) {
      console.error('handleExportBackup error:', err);
      return {
        success: false,
        message: "Échec de l'exportation de la sauvegarde : " + (err?.message || 'Erreur inconnue')
      };
    }
  };

  const handleImportBackup = (jsonStr: string) => {
    const ok = dataService.importDatabaseJson(jsonStr);
    if (ok) {
      reloadData();
      return true;
    }
    return false;
  };

  const alerts14DCount = projects.filter(
    p => p.tracking14Days && p.tracking14Days.enabled && p.status === 'EN_COURS'
  ).length;
  const isDemoData = dataService.isDemoDataActive();
  const currentUser = dataService.getCurrentUser();
  const availableUsers = dataService.getUsers();

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-900">
      {/* Top Navigation Bar */}
      <Navbar
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        projects={projects}
        compressionPVs={compressionPVs}
        currentUser={currentUser}
        availableUsers={availableUsers}
        onSelectUser={u => {
          dataService.setCurrentUser(u.id);
          reloadData();
        }}
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        onNavigate={tab => {
          setActiveTab(tab);
          setSelectedProject(null);
          setSelectedPV(null);
        }}
        active14DayAlertsCount={alerts14DCount}
        onNavigateTo14Days={() => setActiveTab('tracking_14d')}
        isDemoData={isDemoData}
        onClearDemoData={handleResetDemoData}
        onRestoreDemoData={handleResetDemoData}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={tab => {
            setActiveTab(tab);
            setSelectedProject(null);
            setSelectedPV(null);
          }}
          isOpenMobile={sidebarOpen}
          onCloseMobile={() => setSidebarOpen(false)}
          counts={{
            projects: projects.length,
            clients: clients.length,
            chantiers: chantiers.length,
            samples: samples.length,
            tests: tests.length,
            formulations: formulations.length,
            compressionPVs: compressionPVs.length,
            pvs: compressionPVs.length,
            reports: reports.length,
            alerts14D: alerts14DCount
          }}
          onQuickAction={handleQuickAction}
        />

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-3 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && (
              <Dashboard
                projects={projects}
                clients={clients}
                chantiers={chantiers}
                tests={tests}
                formulations={formulations}
                compressionPVs={compressionPVs}
                reports={reports}
                activityLogs={activityLogs}
                onNavigate={setActiveTab}
                onQuickAction={handleQuickAction}
                onSelectProject={handleSelectProjectFromTracking}
                onSelectPV={handleSelectPVFromTracking}
              />
            )}

            {activeTab === 'projects' && (
              <ProjectsView
                projects={projects}
                clients={clients}
                chantiers={chantiers}
                onSaveProject={handleSaveProject}
                onDeleteProject={handleDeleteProject}
                getNextProjectNumber={() => dataService.getNextProjectNumber()}
                initialCreateTrigger={quickCreateAction === 'project'}
                onResetCreateTrigger={() => setQuickCreateAction(null)}
                selectedProject={selectedProject}
                onClearSelectedProject={() => setSelectedProject(null)}
              />
            )}

            {activeTab === 'clients' && (
              <ClientsView
                clients={clients}
                onSaveClient={handleSaveClient}
                onDeleteClient={handleDeleteClient}
              />
            )}

            {activeTab === 'chantiers' && (
              <ChantiersView
                chantiers={chantiers}
                clients={clients}
                projects={projects}
                onSaveChantier={handleSaveChantier}
                onDeleteChantier={handleDeleteChantier}
              />
            )}

            {activeTab === 'samples' && (
              <SamplesView
                samples={samples}
                projects={projects}
                clients={clients}
                chantiers={chantiers}
                settings={settings}
                onSaveSample={handleSaveSample}
                onDeleteSample={handleDeleteSample}
                getNextSampleNumber={() => dataService.getNextSampleNumber()}
              />
            )}

            {activeTab === 'tests' && (
              <TestsView
                tests={tests}
                projects={projects}
                clients={clients}
                chantiers={chantiers}
                settings={settings}
                onSaveTest={handleSaveTest}
                onDeleteTest={handleDeleteTest}
                getNextTestNumber={() => dataService.getNextTestNumber()}
                initialCreateTrigger={quickCreateAction === 'test'}
                onResetCreateTrigger={() => setQuickCreateAction(null)}
              />
            )}

            {activeTab === 'formulations' && (
              <FormulationView
                formulations={formulations}
                projects={projects}
                clients={clients}
                chantiers={chantiers}
                settings={settings}
                onSave={handleSaveFormulation}
                onDuplicate={handleDuplicateFormulation}
                onDelete={handleDeleteFormulation}
                getNextNumber={() => dataService.getNextFormulationNumber()}
                initialCreateTrigger={quickCreateAction === 'formulation'}
                onResetCreateTrigger={() => setQuickCreateAction(null)}
              />
            )}

            {activeTab === 'compression_pvs' && (
              <CompressionPVView
                pvs={compressionPVs}
                projects={projects}
                clients={clients}
                chantiers={chantiers}
                samples={samples}
                settings={settings}
                onSave={handleSaveCompressionPV}
                onDelete={handleDeleteCompressionPV}
                getNextNumber={() => dataService.getNextPVNumber()}
                initialCreateTrigger={quickCreateAction === 'pv'}
                onResetCreateTrigger={() => setQuickCreateAction(null)}
              />
            )}

            {activeTab === 'tracking_14d' && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
                    Suivi Métrologique des Échéances d’Essais (7j, 14j, 28j)
                  </h2>
                  <p className="text-xs text-slate-500">
                    Vue consolidée et alertes automatiques sur les trois échéances normalisées de contrôle de résistance du béton.
                  </p>
                </div>
                <Tracking14DaysWidget
                  projects={projects}
                  compressionPVs={compressionPVs}
                  onSelectProject={handleSelectProjectFromTracking}
                  onSelectPV={handleSelectPVFromTracking}
                  isFullView={true}
                />
              </div>
            )}

            {activeTab === 'reports' && (
              <ReportsView
                reports={reports}
                projects={projects}
                clients={clients}
                settings={settings}
                onSaveReport={handleSaveReport}
                onDeleteReport={handleDeleteReport}
                getNextReportNumber={() => dataService.getNextReportNumber()}
                initialCreateTrigger={quickCreateAction === 'report'}
                onResetCreateTrigger={() => setQuickCreateAction(null)}
              />
            )}

            {activeTab === 'statistics' && (
              <StatisticsView
                projects={projects}
                tests={tests}
                formulations={formulations}
                compressionPVs={compressionPVs}
              />
            )}

            {activeTab === 'history' && (
              <HistoryView logs={activityLogs} />
            )}

            {activeTab === 'settings' && (
              <SettingsView
                settings={settings}
                onSaveSettings={handleSaveSettings}
                onResetDemoData={handleResetDemoData}
                onExportBackup={handleExportBackup}
                onImportBackup={handleImportBackup}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

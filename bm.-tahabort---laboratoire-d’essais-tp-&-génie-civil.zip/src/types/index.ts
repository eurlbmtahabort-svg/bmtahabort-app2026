export type UserRole = 'ADMIN' | 'LAB_MANAGER' | 'TECHNICIAN' | 'VIEWER';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  title: string;
  active: boolean;
}

export type ProjectStatus = 'NOUVEAU' | 'EN_COURS' | 'SUSPENDU' | 'TERMINE' | 'ARCHIVE';

export interface Tracking14Days {
  enabled: boolean;
  startDate: string; // YYYY-MM-DD
  targetDurationDays: number; // default 14
  notes?: string;
}

export interface Client {
  id: string;
  code?: string;
  name: string;
  type: 'ENTREPRISE' | 'MAITRE_OUVRAGE' | 'BUREAU_ETUDES' | 'PARTICULIER' | 'AUTRE';
  address: string;
  wilaya: string;
  commune?: string;
  phone: string;
  email: string;
  nif?: string; // Numéro d'Identification Fiscale
  nis?: string; // Numéro d'Identification Statistique
  rc?: string;  // Registre de Commerce
  contactPerson: string;
  notes?: string;
  createdAt: string;
}

export interface Chantier {
  id: string;
  code?: string;
  name: string;
  projectId?: string;
  projectName?: string;
  clientId?: string;
  clientName?: string;
  wilaya: string;
  commune?: string;
  location?: string;
  locationDescription?: string;
  entreprise?: string;
  maitreOuvrage?: string;
  maitreOeuvre?: string;
  supervisor?: string;
  contactPerson?: string;
  status?: string;
  description?: string;
  observations?: string;
  notes?: string;
  createdAt: string;
}

export interface Project {
  id: string;
  projectNumber: string;
  name: string;
  clientId: string;
  clientName: string;
  maitreOuvrage?: string;
  maitreOeuvre?: string;
  entreprise?: string;
  bureauEtudes?: string;
  chantierId?: string;
  chantierName?: string;
  wilaya: string;
  commune?: string;
  address?: string;
  startDate: string;
  endDate?: string;
  description: string;
  observations?: string;
  status: ProjectStatus;
  tracking14Days: Tracking14Days;
  createdAt: string;
}

export type MaterialCategory =
  | 'BETON'
  | 'CIMENT'
  | 'GRANULATS'
  | 'SABLE'
  | 'SOL'
  | 'GRAVE'
  | 'TOUT_VENANT'
  | 'ENROBE'
  | 'MATERIAUX_ROUTIERS'
  | 'ACIER'
  | 'AUTRE';

export interface Sample {
  id: string;
  sampleNumber: string;
  projectId: string;
  projectName?: string;
  chantierId?: string;
  chantierName?: string;
  clientId: string;
  clientName?: string;
  materialCategory?: MaterialCategory;
  materialType?: string;
  customMaterialName?: string;
  samplingDate: string;
  receptionDate?: string;
  samplingLocation: string;
  samplerName?: string;
  sampledBy?: string;
  quantity?: string;
  ambientTempC?: number;
  conservationConditions?: string;
  conditionOnReception?: 'CONFORME' | 'NON_CONFORME' | 'ALTERE' | 'ACCEPTE_AVEC_RESERVE';
  status?: string;
  observations?: string;
  createdAt: string;
}

export type TestStatus = 'EN_ATTENTE' | 'EN_COURS' | 'TERMINE' | 'VALIDE' | 'REJETE' | 'CONFORME' | 'NON_CONFORME';

export interface LabTest {
  id: string;
  testNumber: string;
  projectId: string;
  projectName?: string;
  clientId?: string;
  clientName?: string;
  chantierId?: string;
  chantierName?: string;
  sampleId?: string;
  sampleNumber?: string;
  category?: string;
  materialCategory?: MaterialCategory;
  testType: string;
  standardRef: string;
  testDate?: string;
  dateRealized?: string;
  operator: string;
  equipmentUsed?: string;
  measurementsSummary?: string;
  resultValue?: number;
  resultUnit?: string;
  complianceObservation?: string;
  results?: Record<string, string | number>;
  units?: Record<string, string>;
  observations?: string;
  conclusion: string;
  status: TestStatus;
  createdAt: string;
}

export interface FormulationConstituent {
  id: string;
  name: string;
  type: 'CIMENT' | 'EAU' | 'SABLE' | 'GRAVILLON_1' | 'GRAVILLON_2' | 'ADJUVANT' | 'AUTRE';
  designation: string;
  quantityKg: number; // For 1 m³
  densityKgPerM3?: number;
  costDzdPerKg?: number;
}

export interface FormulationCustomSection {
  id: string;
  title: string;
  category: 'MATERIAUX' | 'GRANULOMETRIE' | 'GACHEE_ESSAI' | 'RESISTANCE' | 'AUTRE';
  content: string;
  measurements?: Array<{ label: string; value: string | number; unit?: string }>;
  dateRealized?: string;
  technician?: string;
}

export interface ConcreteFormulation {
  id: string;
  formulationNumber: string;
  projectId: string;
  projectName?: string;
  chantierId?: string;
  chantierName?: string;
  clientId: string;
  clientName?: string;
  date: string;
  concreteType: string; // e.g. Béton armé, Béton précontraint, Béton de propreté, etc.
  strengthClass: string; // e.g. C25/30, C30/37, C20/25, C35/45
  consistency: string; // S1 (ferme), S2 (plastique), S3 (très plastique), S4 (fluide), S5 (très fluide)
  dMaxMm: number; // Diamètre maximal des granulats (ex: 15, 20, 25 mm)
  cementType: string; // ex: CEM II/A-L 42.5 N, CPJ-CEM II/A 42.5
  cementSource?: string;
  sandSource?: string;
  sandType?: string;
  sandEquivalentEs?: number;
  gravelSource?: string;
  waterSource?: string;
  adjuvantType?: string;
  adjuvantBrand?: string;
  adjuvantDosageKg: number;
  waterLiter: number;
  cementDosageKg: number;
  wcRatio: number; // Water / Cement ratio (E/C)
  sandKg: number;
  gravel1Kg: number;
  gravel2Kg?: number;
  otherConstituents?: FormulationConstituent[];
  theoreticalDensityKgM3: number;
  theoreticalVolumeM3: number;

  // Dreux-Gorisse & Bolomey specifics
  bolomeyCoeffG?: number;
  targetAirPercent?: number;
  granulometryCurvesSummary?: string;
  
  // Validation / Test comparisons (7j, 14j, 28j treated with equal status)
  targetSlumpMm: number;
  measuredSlumpMm?: number;
  freshConcreteDensityKgM3?: number;
  targetStrength7jMpa?: number;
  measuredStrength7jMpa?: number;
  targetStrength14jMpa?: number;
  measuredStrength14jMpa?: number;
  targetStrength28jMpa?: number;
  measuredStrength28jMpa?: number;
  
  // Multi-section dossier pages & experiments
  customSections?: FormulationCustomSection[];

  status?: string;
  observations?: string;
  preparedBy: string;
  approvedBy?: string;
  directorName?: string;
  technicianName?: string;
  createdAt: string;
}

export type SpecimenType =
  | 'CYLINDRIQUE_16_32' // S = 201.06 cm² (20106 mm²)
  | 'CYLINDRIQUE_11_22' // S = 100.29 cm² (10029 mm²)
  | 'CUBIQUE_15_15'     // S = 225 cm² (22500 mm²)
  | 'CUBIQUE_10_10'     // S = 100 cm² (10000 mm²)
  | 'AUTRE';

export interface CompressionSpecimen {
  id: string;
  index: number;
  ageDays: number; // e.g. 7, 14, 28
  dimensionsDescription: string;
  diameterMm?: number;
  heightMm?: number;
  sideMm?: number;
  massG?: number;
  maxLoadKn: number; // Charge maximale F (kN)
  areaMm2: number; // Surface S (mm²)
  strengthMpa: number; // Résistance fc = (F * 1000) / S (MPa)
  failureMode: string; // e.g. Normal (cône), Semi-pyramidal, Cisaillement, etc.
  observations?: string;
}

export interface CompressionPV {
  id: string;
  pvNumber: string;
  projectId: string;
  projectName?: string;
  chantierId?: string;
  chantierName?: string;
  clientId: string;
  clientName?: string;
  sampleId?: string;
  sampleNumber: string;
  samplingDate: string;
  receptionDate: string;
  confectionDate: string;
  crushingDate: string;
  concreteAgeDays: number; // 7, 14, 28, etc. Independent PV per age!
  concreteClass: string;
  specimenType: SpecimenType;
  customDimensions?: string;
  machineUsed: string; // e.g. Presse hydraulique 2000 kN étalonnée
  operator: string;
  directorName?: string;
  technicianName?: string;
  specimens: CompressionSpecimen[];
  averageStrengthMpa: number;
  standardDeviationMpa?: number;
  targetStrengthMpa?: number;
  complianceObservation?: string;
  observations?: string;
  conclusion: string;
  status: 'BROUILLON' | 'VALIDE';
  validatedBy?: string;
  createdAt: string;
}

export interface LabReport {
  id: string;
  reportNumber: string;
  title: string;
  type: string;
  entityId?: string;
  projectId: string;
  projectName?: string;
  chantierId?: string;
  chantierName?: string;
  clientId?: string;
  clientName?: string;
  sampleId?: string;
  sampleNumber?: string;
  testId?: string;
  testNumber?: string;
  pvId?: string;
  pvNumber?: string;
  concreteAgeDays?: number;
  date: string;
  author?: string;
  preparedBy?: string;
  verifiedBy?: string;
  approvedBy?: string;
  directorName?: string;
  technicianName?: string;
  qualityManagerName?: string;
  summary?: string;
  contentSummary?: string;
  resultsSummary?: string;
  observations?: string;
  conclusion: string;
  status: string;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  date: string;
  user: string;
  userRole?: string;
  action: string;
  documentType: string;
  documentNumber: string;
  projectId?: string;
  description: string;
}

export interface LabSettings {
  companyName: string;
  laboratorySubtitle?: string;
  activitySubtitle?: string;
  address: string;
  wilaya?: string;
  phone: string;
  email: string;
  nif: string;
  rc: string;
  nis?: string;
  directorName?: string;
  technicianName?: string;
  qualityManagerName?: string;
  defaultUnits?: {
    load: string;
    strength: string;
    mass: string;
    dimensions: string;
  };
  numberingPrefixes?: {
    project: string;
    client: string;
    chantier: string;
    sample: string;
    test: string;
    formulation: string;
    pvCompression: string;
    report: string;
  };
  tracking14DayDefaultDays?: number;
  target14DaysDuration?: number;
  enable14DaysNotification?: boolean;
  language?: 'fr' | 'ar' | 'en';
}

export type LaboratorySettings = LabSettings;

import React from 'react';
import {
  LayoutDashboard,
  FolderKanban,
  Users,
  HardHat,
  Boxes,
  FlaskConical,
  Beaker,
  FileCheck2,
  FileText,
  History,
  BarChart3,
  Settings,
  ClockAlert,
  PlusCircle
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'projects'
  | 'clients'
  | 'chantiers'
  | 'samples'
  | 'tests'
  | 'formulations'
  | 'compression_pvs'
  | 'reports'
  | 'tracking_14d'
  | 'history'
  | 'statistics'
  | 'settings';

export interface SidebarCounts {
  projects?: number;
  clients?: number;
  chantiers?: number;
  samples?: number;
  tests?: number;
  formulations?: number;
  compressionPVs?: number;
  pvs?: number;
  reports?: number;
  alerts14D?: number;
}

export interface SidebarProps {
  currentTab?: NavTab;
  activeTab?: NavTab;
  onSelectTab?: (tab: NavTab) => void;
  onTabChange?: (tab: NavTab) => void;
  counts?: SidebarCounts;
  isMobileOpen?: boolean;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
  onOpenQuickCreate?: () => void;
  onQuickAction?: (action: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  activeTab,
  onSelectTab,
  onTabChange,
  counts,
  isMobileOpen = false,
  isOpenMobile = false,
  onCloseMobile,
  onOpenQuickCreate,
  onQuickAction
}) => {
  const safeCounts: SidebarCounts = counts || {};
  const effectiveTab = activeTab || currentTab || 'dashboard';
  const handleSelectTab = (tab: NavTab) => {
    if (onSelectTab) onSelectTab(tab);
    if (onTabChange) onTabChange(tab);
  };
  const effectiveMobileOpen = isOpenMobile || isMobileOpen;

  const handleQuickCreate = () => {
    if (onOpenQuickCreate) onOpenQuickCreate();
    else if (onQuickAction) onQuickAction('project');
    if (onCloseMobile) onCloseMobile();
  };

  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'Tableau de bord',
      icon: LayoutDashboard,
      section: 'principal'
    },
    {
      id: 'projects' as NavTab,
      label: 'Projets',
      icon: FolderKanban,
      count: safeCounts.projects ?? 0,
      section: 'principal'
    },
    {
      id: 'clients' as NavTab,
      label: 'Clients',
      icon: Users,
      count: safeCounts.clients ?? 0,
      section: 'principal'
    },
    {
      id: 'chantiers' as NavTab,
      label: 'Chantiers',
      icon: HardHat,
      count: safeCounts.chantiers ?? 0,
      section: 'principal'
    },
    {
      id: 'samples' as NavTab,
      label: 'Échantillons',
      icon: Boxes,
      count: safeCounts.samples ?? 0,
      section: 'laboratoire'
    },
    {
      id: 'tests' as NavTab,
      label: 'Essais',
      icon: FlaskConical,
      count: safeCounts.tests ?? 0,
      section: 'laboratoire'
    },
    {
      id: 'formulations' as NavTab,
      label: 'Formulations',
      icon: Beaker,
      count: safeCounts.formulations ?? 0,
      section: 'laboratoire'
    },
    {
      id: 'compression_pvs' as NavTab,
      label: 'PV d’écrasement',
      icon: FileCheck2,
      count: safeCounts.compressionPVs ?? safeCounts.pvs ?? 0,
      section: 'laboratoire'
    },
    {
      id: 'reports' as NavTab,
      label: 'Rapports',
      icon: FileText,
      count: safeCounts.reports ?? 0,
      section: 'laboratoire'
    },
    {
      id: 'tracking_14d' as NavTab,
      label: 'Échéances 7, 14, 28j',
      icon: ClockAlert,
      badge: (safeCounts.alerts14D ?? 0) > 0 ? `${safeCounts.alerts14D}` : undefined,
      badgeColor: (safeCounts.alerts14D ?? 0) > 0 ? 'bg-amber-500 text-slate-950 font-bold' : undefined,
      section: 'suivi'
    },
    {
      id: 'history' as NavTab,
      label: 'Historique',
      icon: History,
      section: 'suivi'
    },
    {
      id: 'statistics' as NavTab,
      label: 'Statistiques',
      icon: BarChart3,
      section: 'suivi'
    },
    {
      id: 'settings' as NavTab,
      label: 'Paramètres',
      icon: Settings,
      section: 'systeme'
    }
  ];

  const renderSectionHeader = (title: string) => (
    <div className="px-3 pt-3 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
      {title}
    </div>
  );

  return (
    <>
      {/* Mobile Backdrop */}
      {effectiveMobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs md:hidden"
        />
      )}

      {/* Navigation Container */}
      <aside
        className={`fixed md:sticky top-0 md:top-[61px] bottom-0 left-0 z-50 md:z-20 w-64 bg-slate-900 text-slate-200 flex flex-col border-r border-slate-800 transition-transform duration-200 ease-in-out h-full md:h-[calc(100vh-61px)] ${
          effectiveMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        } no-print`}
      >
        {/* Mobile Header */}
        <div className="md:hidden p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-tech font-bold text-emerald-400">BM. TAHABORT</span>
            <span className="text-xs text-slate-400">Menu</span>
          </div>
          <button
            onClick={onCloseMobile}
            className="p-1 rounded text-slate-400 hover:text-white cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Quick Create Action Button */}
        <div className="p-3 border-b border-slate-800">
          <button
            onClick={handleQuickCreate}
            className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Nouveau Document / Essai</span>
          </button>
        </div>

        {/* Navigation Items List */}
        <nav className="flex-1 overflow-y-auto px-2 py-2 space-y-0.5 custom-scrollbar">
          {renderSectionHeader('Opérations Générales')}
          {navItems
            .filter(item => item.section === 'principal')
            .map(item => {
              const Icon = item.icon;
              const isActive = effectiveTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    handleSelectTab(item.id);
                    if (effectiveMobileOpen && onCloseMobile) onCloseMobile();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-emerald-700 text-white font-semibold shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {typeof item.count === 'number' && (
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                        isActive
                          ? 'bg-emerald-900/80 text-emerald-100'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}

          {renderSectionHeader('Laboratoire & Essais')}
          {navItems
            .filter(item => item.section === 'laboratoire')
            .map(item => {
              const Icon = item.icon;
              const isActive = effectiveTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    handleSelectTab(item.id);
                    if (effectiveMobileOpen && onCloseMobile) onCloseMobile();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-emerald-700 text-white font-semibold shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {typeof item.count === 'number' && (
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                        isActive
                          ? 'bg-emerald-900/80 text-emerald-100'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}

          {renderSectionHeader('Contrôle & Qualité')}
          {navItems
            .filter(item => item.section === 'suivi')
            .map(item => {
              const Icon = item.icon;
              const isActive = effectiveTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    handleSelectTab(item.id);
                    if (effectiveMobileOpen && onCloseMobile) onCloseMobile();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-emerald-700 text-white font-semibold shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] ${item.badgeColor || 'bg-slate-800 text-slate-400'}`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}

          {renderSectionHeader('Administration')}
          {navItems
            .filter(item => item.section === 'systeme')
            .map(item => {
              const Icon = item.icon;
              const isActive = effectiveTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    handleSelectTab(item.id);
                    if (effectiveMobileOpen && onCloseMobile) onCloseMobile();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-emerald-700 text-white font-semibold shadow-xs'
                      : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                </button>
              );
            })}
        </nav>

        {/* Footer info in sidebar */}
        <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 flex flex-col gap-1 bg-slate-950/50">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-300">BM. TAHABORT</span>
            <span className="text-[10px] text-emerald-400 font-mono">v1.0.0</span>
          </div>
          <p className="text-[10px] text-slate-500">
            Laboratoire Travaux Publics & Génie Civil
          </p>
        </div>
      </aside>
    </>
  );
};

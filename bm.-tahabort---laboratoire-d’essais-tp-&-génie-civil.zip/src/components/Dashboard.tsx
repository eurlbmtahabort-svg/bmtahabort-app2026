import React from 'react';
import {
  FolderKanban,
  FlaskConical,
  Beaker,
  FileCheck2,
  FileText,
  ClockAlert,
  Plus,
  ArrowUpRight,
  TrendingUp,
  Activity,
  HardHat,
  Users
} from 'lucide-react';
import { 
  Project, 
  Client, 
  Chantier, 
  LabTest, 
  ConcreteFormulation, 
  CompressionPV, 
  LabReport, 
  ActivityLog 
} from '../types';
import { Tracking14DaysWidget } from './Tracking14DaysWidget';
import { NavTab } from './Sidebar';

interface DashboardProps {
  projects: Project[];
  clients: Client[];
  chantiers: Chantier[];
  tests: LabTest[];
  formulations: ConcreteFormulation[];
  compressionPVs: CompressionPV[];
  reports: LabReport[];
  activityLogs: ActivityLog[];
  onNavigate: (tab: NavTab) => void;
  onQuickAction: (action: 'project' | 'formulation' | 'pv' | 'test' | 'report') => void;
  onSelectProject: (project: Project) => void;
  onSelectPV: (pv: CompressionPV) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  projects,
  clients,
  chantiers,
  tests,
  formulations,
  compressionPVs,
  reports,
  activityLogs,
  onNavigate,
  onQuickAction,
  onSelectProject,
  onSelectPV
}) => {
  // Compute metric numbers
  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === 'EN_COURS').length;
  const completedProjects = projects.filter(p => p.status === 'TERMINE').length;

  const totalTests = tests.length;
  const testsPending = tests.filter(t => t.status === 'EN_ATTENTE' || t.status === 'EN_COURS').length;
  const testsValidated = tests.filter(t => t.status === 'VALIDE' || t.status === 'TERMINE').length;

  const totalFormulations = formulations.length;
  const totalCompressionPVs = compressionPVs.length;
  const totalReports = reports.length;

  const statCards = [
    {
      label: 'Projets Totaux',
      value: totalProjects,
      subtext: `${activeProjects} en cours • ${completedProjects} terminés`,
      icon: FolderKanban,
      color: 'emerald',
      onClick: () => onNavigate('projects')
    },
    {
      label: 'Essais de Laboratoire',
      value: totalTests,
      subtext: `${testsValidated} réalisés • ${testsPending} en attente`,
      icon: FlaskConical,
      color: 'blue',
      onClick: () => onNavigate('tests')
    },
    {
      label: 'Formulations de Béton',
      value: totalFormulations,
      subtext: 'Études granulaires & E/C',
      icon: Beaker,
      color: 'teal',
      onClick: () => onNavigate('formulations')
    },
    {
      label: 'PV d’Écrasement',
      value: totalCompressionPVs,
      subtext: 'Essais 7j, 14j et 28j normalisés',
      icon: FileCheck2,
      color: 'indigo',
      onClick: () => onNavigate('compression_pvs')
    },
    {
      label: 'Rapports & PV Générés',
      value: totalReports,
      subtext: 'Documents officiels émis',
      icon: FileText,
      color: 'slate',
      onClick: () => onNavigate('reports')
    },
    {
      label: 'Chantiers Suivis',
      value: chantiers.length,
      subtext: `${clients.length} clients enregistrés`,
      icon: HardHat,
      color: 'amber',
      onClick: () => onNavigate('chantiers')
    }
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Welcome Banner with Quick Actions */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-5 sm:p-6 border border-slate-700 shadow-md">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Génie Civil & Travaux Publics
              </span>
              <span className="text-xs text-slate-400">Algérie</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-tech text-white">
              BM. TAHABORT • Laboratoire d’Essais
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
              Plateforme intégrée de gestion des essais mécaniques, formulations de béton,
              procès-verbaux d'écrasement et contrôle de conformité des matériaux.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onQuickAction('project')}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Nouveau Projet</span>
            </button>

            <button
              onClick={() => onQuickAction('formulation')}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-teal-400" />
              <span>Nouvelle Formulation</span>
            </button>

            <button
              onClick={() => onQuickAction('pv')}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-amber-400" />
              <span>Nouveau PV d’Écrasement</span>
            </button>

            <button
              onClick={() => onQuickAction('test')}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-blue-400" />
              <span>Nouvel Essai</span>
            </button>

            <button
              onClick={() => onQuickAction('report')}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-slate-300" />
              <span>Nouveau Rapport</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Statistics Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {statCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <div
              key={idx}
              onClick={card.onClick}
              className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md hover:border-slate-300 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  {card.label}
                </span>
                <div className="p-1.5 rounded-lg bg-slate-100 text-slate-700 group-hover:bg-emerald-100 group-hover:text-emerald-800 transition-colors">
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3">
                <div className="text-2xl font-bold text-slate-900 font-tech">
                  {card.value}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                  {card.subtext}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 14-Day Requirement Highlight Section */}
      <Tracking14DaysWidget
        projects={projects}
        compressionPVs={compressionPVs}
        onSelectProject={onSelectProject}
        onSelectPV={onSelectPV}
      />

      {/* Two Column Layout: Recent Projects & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Projects Table */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4 sm:p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <FolderKanban className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-sm font-tech">
                  Projets Récents en Cours
                </h3>
              </div>
              <button
                onClick={() => onNavigate('projects')}
                className="text-xs text-emerald-700 hover:text-emerald-800 font-medium flex items-center gap-1 cursor-pointer"
              >
                <span>Voir tous ({projects.length})</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {projects.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                Aucun projet enregistré. Créez un nouveau projet pour démarrer.
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {projects.slice(0, 5).map(p => (
                  <div
                    key={p.id}
                    onClick={() => onSelectProject(p)}
                    className="py-2.5 px-2 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer flex items-center justify-between gap-2"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-900">
                          {p.projectNumber}
                        </span>
                        <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                          p.status === 'EN_COURS'
                            ? 'bg-emerald-100 text-emerald-800'
                            : p.status === 'TERMINE'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {p.status}
                        </span>
                      </div>
                      <p className="text-xs font-medium text-slate-800 truncate max-w-xs mt-0.5">
                        {p.name}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Client : {p.clientName} • Wilaya : {p.wilaya}
                      </p>
                    </div>

                    <div className="text-right text-[11px] text-slate-400">
                      {p.startDate}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 mt-2 border-t border-slate-100">
            <button
              onClick={() => onQuickAction('project')}
              className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-600" />
              <span>Créer un nouveau projet</span>
            </button>
          </div>
        </div>

        {/* Recent Laboratory Activity Log */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4 sm:p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-sm font-tech">
                  Journal d’Activité Récent
                </h3>
              </div>
              <button
                onClick={() => onNavigate('history')}
                className="text-xs text-blue-700 hover:text-blue-800 font-medium flex items-center gap-1 cursor-pointer"
              >
                <span>Historique complet</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {activityLogs.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                Aucune activité récente.
              </div>
            ) : (
              <div className="space-y-3">
                {activityLogs.slice(0, 5).map(log => (
                  <div key={log.id} className="flex items-start gap-2.5 text-xs">
                    <div className="w-2 h-2 rounded-full bg-emerald-600 mt-1.5 flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-semibold text-slate-800">
                          {log.action}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {log.date}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        {log.description}
                      </p>
                      <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                        <span className="font-mono bg-slate-100 px-1 rounded">
                          {log.documentNumber}
                        </span>
                        <span>Par {log.user}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 mt-2 border-t border-slate-100">
            <button
              onClick={() => onNavigate('history')}
              className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Consulter l'historique complet d'audit</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

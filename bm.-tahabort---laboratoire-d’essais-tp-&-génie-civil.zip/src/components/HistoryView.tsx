import React, { useState } from 'react';
import {
  History,
  Search,
  Filter,
  ShieldCheck,
  User,
  Calendar,
  FileText
} from 'lucide-react';
import { ActivityLog } from '../types';

interface HistoryViewProps {
  logs: ActivityLog[];
}

export const HistoryView: React.FC<HistoryViewProps> = ({ logs }) => {
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('ALL');

  const filtered = logs.filter(log => {
    const q = search.toLowerCase();
    const matchSearch =
      log.description.toLowerCase().includes(q) ||
      log.user.toLowerCase().includes(q) ||
      (log.documentNumber && log.documentNumber.toLowerCase().includes(q)) ||
      log.action.toLowerCase().includes(q);

    if (actionFilter === 'ALL') return matchSearch;
    return matchSearch && log.action.includes(actionFilter);
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Journal d'Audit & Traçabilité des Actions
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-semibold">
              {logs.length} événements enregistrés
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Historique inaltérable des créations, modifications, approbations et impressions de documents d'essais.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher dans l'historique..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
            />
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            {['ALL', 'CREATION', 'MODIFICATION', 'DUPLICATION', 'IMPRESSION'].map(act => (
              <button
                key={act}
                onClick={() => setActionFilter(act)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                  actionFilter === act
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {act === 'ALL' ? 'Tous' : act}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            Aucun événement d'audit ne correspond à vos critères.
          </div>
        ) : (
          <>
            {/* Mobile View: Cards */}
            <div className="md:hidden divide-y divide-slate-100">
              {filtered.map(log => (
                <div key={log.id} className="p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-900">
                      {log.action}
                    </span>
                    <span className="font-mono text-[11px] text-slate-400">{log.date}</span>
                  </div>
                  <p className="text-xs text-slate-800 font-medium">{log.description}</p>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    {log.documentNumber ? (
                      <span className="font-mono font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded">
                        {log.documentNumber}
                      </span>
                    ) : <span></span>}
                    <div className="flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>{log.user}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop View: Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Horodatage</th>
                    <th className="p-3">Action</th>
                    <th className="p-3">Description Technique</th>
                    <th className="p-3">Document Lié</th>
                    <th className="p-3">Utilisateur / Rôle</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono text-slate-500 whitespace-nowrap">
                        {log.date}
                      </td>
                      <td className="p-3">
                        <span className="font-semibold text-slate-900">
                          {log.action}
                        </span>
                      </td>
                      <td className="p-3 text-slate-700">
                        {log.description}
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-800">
                        {log.documentNumber || '—'}
                      </td>
                      <td className="p-3 text-slate-600 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>{log.user}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

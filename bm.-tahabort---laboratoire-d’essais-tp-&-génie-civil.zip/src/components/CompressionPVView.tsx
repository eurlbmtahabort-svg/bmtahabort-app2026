import React, { useState } from 'react';
import {
  FileCheck2,
  Plus,
  Search,
  Printer,
  Trash2,
  Edit,
  Eye,
  FileSpreadsheet,
  Calculator,
  AlertTriangle,
  CheckCircle2,
  Info,
  Calendar,
  Layers,
  Award,
  Clock,
  Shield
} from 'lucide-react';
import { CompressionPV, CompressionSpecimen, Project, Client, Chantier, Sample, SpecimenType, LabSettings } from '../types';
import {
  getSpecimenAreaMm2,
  calculateCompressiveStrengthMpa,
  calculateAverageStrength,
  calculateStandardDeviation
} from '../utils/engineeringCalculations';
import { CONCRETE_STRENGTH_CLASSES, FAILURE_MODES_LIST } from '../data/algeriaData';
import { exportCompressionPVToExcel, exportCompressionPVsListToExcel } from '../utils/excelExport';
import { PrintPreviewModal } from './PrintPreviewModal';

interface CompressionPVViewProps {
  pvs: CompressionPV[];
  projects: Project[];
  clients: Client[];
  chantiers: Chantier[];
  samples: Sample[];
  settings?: LabSettings;
  onSave: (pv: CompressionPV) => void;
  onDelete: (id: string) => void;
  getNextNumber: () => string;
  initialCreateTrigger?: boolean;
  onResetCreateTrigger?: () => void;
  onOpenReport?: (pv: CompressionPV) => void;
}

export const CompressionPVView: React.FC<CompressionPVViewProps> = ({
  pvs,
  projects,
  clients,
  chantiers,
  samples,
  settings,
  onSave,
  onDelete,
  getNextNumber,
  initialCreateTrigger,
  onResetCreateTrigger,
  onOpenReport
}) => {
  const [search, setSearch] = useState('');
  const [ageFilter, setAgeFilter] = useState<'ALL' | 7 | 14 | 28>('ALL');
  const [selectedPV, setSelectedPV] = useState<CompressionPV | null>(null);
  const [previewModalPV, setPreviewModalPV] = useState<CompressionPV | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  // Form State
  const [formData, setFormData] = useState<Partial<CompressionPV>>({});
  const [specimens, setSpecimens] = useState<CompressionSpecimen[]>([]);

  // Trigger from parent quick action
  React.useEffect(() => {
    if (initialCreateTrigger) {
      handleStartNew(28);
      if (onResetCreateTrigger) onResetCreateTrigger();
    }
  }, [initialCreateTrigger]);

  // Compute crushing date given confection date and age in days
  const computeCrushingDate = (confectionDateStr: string, ageDays: number) => {
    if (!confectionDateStr) return new Date().toISOString().split('T')[0];
    const d = new Date(confectionDateStr);
    if (isNaN(d.getTime())) return new Date().toISOString().split('T')[0];
    d.setDate(d.getDate() + ageDays);
    return d.toISOString().split('T')[0];
  };

  // Compute target strength based on class and age
  const computeTargetStrength = (concreteClass: string, ageDays: number) => {
    const classObj = CONCRETE_STRENGTH_CLASSES.find(c => c.code === concreteClass);
    const fckCyl = classObj ? classObj.fckCyl : 25;
    if (ageDays === 7) return Math.round(fckCyl * 0.70 * 10) / 10;
    if (ageDays === 14) return Math.round(fckCyl * 0.85 * 10) / 10;
    if (ageDays === 28) return fckCyl;
    return fckCyl;
  };

  const handleStartNew = (initialAge: number = 28) => {
    const newNumber = getNextNumber();
    const today = new Date().toISOString().split('T')[0];
    const defaultProj = projects[0];

    // Confection date set to `initialAge` days ago so crushing date defaults to today
    const confectionD = new Date();
    confectionD.setDate(confectionD.getDate() - initialAge);
    const confectionDate = confectionD.toISOString().split('T')[0];
    const crushingDate = today;

    const initialSpecimens: CompressionSpecimen[] = [
      {
        id: 'spec-1',
        index: 1,
        ageDays: initialAge,
        dimensionsDescription: 'Cylindre Ø16×32 cm',
        diameterMm: 160,
        heightMm: 320,
        areaMm2: 20106.2,
        massG: 12540,
        maxLoadKn: 0,
        strengthMpa: 0,
        failureMode: 'Cône satisfaisant (Norme Fig 1)'
      },
      {
        id: 'spec-2',
        index: 2,
        ageDays: initialAge,
        dimensionsDescription: 'Cylindre Ø16×32 cm',
        diameterMm: 160,
        heightMm: 320,
        areaMm2: 20106.2,
        massG: 12510,
        maxLoadKn: 0,
        strengthMpa: 0,
        failureMode: 'Cône satisfaisant (Norme Fig 1)'
      },
      {
        id: 'spec-3',
        index: 3,
        ageDays: initialAge,
        dimensionsDescription: 'Cylindre Ø16×32 cm',
        diameterMm: 160,
        heightMm: 320,
        areaMm2: 20106.2,
        massG: 12580,
        maxLoadKn: 0,
        strengthMpa: 0,
        failureMode: 'Cône satisfaisant (Norme Fig 1)'
      }
    ];

    const targetStrength = computeTargetStrength('C25/30', initialAge);

    setFormData({
      id: 'pv-' + Date.now(),
      pvNumber: newNumber,
      projectId: defaultProj ? defaultProj.id : '',
      projectName: defaultProj ? defaultProj.name : '',
      clientId: defaultProj ? defaultProj.clientId : '',
      clientName: defaultProj ? defaultProj.clientName : '',
      chantierId: defaultProj ? defaultProj.chantierId : '',
      chantierName: defaultProj ? defaultProj.chantierName : '',
      sampleId: '',
      sampleNumber: 'ECH-001',
      samplingDate: confectionDate,
      confectionDate: confectionDate,
      crushingDate: crushingDate,
      concreteAgeDays: initialAge,
      concreteClass: 'C25/30',
      specimenType: 'CYLINDRIQUE_16_32',
      machineUsed: 'Presse Hydraulique 2000 kN Automatique (Étalonnée)',
      operator: settings?.technicianName || 'Technicien Supérieur Béton',
      technicianName: settings?.technicianName || 'Technicien Supérieur Béton',
      directorName: settings?.directorName || 'Ing. B. Mourad (Directeur Technique)',
      targetStrengthMpa: targetStrength,
      complianceObservation: 'Résultats conformes aux spécifications du marché pour l’échéance sélectionnée.',
      observations: `Éprouvettes conservées en immersion à 20°C ± 2°C (NF EN 12390-2). Essai à ${initialAge} jours.`,
      conclusion: `La résistance moyenne obtenue satisfait aux critères de conformité requis à ${initialAge} jours.`,
      status: 'VALIDE',
      validatedBy: settings?.directorName || 'Directeur Technique Laboratoire',
      createdAt: today
    });
    setSpecimens(initialSpecimens);
    setIsEditing(true);
    setSelectedPV(null);
  };

  const handleEdit = (pv: CompressionPV) => {
    setFormData({
      ...pv,
      technicianName: pv.technicianName || pv.operator || settings?.technicianName,
      directorName: pv.directorName || settings?.directorName
    });
    setSpecimens([...pv.specimens]);
    setIsEditing(true);
    setSelectedPV(null);
  };

  const handleView = (pv: CompressionPV) => {
    setSelectedPV(pv);
    setIsEditing(false);
  };

  const handlePrint = (pv: CompressionPV) => {
    setPreviewModalPV(pv);
  };

  // Change age directly in form (7j, 14j, 28j with equal importance)
  const handleSetAge = (age: number) => {
    const confectionDate = formData.confectionDate || formData.samplingDate || '';
    const newCrushingDate = computeCrushingDate(confectionDate, age);
    const newTarget = computeTargetStrength(formData.concreteClass || 'C25/30', age);

    setFormData({
      ...formData,
      concreteAgeDays: age,
      crushingDate: newCrushingDate,
      targetStrengthMpa: newTarget,
      observations: `Éprouvettes conservées en immersion à 20°C ± 2°C. Essai à ${age} jours.`
    });

    // Propagate age to all specimens
    setSpecimens(specimens.map(s => ({ ...s, ageDays: age })));
  };

  // Update specimen load and recompute strength
  const handleSpecimenLoadChange = (id: string, loadKn: number) => {
    const updated = specimens.map(s => {
      if (s.id === id) {
        const str = calculateCompressiveStrengthMpa(loadKn, s.areaMm2);
        return { ...s, maxLoadKn: loadKn, strengthMpa: str };
      }
      return s;
    });
    setSpecimens(updated);

    // Auto-update average and standard deviation in formData preview
    const strengths = updated.map(s => s.strengthMpa);
    const avg = calculateAverageStrength(strengths);
    const stdDev = calculateStandardDeviation(strengths);
    setFormData(prev => ({
      ...prev,
      averageStrengthMpa: avg,
      standardDeviationMpa: stdDev
    }));
  };

  const handleSpecimenFieldChange = (id: string, field: keyof CompressionSpecimen, value: any) => {
    setSpecimens(specimens.map(s => {
      if (s.id === id) {
        return { ...s, [field]: value };
      }
      return s;
    }));
  };

  const handleAddSpecimen = () => {
    const nextIdx = specimens.length + 1;
    const refSpec = specimens[0] || {
      dimensionsDescription: 'Cylindre Ø16×32 cm',
      diameterMm: 160,
      heightMm: 320,
      areaMm2: 20106.2
    };

    const newSpec: CompressionSpecimen = {
      id: 'spec-' + Date.now(),
      index: nextIdx,
      ageDays: formData.concreteAgeDays || 28,
      dimensionsDescription: refSpec.dimensionsDescription,
      diameterMm: refSpec.diameterMm,
      heightMm: refSpec.heightMm,
      sideMm: refSpec.sideMm,
      areaMm2: refSpec.areaMm2,
      massG: 12500,
      maxLoadKn: 0,
      strengthMpa: 0,
      failureMode: 'Cône satisfaisant (Norme Fig 1)'
    };
    setSpecimens([...specimens, newSpec]);
  };

  const handleRemoveSpecimen = (id: string) => {
    if (specimens.length <= 1) {
      alert('Un procès-verbal doit comporter au moins une éprouvette.');
      return;
    }
    const filtered = specimens.filter(s => s.id !== id).map((s, idx) => ({ ...s, index: idx + 1 }));
    setSpecimens(filtered);
  };

  const handleSpecimenTypeChange = (type: SpecimenType) => {
    let dimDesc = '';
    let d = 160;
    let h = 320;
    let side: number | undefined = undefined;

    switch (type) {
      case 'CYLINDRIQUE_16_32':
        dimDesc = 'Cylindre Ø16×32 cm';
        d = 160;
        h = 320;
        break;
      case 'CYLINDRIQUE_11_22':
        dimDesc = 'Cylindre Ø11.3×22 cm';
        d = 113;
        h = 220;
        break;
      case 'CUBIQUE_15_15':
        dimDesc = 'Cube 15×15 cm';
        side = 150;
        d = 0;
        h = 150;
        break;
      case 'CUBIQUE_10_10':
        dimDesc = 'Cube 10×10 cm';
        side = 100;
        d = 0;
        h = 100;
        break;
      case 'AUTRE':
        dimDesc = 'Prismatique / Spécial';
        break;
    }

    const area = getSpecimenAreaMm2(type);

    const updated = specimens.map(s => {
      const str = calculateCompressiveStrengthMpa(s.maxLoadKn, area);
      return {
        ...s,
        dimensionsDescription: dimDesc,
        diameterMm: d,
        heightMm: h,
        sideMm: side,
        areaMm2: area,
        strengthMpa: str
      };
    });

    setSpecimens(updated);
    setFormData({ ...formData, specimenType: type });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.pvNumber || !formData.projectId) {
      alert('Veuillez remplir le numéro de PV et sélectionner un projet.');
      return;
    }

    const proj = projects.find(p => p.id === formData.projectId);
    const strengths = specimens.map(s => s.strengthMpa);
    const avg = calculateAverageStrength(strengths);
    const stdDev = calculateStandardDeviation(strengths);

    const completePV: CompressionPV = {
      id: formData.id || 'pv-' + Date.now(),
      pvNumber: formData.pvNumber,
      projectId: formData.projectId,
      projectName: proj ? proj.name : formData.projectName || '',
      clientId: formData.clientId || (proj ? proj.clientId : ''),
      clientName: formData.clientName || (proj ? proj.clientName : ''),
      chantierId: formData.chantierId || (proj ? proj.chantierId : ''),
      chantierName: formData.chantierName || (proj ? proj.chantierName : ''),
      sampleId: formData.sampleId,
      sampleNumber: formData.sampleNumber || 'ECH-001',
      samplingDate: formData.samplingDate || '',
      receptionDate: formData.receptionDate || '',
      confectionDate: formData.confectionDate || '',
      crushingDate: formData.crushingDate || new Date().toISOString().split('T')[0],
      concreteAgeDays: Number(formData.concreteAgeDays || 28),
      concreteClass: formData.concreteClass || 'C25/30',
      specimenType: formData.specimenType || 'CYLINDRIQUE_16_32',
      customDimensions: formData.customDimensions,
      machineUsed: formData.machineUsed || 'Presse Hydraulique 2000 kN étalonnée',
      operator: formData.technicianName || formData.operator || settings?.technicianName || 'Technicien Laboratoire',
      technicianName: formData.technicianName || formData.operator || settings?.technicianName || 'Technicien Laboratoire',
      directorName: formData.directorName || settings?.directorName || 'Ing. B. Mourad (Directeur Technique)',
      specimens: specimens,
      averageStrengthMpa: avg,
      standardDeviationMpa: stdDev,
      targetStrengthMpa: formData.targetStrengthMpa ? Number(formData.targetStrengthMpa) : undefined,
      complianceObservation: formData.complianceObservation || '',
      observations: formData.observations || '',
      conclusion: formData.conclusion || 'Résultats conformes aux exigences métrologiques.',
      status: formData.status || 'VALIDE',
      validatedBy: formData.directorName || settings?.directorName || 'Directeur Technique Laboratoire',
      createdAt: formData.createdAt || new Date().toISOString().split('T')[0]
    };

    onSave(completePV);
    setIsEditing(false);
    setSelectedPV(completePV);
  };

  const filtered = pvs.filter(p => {
    if (ageFilter !== 'ALL' && p.concreteAgeDays !== ageFilter) return false;
    const q = search.toLowerCase();
    return (
      p.pvNumber.toLowerCase().includes(q) ||
      (p.projectName && p.projectName.toLowerCase().includes(q)) ||
      (p.clientName && p.clientName.toLowerCase().includes(q)) ||
      (p.sampleNumber && p.sampleNumber.toLowerCase().includes(q)) ||
      (p.concreteClass && p.concreteClass.toLowerCase().includes(q))
    );
  });

  const renderPVContent = (pv: CompressionPV) => (
    <div className="space-y-6 text-slate-800">
      {/* Laboratory Header */}
      <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded bg-slate-900 text-teal-400 font-tech font-bold flex items-center justify-center text-base border-2 border-teal-600">
            BM
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-slate-900 font-tech">
              {settings?.labName || 'BM. TAHABORT'}
            </h1>
            <p className="text-[11px] text-slate-700 font-semibold">
              {settings?.subName || 'Laboratoire d’Essais de Travaux Publics & Génie Civil'}
            </p>
            <p className="text-[10px] text-slate-500">
              {settings?.address || 'Zone Industrielle, Alger'} • NIF: {settings?.nif || '001916012345678'} • RC: {settings?.rc || '16/00-1234567B19'}
            </p>
          </div>
        </div>

        <div className="text-right">
          <div className="text-xs font-bold text-teal-900 font-mono">
            {pv.pvNumber}
          </div>
          <div className="text-[10px] text-slate-500">
            Date d'écrasement : <strong>{pv.crushingDate}</strong>
          </div>
          <div className="text-[10px] font-bold text-teal-800 uppercase">
            Procès-Verbal Officiel d'Essai Mécanique
          </div>
        </div>
      </div>

      {/* Document Title */}
      <div className="text-center py-2.5 bg-slate-100 rounded border border-slate-200">
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide font-tech">
          Procès-Verbal d'Essai de Résistance à la Compression du Béton
        </h2>
        <p className="text-xs text-slate-600">
          Selon normes NF EN 12390-3 / NA 437 • Échéance d'écrasement : <strong>{pv.concreteAgeDays} jours</strong> • Classe : <strong>{pv.concreteClass}</strong>
        </p>
      </div>

      {/* Information Grid */}
      <div className="grid grid-cols-2 gap-4 text-xs">
        <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
          <div className="text-[10px] uppercase font-bold text-slate-400">Identification du Chantier</div>
          <div>Projet : <strong>{pv.projectName}</strong></div>
          <div>Chantier : <strong>{pv.chantierName || 'Non spécifié'}</strong></div>
          <div>Client / Maître de l'Ouvrage : <strong>{pv.clientName || 'N/A'}</strong></div>
        </div>

        <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
          <div className="text-[10px] uppercase font-bold text-slate-400">Prélèvement & Conservation</div>
          <div>N° Échantillon : <strong>{pv.sampleNumber}</strong></div>
          <div>Date de confection : <strong>{pv.confectionDate || pv.samplingDate}</strong></div>
          <div>Date d'essai d'écrasement : <strong>{pv.crushingDate}</strong> (Âge : <strong>{pv.concreteAgeDays} jours</strong>)</div>
          <div>Presse d'essai : <strong>{pv.machineUsed}</strong></div>
        </div>
      </div>

      {/* Specimens Results Table */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
          Résultats Métrologiques des Éprouvettes
        </h3>
        <table className="w-full text-xs border border-slate-300 text-left">
          <thead className="bg-slate-100 text-slate-700 border-b border-slate-300 font-semibold">
            <tr>
              <th className="p-2 border-r border-slate-300 text-center">Éprouvette</th>
              <th className="p-2 border-r border-slate-300 text-center">Âge (j)</th>
              <th className="p-2 border-r border-slate-300">Dimensions / Type</th>
              <th className="p-2 border-r border-slate-300 text-right">Masse (g)</th>
              <th className="p-2 border-r border-slate-300 text-right">Charge F (kN)</th>
              <th className="p-2 border-r border-slate-300 text-right">Surface (mm²)</th>
              <th className="p-2 border-r border-slate-300 text-right">Résistance (MPa)</th>
              <th className="p-2">Mode de rupture</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {pv.specimens.map(s => (
              <tr key={s.id}>
                <td className="p-2 text-center font-bold font-mono border-r border-slate-200">
                  #{s.index}
                </td>
                <td className="p-2 text-center font-mono border-r border-slate-200">
                  {s.ageDays} j
                </td>
                <td className="p-2 border-r border-slate-200">
                  {s.dimensionsDescription}
                </td>
                <td className="p-2 text-right font-mono border-r border-slate-200">
                  {s.massG || '-'}
                </td>
                <td className="p-2 text-right font-mono font-semibold border-r border-slate-200">
                  {s.maxLoadKn.toFixed(1)}
                </td>
                <td className="p-2 text-right font-mono border-r border-slate-200">
                  {s.areaMm2.toFixed(1)}
                </td>
                <td className="p-2 text-right font-mono font-bold text-slate-900 border-r border-slate-200">
                  {s.strengthMpa.toFixed(2)}
                </td>
                <td className="p-2 text-slate-700">
                  {s.failureMode}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300">
            <tr>
              <td colSpan={6} className="p-2.5 text-right border-r border-slate-300 text-slate-800">
                RÉSISTANCE MOYENNE À LA COMPRESSION (fcm) :
              </td>
              <td colSpan={2} className="p-2.5">
                <span className="font-mono text-sm font-extrabold text-teal-900">
                  {pv.averageStrengthMpa.toFixed(2)} MPa
                </span>
              </td>
            </tr>
            {pv.standardDeviationMpa !== undefined && (
              <tr className="bg-slate-50 border-t border-slate-200">
                <td colSpan={6} className="p-2 text-right border-r border-slate-300 text-slate-700 font-medium">
                  Écart-type de l'échantillon (s) :
                </td>
                <td colSpan={2} className="p-2 font-mono font-semibold text-slate-800">
                  {pv.standardDeviationMpa.toFixed(2)} MPa
                </td>
              </tr>
            )}
            {pv.targetStrengthMpa !== undefined && pv.targetStrengthMpa > 0 && (
              <tr className="bg-slate-50 border-t border-slate-200">
                <td colSpan={6} className="p-2 text-right border-r border-slate-300 text-slate-700 font-medium">
                  Résistance caractéristique requise à {pv.concreteAgeDays} jours :
                </td>
                <td colSpan={2} className="p-2 flex items-center gap-2">
                  <span className="font-mono font-semibold text-slate-800">
                    {pv.targetStrengthMpa.toFixed(2)} MPa
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    pv.averageStrengthMpa >= pv.targetStrengthMpa
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {pv.averageStrengthMpa >= pv.targetStrengthMpa ? 'CONFORME' : 'À VÉRIFIER'}
                  </span>
                </td>
              </tr>
            )}
          </tfoot>
        </table>
      </div>

      {/* Observations, Conclusion and Signatures */}
      <div className="space-y-3 text-xs">
        <div className="p-3 bg-slate-50 rounded border border-slate-200">
          <span className="font-bold text-slate-800 block mb-1">Conclusion du Laboratoire :</span>
          <p className="text-slate-700 font-medium">
            {pv.conclusion}
          </p>
          {pv.observations && (
            <p className="text-slate-500 text-[11px] mt-1 italic">
              Remarques : {pv.observations}
            </p>
          )}
        </div>

        {/* Official Signatories Snapshot */}
        <div className="grid grid-cols-2 gap-8 pt-4 border-t border-slate-200">
          <div>
            <div className="font-semibold text-slate-800">L'Opérateur d'Essai (Technicien) :</div>
            <p className="text-[11px] text-slate-600 mt-1 font-medium">
              {pv.technicianName || pv.operator || 'Technicien Supérieur Béton'}
            </p>
            <div className="h-14"></div>
            <div className="text-[10px] text-slate-400 border-t border-slate-300 pt-1">
              Signature du technicien
            </div>
          </div>

          <div className="text-right">
            <div className="font-semibold text-slate-800">Le Directeur Technique / Chef de Laboratoire :</div>
            <p className="text-[11px] text-slate-600 mt-1 font-bold">
              {pv.directorName || 'Ing. B. Mourad (Directeur Technique)'}
            </p>
            <div className="h-14"></div>
            <div className="text-[10px] text-slate-400 border-t border-slate-300 pt-1">
              Cachet & Visa de validation
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Procès-Verbaux d’Écrasement (PV de Compression)
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold">
              NF EN 12390-3 / NA 437
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Chaque PV d'écrasement constitue un rapport d'essai indépendant (7 jours, 14 jours ou 28 jours), avec calculs de résistance (σ = (F × 10³) / S), moyenne fcm, écart-type et export Excel direct.
          </p>
        </div>

        {/* Action button creating a PV */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleStartNew(28)}
            className="px-3.5 py-2 bg-teal-700 hover:bg-teal-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Nouveau PV d’Écrasement</span>
          </button>
        </div>
      </div>

      {/* Editor Modal / Form */}
      {isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6 no-print">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-teal-700" />
              <div>
                <h3 className="font-bold text-slate-900 text-base font-tech">
                  {formData.id ? 'Éditer le Procès-Verbal d’Écrasement' : 'Nouveau PV d’Écrasement'}
                </h3>
                <span className="text-xs text-slate-500 font-mono">
                  Échéance : <strong>{formData.concreteAgeDays} jours</strong> • Classe : {formData.concreteClass}
                </span>
              </div>
            </div>
            <button
              onClick={() => setIsEditing(false)}
              className="text-slate-500 hover:text-slate-800 text-xs px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 cursor-pointer"
            >
              Annuler
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Section 1: PV Header & Link */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900 mb-3">
                1. Identification du PV & Origine des Éprouvettes
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    N° du Procès-Verbal <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.pvNumber || ''}
                    onChange={e => setFormData({ ...formData, pvNumber: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Projet <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    value={formData.projectId || ''}
                    onChange={e => {
                      const p = projects.find(item => item.id === e.target.value);
                      setFormData({
                        ...formData,
                        projectId: e.target.value,
                        projectName: p ? p.name : '',
                        clientId: p ? p.clientId : '',
                        clientName: p ? p.clientName : '',
                        chantierId: p ? p.chantierId : '',
                        chantierName: p ? p.chantierName : ''
                      });
                    }}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-900"
                  >
                    <option value="">Sélectionner un projet...</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.projectNumber} - {p.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Client / Maître d'Ouvrage
                  </label>
                  <input
                    type="text"
                    value={formData.clientName || ''}
                    onChange={e => setFormData({ ...formData, clientName: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Chantier
                  </label>
                  <input
                    type="text"
                    value={formData.chantierName || ''}
                    onChange={e => setFormData({ ...formData, chantierName: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-900"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Concrete Age, Dates & Strength Class (EQUAL IMPORTANCE FOR 7J, 14J, 28J) */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900">
                  2. Âge d'Essai du Béton & Calendrier Métrologique
                </h4>
                <span className="text-[10px] text-teal-800 bg-teal-100 px-2.5 py-0.5 rounded-full font-semibold">
                  Norme : 7j, 14j et 28j sont des échéances d'essais indépendantes
                </span>
              </div>

              {/* Fast Age Selector Buttons */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  Sélection Rapide de l'Échéance d'Essai :
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => handleSetAge(7)}
                    className={`p-2.5 rounded-lg border text-left cursor-pointer transition-all ${
                      formData.concreteAgeDays === 7
                        ? 'bg-blue-50 border-blue-500 text-blue-900 font-bold ring-2 ring-blue-300'
                        : 'bg-white border-slate-300 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-blue-600" />
                      <span>7 Jours</span>
                    </div>
                    <div className="text-[10px] text-slate-500">Contrôle initial (~70% fck)</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSetAge(14)}
                    className={`p-2.5 rounded-lg border text-left cursor-pointer transition-all ${
                      formData.concreteAgeDays === 14
                        ? 'bg-amber-50 border-amber-500 text-amber-900 font-bold ring-2 ring-amber-300'
                        : 'bg-white border-slate-300 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                      <span>14 Jours</span>
                    </div>
                    <div className="text-[10px] text-slate-500">Intermédiaire (~85% fck)</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSetAge(28)}
                    className={`p-2.5 rounded-lg border text-left cursor-pointer transition-all ${
                      formData.concreteAgeDays === 28
                        ? 'bg-teal-50 border-teal-600 text-teal-900 font-bold ring-2 ring-teal-300'
                        : 'bg-white border-slate-300 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5 text-teal-700" />
                      <span>28 Jours</span>
                    </div>
                    <div className="text-[10px] text-slate-500">Contractuel (100% fck)</div>
                  </button>

                  <div className="p-2 bg-white rounded-lg border border-slate-300 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-600">Autre âge :</span>
                    <input
                      type="number"
                      min={1}
                      max={365}
                      value={formData.concreteAgeDays || ''}
                      onChange={e => handleSetAge(Number(e.target.value))}
                      className="w-16 p-1 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-center text-xs"
                    />
                    <span className="text-xs font-bold text-slate-700">j</span>
                  </div>
                </div>
              </div>

              {/* Dates & Concrete Class */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs pt-2">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Date de confection (coulage)
                  </label>
                  <input
                    type="date"
                    value={formData.confectionDate || ''}
                    onChange={e => {
                      const newConf = e.target.value;
                      const newCrush = computeCrushingDate(newConf, formData.concreteAgeDays || 28);
                      setFormData({
                        ...formData,
                        confectionDate: newConf,
                        crushingDate: newCrush
                      });
                    }}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Date d’écrasement effective
                  </label>
                  <input
                    type="date"
                    value={formData.crushingDate || ''}
                    onChange={e => setFormData({ ...formData, crushingDate: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Classe de béton prescrite
                  </label>
                  <select
                    value={formData.concreteClass || 'C25/30'}
                    onChange={e => {
                      const newClass = e.target.value;
                      const newTarget = computeTargetStrength(newClass, formData.concreteAgeDays || 28);
                      setFormData({ ...formData, concreteClass: newClass, targetStrengthMpa: newTarget });
                    }}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                  >
                    {CONCRETE_STRENGTH_CLASSES.map(c => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.desc})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Résistance cible requise (MPa)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.targetStrengthMpa || ''}
                    onChange={e => setFormData({ ...formData, targetStrengthMpa: Number(e.target.value) })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-teal-900"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Specimen Geometry & Test Machine */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Format & Type d’Éprouvette
                  </label>
                  <select
                    value={formData.specimenType || 'CYLINDRIQUE_16_32'}
                    onChange={e => handleSpecimenTypeChange(e.target.value as SpecimenType)}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-semibold text-slate-900"
                  >
                    <option value="CYLINDRIQUE_16_32">Cylindrique Ø16×32 cm (Surface 201.06 cm²)</option>
                    <option value="CYLINDRIQUE_11_22">Cylindrique Ø11.3×22 cm (Surface 100.0 cm²)</option>
                    <option value="CUBIQUE_15_15">Cubique 15×15 cm (Surface 225.0 cm²)</option>
                    <option value="CUBIQUE_10_10">Cubique 10×10 cm (Surface 100.0 cm²)</option>
                    <option value="AUTRE">Autre format normalisé</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Machine d’Essai Utilisée (Presse Étalonnée)
                  </label>
                  <input
                    type="text"
                    value={formData.machineUsed || ''}
                    onChange={e => setFormData({ ...formData, machineUsed: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-900"
                  />
                </div>
              </div>
            </div>

            {/* Section 4: Specimens Table with Live Calculations */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900">
                    4. Résultats de Rupture par Éprouvette
                  </h4>
                  <span className="text-[11px] text-slate-500 font-mono">
                    Formule normalisée : Résistance (MPa) = (Charge F en kN × 1000) / Surface en mm²
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleAddSpecimen}
                  className="px-2.5 py-1 bg-teal-700 hover:bg-teal-600 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Ajouter une Éprouvette</span>
                </button>
              </div>

              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-100 text-slate-700 border-b border-slate-200">
                    <tr>
                      <th className="p-2 w-12 text-center">N°</th>
                      <th className="p-2 w-20 text-center">Âge (j)</th>
                      <th className="p-2">Format</th>
                      <th className="p-2 w-24">Masse (g)</th>
                      <th className="p-2 w-28">Surface (mm²)</th>
                      <th className="p-2 w-32">Charge F (kN) *</th>
                      <th className="p-2 w-32 font-bold text-slate-900">Résistance (MPa)</th>
                      <th className="p-2">Mode de rupture (Fig. NF EN)</th>
                      <th className="p-2 w-10 text-center"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {specimens.map((spec, idx) => (
                      <tr key={spec.id} className="hover:bg-slate-50">
                        <td className="p-2 text-center font-bold text-slate-700">
                          #{spec.index}
                        </td>
                        <td className="p-2 text-center font-mono">
                          <input
                            type="number"
                            value={spec.ageDays}
                            onChange={e => handleSpecimenFieldChange(spec.id, 'ageDays', Number(e.target.value))}
                            className="w-14 p-1 text-center bg-white border border-slate-300 rounded font-mono font-bold"
                          />
                        </td>
                        <td className="p-2 text-slate-600 text-[11px]">
                          {spec.dimensionsDescription}
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={spec.massG || ''}
                            onChange={e => handleSpecimenFieldChange(spec.id, 'massG', Number(e.target.value))}
                            placeholder="ex: 12500"
                            className="w-full p-1 bg-white border border-slate-300 rounded font-mono text-xs"
                          />
                        </td>
                        <td className="p-2 font-mono text-slate-600">
                          {spec.areaMm2.toFixed(1)}
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            step="0.1"
                            value={spec.maxLoadKn || ''}
                            onChange={e => handleSpecimenLoadChange(spec.id, Number(e.target.value))}
                            placeholder="0.0"
                            className="w-full p-1.5 bg-amber-50 border border-amber-300 rounded font-mono font-bold text-amber-950 text-xs focus:ring-1 focus:ring-amber-500"
                          />
                        </td>
                        <td className="p-2 font-mono font-bold text-sm text-teal-900">
                          {spec.strengthMpa.toFixed(2)} MPa
                        </td>
                        <td className="p-2">
                          <select
                            value={spec.failureMode}
                            onChange={e => handleSpecimenFieldChange(spec.id, 'failureMode', e.target.value)}
                            className="w-full p-1 bg-white border border-slate-300 rounded text-xs"
                          >
                            {FAILURE_MODES_LIST.map(f => (
                              <option key={f} value={f}>{f}</option>
                            ))}
                          </select>
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveSpecimen(spec.id)}
                            className="text-slate-400 hover:text-red-600 p-1 cursor-pointer"
                            title="Supprimer cette éprouvette"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Live Calculation Summary Banner */}
            <div className="p-4 bg-teal-50 rounded-xl border border-teal-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-teal-600 text-white rounded-lg">
                  <Calculator className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-teal-800 font-semibold">
                    Résistance Moyenne de la Série (fcm) à {formData.concreteAgeDays} jours :
                  </div>
                  <div className="text-xl font-bold font-mono text-teal-950">
                    {calculateAverageStrength(specimens.map(s => s.strengthMpa)).toFixed(2)} MPa
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6 text-xs font-mono">
                <div>
                  <span className="text-slate-500 block">Écart-type (s) :</span>
                  <span className="font-bold text-slate-800">
                    {calculateStandardDeviation(specimens.map(s => s.strengthMpa)).toFixed(2)} MPa
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Résistance Cible :</span>
                  <span className="font-bold text-slate-800">
                    {formData.targetStrengthMpa ? `${formData.targetStrengthMpa} MPa` : 'Non fixée'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Évaluation :</span>
                  <span className="font-bold text-teal-800">
                    {formData.targetStrengthMpa && calculateAverageStrength(specimens.map(s => s.strengthMpa)) >= formData.targetStrengthMpa
                      ? 'CONFORME'
                      : 'SATISFAISANT'}
                  </span>
                </div>
              </div>
            </div>

            {/* Section 5: Personnel Signatories (IMMUTABLE SNAPSHOT) */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-teal-700" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900">
                  5. Signataires Officiels du Procès-Verbal (Stockés Définitivement dans ce PV)
                </h4>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Technicien d'Essais (Opérateur)
                  </label>
                  <input
                    type="text"
                    value={formData.technicianName || ''}
                    onChange={e => setFormData({ ...formData, technicianName: e.target.value, operator: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Personne ayant procédé à l'écrasement sur la presse.
                  </span>
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Directeur Technique / Chef de Laboratoire (Visa)
                  </label>
                  <input
                    type="text"
                    value={formData.directorName || ''}
                    onChange={e => setFormData({ ...formData, directorName: e.target.value, validatedBy: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Responsable habilité à valider et certifier le présent PV.
                  </span>
                </div>
              </div>
            </div>

            {/* Observations & Conclusion */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Observations Métrologiques & Conditions de Cure
                </label>
                <textarea
                  rows={2}
                  value={formData.observations || ''}
                  onChange={e => setFormData({ ...formData, observations: e.target.value })}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Conclusion & Avis Technique
                </label>
                <textarea
                  rows={2}
                  value={formData.conclusion || ''}
                  onChange={e => setFormData({ ...formData, conclusion: e.target.value })}
                  className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-800"
                />
              </div>
            </div>

            {/* Form Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-teal-700 hover:bg-teal-600 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                Enregistrer le Procès-Verbal
              </button>
            </div>
          </form>
        </div>
      )}

      {/* =========================================================================
          PV DETAILS VIEW & PRINT (WITH PROMINENT EXCEL EXPORT)
          ========================================================================= */}
      {selectedPV && !isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3 no-print">
            <div className="flex items-center gap-2.5">
              <span className="font-mono text-sm font-bold text-teal-900 bg-teal-50 px-2.5 py-1 rounded border border-teal-200">
                {selectedPV.pvNumber}
              </span>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Procès-Verbal d'Essai de Compression
                </h3>
                <span className="text-xs text-slate-500">
                  Échéance : <strong>{selectedPV.concreteAgeDays} jours</strong> • Classe : {selectedPV.concreteClass}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* PROMINENT EXCEL EXPORT BUTTON */}
              <button
                onClick={() => exportCompressionPVToExcel(selectedPV, settings)}
                className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                title="Télécharger ce PV au format officiel Excel (.xlsx)"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Exporter en Excel</span>
              </button>

              <button
                onClick={() => handlePrint(selectedPV)}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                title="Aperçu avant impression et export PDF"
              >
                <Printer className="w-4 h-4" />
                <span>Aperçu & Impression</span>
              </button>

              <button
                onClick={() => handleEdit(selectedPV)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Edit className="w-4 h-4" />
                <span>Modifier</span>
              </button>

              <button
                onClick={() => setSelectedPV(null)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>

          {/* Official Document Body */}
          {renderPVContent(selectedPV)}
        </div>
      )}

      {/* =========================================================================
          PV LIST TABLE (WITH AGE FILTERS & DIRECT EXCEL EXPORT BUTTON)
          ========================================================================= */}
      {!isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden no-print">
          {/* Filter Bar */}
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative flex-1 min-w-[200px] max-w-xs">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Rechercher par N° PV, projet, client..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>

              {/* Age Filter Tabs */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs">
                <button
                  onClick={() => setAgeFilter('ALL')}
                  className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                    ageFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Tous les âges
                </button>
                <button
                  onClick={() => setAgeFilter(7)}
                  className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                    ageFilter === 7 ? 'bg-blue-600 text-white shadow-xs font-bold' : 'text-slate-600 hover:text-blue-700'
                  }`}
                >
                  7 Jours
                </button>
                <button
                  onClick={() => setAgeFilter(14)}
                  className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                    ageFilter === 14 ? 'bg-amber-600 text-white shadow-xs font-bold' : 'text-slate-600 hover:text-amber-700'
                  }`}
                >
                  14 Jours
                </button>
                <button
                  onClick={() => setAgeFilter(28)}
                  className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                    ageFilter === 28 ? 'bg-teal-700 text-white shadow-xs font-bold' : 'text-slate-600 hover:text-teal-800'
                  }`}
                >
                  28 Jours
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => exportCompressionPVsListToExcel(filtered, settings)}
                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                title="Exporter tous les procès-verbaux filtrés en Excel (.xlsx)"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Exporter le Registre Excel</span>
              </button>
              <span className="text-xs text-slate-500">
                {filtered.length} PV affiché{filtered.length > 1 ? 's' : ''}
              </span>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="p-12 text-center text-xs text-slate-400">
              Aucun procès-verbal d’écrasement correspondant.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filtered.map(pv => {
                // Color badge according to age
                let ageBadgeClass = 'bg-slate-100 text-slate-700 border-slate-200';
                if (pv.concreteAgeDays === 7) ageBadgeClass = 'bg-blue-50 text-blue-800 border-blue-200 font-bold';
                else if (pv.concreteAgeDays === 14) ageBadgeClass = 'bg-amber-50 text-amber-900 border-amber-200 font-bold';
                else if (pv.concreteAgeDays === 28) ageBadgeClass = 'bg-teal-50 text-teal-900 border-teal-200 font-bold';

                return (
                  <div
                    key={pv.id}
                    className="p-3 sm:p-4 hover:bg-slate-50/80 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3"
                  >
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <div className="p-2.5 bg-teal-100 text-teal-800 rounded-lg flex-shrink-0">
                        <FileCheck2 className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-xs font-bold text-teal-900 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                            {pv.pvNumber}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded border ${ageBadgeClass}`}>
                            {pv.concreteAgeDays} Jours
                          </span>
                          <span className="text-xs font-bold text-slate-800">
                            {pv.projectName}
                          </span>
                          <span className="text-xs text-slate-500 truncate">
                            • {pv.clientName}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 mt-1 text-xs">
                          <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-bold font-mono">
                            {pv.concreteClass}
                          </span>
                          <span className="text-slate-500">
                            Écrasé le : {pv.crushingDate}
                          </span>
                          <span className="text-slate-500">
                            {pv.specimens.length} éprouvettes
                          </span>
                          <span className="font-mono font-bold text-teal-900 bg-teal-50/60 px-2 py-0.5 rounded">
                            Moyenne : {pv.averageStrengthMpa.toFixed(2)} MPa
                          </span>
                          {pv.targetStrengthMpa && (
                            <span className="text-slate-500">
                              (Cible : {pv.targetStrengthMpa.toFixed(1)} MPa)
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Actions: View, Excel Export, Print, Edit, Delete */}
                    <div className="flex items-center gap-1 self-end md:self-center">
                      <button
                        onClick={() => handleView(pv)}
                        title="Consulter les détails du PV"
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => exportCompressionPVToExcel(pv, settings)}
                        title="Exporter en Excel (.xls)"
                        className="p-2 text-emerald-700 hover:bg-emerald-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <FileSpreadsheet className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handlePrint(pv)}
                        title="Aperçu & Impression"
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleEdit(pv)}
                        title="Modifier"
                        className="p-2 text-teal-700 hover:bg-teal-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Supprimer le procès-verbal ${pv.pvNumber} ?`)) {
                            onDelete(pv.id);
                          }
                        }}
                        title="Supprimer"
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Responsive Print/PDF Preview Modal */}
      {previewModalPV && (
        <PrintPreviewModal
          isOpen={!!previewModalPV}
          onClose={() => setPreviewModalPV(null)}
          title={`Procès-Verbal d'Écrasement à ${previewModalPV.concreteAgeDays} Jours`}
          documentNumber={previewModalPV.pvNumber}
          documentSubtitle={`Classe ${previewModalPV.concreteClass} • Échéance ${previewModalPV.concreteAgeDays}j`}
          onExportExcel={() => exportCompressionPVToExcel(previewModalPV, settings)}
        >
          {renderPVContent(previewModalPV)}
        </PrintPreviewModal>
      )}
    </div>
  );
};

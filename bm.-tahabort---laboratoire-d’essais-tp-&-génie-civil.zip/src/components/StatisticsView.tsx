import React from 'react';
import {
  BarChart3,
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  FolderKanban,
  FileCheck2,
  Beaker,
  HardHat,
  Percent
} from 'lucide-react';
import { Project, LabTest, ConcreteFormulation, CompressionPV } from '../types';

interface StatisticsViewProps {
  projects: Project[];
  tests: LabTest[];
  formulations: ConcreteFormulation[];
  compressionPVs: CompressionPV[];
}

export const StatisticsView: React.FC<StatisticsViewProps> = ({
  projects,
  tests,
  formulations,
  compressionPVs
}) => {
  // Aggregate real statistics
  const totalTests = tests.length;
  const compliantTests = tests.filter(t => t.status === 'CONFORME' || t.status === 'VALIDE' || t.status === 'TERMINE').length;
  const nonCompliantTests = tests.filter(t => t.status === 'NON_CONFORME').length;
  const complianceRate = totalTests > 0 ? ((compliantTests / totalTests) * 100).toFixed(1) : '100.0';

  // Compression PV stats
  const allStrengths = compressionPVs.map(pv => pv.averageStrengthMpa).filter(s => s > 0);
  const overallAvgStrength = allStrengths.length > 0
    ? (allStrengths.reduce((a, b) => a + b, 0) / allStrengths.length).toFixed(2)
    : '0.00';

  // Category counts
  const categoryCounts: Record<string, number> = {};
  tests.forEach(t => {
    categoryCounts[t.category] = (categoryCounts[t.category] || 0) + 1;
  });

  // Projects status
  const activeProjects = projects.filter(p => p.status === 'EN_COURS').length;
  const completedProjects = projects.filter(p => p.status === 'TERMINE').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Indicateurs & Statistiques d'Activité
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
              Données Réelles du Laboratoire
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Analyse métrologique de la conformité des bétons, cadence des essais et volumétrie des dossiers de contrôle.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Taux de Conformité</span>
          <div className="text-2xl font-bold font-tech text-emerald-700 mt-2 flex items-center gap-1.5">
            <span>{complianceRate}%</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {compliantTests} conformes sur {totalTests} essais
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Résistance Moyenne Béton</span>
          <div className="text-2xl font-bold font-tech text-blue-700 mt-2">
            {overallAvgStrength} MPa
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Sur {compressionPVs.length} PV d'écrasement
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Formulations Actives</span>
          <div className="text-2xl font-bold font-tech text-teal-700 mt-2">
            {formulations.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Études granulaires & E/C validées
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Projets en Suivi</span>
          <div className="text-2xl font-bold font-tech text-amber-700 mt-2">
            {activeProjects}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {completedProjects} projets archivés avec succès
          </div>
        </div>
      </div>

      {/* Breakdown Details */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {/* Test Categories */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-sm font-tech">
            Répartition des Essais par Domaine Technique
          </h3>
          <div className="space-y-3 text-xs">
            {Object.entries(categoryCounts).map(([cat, count]) => {
              const pct = totalTests > 0 ? ((count / totalTests) * 100).toFixed(0) : 0;
              return (
                <div key={cat} className="space-y-1">
                  <div className="flex justify-between font-medium text-slate-700">
                    <span>{cat}</span>
                    <span className="font-mono text-slate-900">{count} essais ({pct}%)</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-emerald-600 h-2 rounded-full transition-all"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Concrete Resistance Overview */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-sm font-tech">
            Historique des Résistances des PV d'Écrasement
          </h3>
          {compressionPVs.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              Aucun PV d'écrasement enregistré pour le calcul des moyennes.
            </div>
          ) : (
            <div className="space-y-2 text-xs">
              {compressionPVs.slice(0, 6).map(pv => (
                <div key={pv.id} className="p-2.5 bg-slate-50 rounded-lg flex items-center justify-between">
                  <div>
                    <div className="font-mono font-bold text-slate-900">{pv.pvNumber}</div>
                    <div className="text-[11px] text-slate-500">
                      Classe {pv.concreteClass} • {pv.concreteAgeDays} jours
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-sm text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {pv.averageStrengthMpa ? pv.averageStrengthMpa.toFixed(2) : '0.00'} MPa
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

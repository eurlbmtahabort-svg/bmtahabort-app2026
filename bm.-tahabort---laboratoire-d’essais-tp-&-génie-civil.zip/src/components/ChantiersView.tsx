import React, { useState } from 'react';
import {
  HardHat,
  Plus,
  Search,
  MapPin,
  Building2,
  Calendar,
  Edit,
  Trash2,
  CheckCircle2,
  Eye,
  X,
  Briefcase
} from 'lucide-react';
import { Chantier, Client, Project } from '../types';
import { ALGERIAN_WILAYAS } from '../data/algeriaData';

interface ChantiersViewProps {
  chantiers: Chantier[];
  clients: Client[];
  projects?: Project[];
  onSaveChantier: (chantier: Chantier) => void;
  onDeleteChantier: (id: string) => void;
}

export const ChantiersView: React.FC<ChantiersViewProps> = ({
  chantiers,
  clients,
  projects = [],
  onSaveChantier,
  onDeleteChantier
}) => {
  const [search, setSearch] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [selectedChantierDetail, setSelectedChantierDetail] = useState<Chantier | null>(null);
  const [formData, setFormData] = useState<Partial<Chantier>>({});

  const handleStartNew = () => {
    const defaultClient = clients[0];
    const defaultProject = projects[0];
    setFormData({
      id: 'cht-' + Date.now(),
      name: '',
      clientId: defaultClient ? defaultClient.id : '',
      clientName: defaultClient ? defaultClient.name : '',
      projectId: defaultProject ? defaultProject.id : undefined,
      projectName: defaultProject ? defaultProject.name : undefined,
      wilaya: '16 - Alger',
      commune: '',
      locationDescription: '',
      contactPerson: '',
      status: 'ACTIF',
      notes: '',
      createdAt: new Date().toISOString().split('T')[0]
    });
    setIsEditing(true);
    setSelectedChantierDetail(null);
  };

  const handleEdit = (ch: Chantier) => {
    setFormData({ ...ch });
    setIsEditing(true);
    setSelectedChantierDetail(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name?.trim() || !formData.clientId) {
      alert('Veuillez renseigner la désignation du chantier et sélectionner le client / organisme associé.');
      return;
    }

    const client = clients.find(c => c.id === formData.clientId);
    const project = projects.find(p => p.id === formData.projectId);

    const complete: Chantier = {
      id: formData.id || 'cht-' + Date.now(),
      name: formData.name.trim(),
      clientId: formData.clientId,
      clientName: client ? client.name : formData.clientName || '',
      projectId: formData.projectId || undefined,
      projectName: project ? project.name : formData.projectName || undefined,
      wilaya: formData.wilaya || '16 - Alger',
      commune: formData.commune?.trim() || '',
      locationDescription: formData.locationDescription?.trim() || '',
      contactPerson: formData.contactPerson?.trim() || '',
      status: formData.status as any || 'ACTIF',
      notes: formData.notes?.trim() || '',
      createdAt: formData.createdAt || new Date().toISOString().split('T')[0]
    };

    onSaveChantier(complete);
    setIsEditing(false);
  };

  const filtered = chantiers.filter(ch => {
    const q = search.toLowerCase();
    return (
      ch.name.toLowerCase().includes(q) ||
      ch.clientName?.toLowerCase().includes(q) ||
      ch.projectName?.toLowerCase().includes(q) ||
      ch.wilaya.toLowerCase().includes(q) ||
      (ch.commune && ch.commune.toLowerCase().includes(q)) ||
      (ch.contactPerson && ch.contactPerson.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Chantiers & Sites de Travaux Publics
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold">
              {chantiers.length} sites actifs
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Localisation géographique des ouvrages d'art, voiries, terrassements et bâtiments sous contrôle de conformité.
          </p>
        </div>

        <button
          onClick={handleStartNew}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer min-h-[44px]"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau Chantier</span>
        </button>
      </div>

      {isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
            <h3 className="font-bold text-slate-900 text-base font-tech">
              {formData.id && chantiers.some(c => c.id === formData.id) ? 'Modifier le Chantier' : 'Nouveau Chantier'}
            </h3>
            <button
              onClick={() => setIsEditing(false)}
              className="text-slate-400 hover:text-slate-700 text-xs px-2.5 py-1 rounded bg-slate-100 cursor-pointer min-h-[36px]"
            >
              Annuler
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-medium mb-1">
                  Nom / Désignation du Chantier <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: Tronçon RN 01 - PK 45+200 à 62+000"
                  value={formData.name || ''}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:bg-white focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Client / Entreprise Responsable <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={formData.clientId || ''}
                  onChange={e => {
                    const c = clients.find(cl => cl.id === e.target.value);
                    setFormData({
                      ...formData,
                      clientId: e.target.value,
                      clientName: c ? c.name : ''
                    });
                  }}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  <option value="">Sélectionner un client...</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              {projects.length > 0 && (
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Projet de Génie Civil Lié (Optionnel)
                  </label>
                  <select
                    value={formData.projectId || ''}
                    onChange={e => {
                      const p = projects.find(pr => pr.id === e.target.value);
                      setFormData({
                        ...formData,
                        projectId: e.target.value || undefined,
                        projectName: p ? p.name : undefined
                      });
                    }}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                  >
                    <option value="">Aucun projet lié</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.projectNumber} - {p.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Wilaya (Algérie)
                </label>
                <select
                  value={formData.wilaya || '16 - Alger'}
                  onChange={e => setFormData({ ...formData, wilaya: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  {ALGERIAN_WILAYAS.map(w => {
                    const str = `${w.code} - ${w.name}`;
                    return (
                      <option key={w.code} value={str}>
                        {str}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Commune / Localité
                </label>
                <input
                  type="text"
                  placeholder="ex: Blida, Boufarik..."
                  value={formData.commune || ''}
                  onChange={e => setFormData({ ...formData, commune: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Conducteur de Travaux / Contact Chantier
                </label>
                <input
                  type="text"
                  placeholder="Nom & Téléphone de contact"
                  value={formData.contactPerson || ''}
                  onChange={e => setFormData({ ...formData, contactPerson: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Statut du Chantier
                </label>
                <select
                  value={formData.status || 'ACTIF'}
                  onChange={e => setFormData({ ...formData, status: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  <option value="ACTIF">En cours (Actif)</option>
                  <option value="SUSPENDU">Arrêt temporaire / Intempéries</option>
                  <option value="ACHEVE">Travaux Achevés</option>
                  <option value="RECEPTIONNE">Réceptionné (Définitif)</option>
                </select>
              </div>

              <div className="sm:col-span-3">
                <label className="block text-slate-700 font-medium mb-1">
                  Repères d'accès & Description du site
                </label>
                <input
                  type="text"
                  placeholder="Points kilométriques, accès voie rapide, centrale à béton installée sur site..."
                  value={formData.locationDescription || ''}
                  onChange={e => setFormData({ ...formData, locationDescription: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-slate-700 font-medium mb-1">
                  Observations / Prescriptions
                </label>
                <textarea
                  rows={2}
                  placeholder="Cadence de coulage, nature du sol, contraintes de circulation..."
                  value={formData.notes || ''}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold cursor-pointer min-h-[44px]"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer min-h-[44px]"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Enregistrer le Chantier</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Details View Modal */}
      {selectedChantierDetail && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-emerald-100 text-emerald-800">
                  {selectedChantierDetail.status || 'ACTIF'}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1 font-tech">
                  {selectedChantierDetail.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedChantierDetail(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs text-slate-700">
              <div>
                <span className="font-semibold text-slate-500">Client / Entreprise : </span>
                <span className="font-semibold text-slate-900">{selectedChantierDetail.clientName || '—'}</span>
              </div>
              {selectedChantierDetail.projectName && (
                <div>
                  <span className="font-semibold text-slate-500">Projet associé : </span>
                  <span className="font-medium text-slate-900">{selectedChantierDetail.projectName}</span>
                </div>
              )}
              <div>
                <span className="font-semibold text-slate-500">Localisation : </span>
                <span className="text-slate-900">{selectedChantierDetail.wilaya} {selectedChantierDetail.commune ? `(${selectedChantierDetail.commune})` : ''}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500">Conducteur de Travaux : </span>
                <span className="text-slate-900">{selectedChantierDetail.contactPerson || '—'}</span>
              </div>
              {selectedChantierDetail.locationDescription && (
                <div>
                  <span className="font-semibold text-slate-500">Description du site : </span>
                  <p className="text-slate-700 mt-0.5">{selectedChantierDetail.locationDescription}</p>
                </div>
              )}
              {selectedChantierDetail.notes && (
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="font-semibold text-slate-700 mb-0.5">Observations / Prescriptions :</div>
                  <p className="text-slate-600 leading-relaxed">{selectedChantierDetail.notes}</p>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
              <button
                onClick={() => {
                  handleEdit(selectedChantierDetail);
                  setSelectedChantierDetail(null);
                }}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold cursor-pointer"
              >
                Modifier ce chantier
              </button>
              <button
                onClick={() => setSelectedChantierDetail(null)}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main List */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher par nom de chantier, client, wilaya..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white"
            />
          </div>
        </div>

        {/* Mobile View: Cards */}
        <div className="md:hidden divide-y divide-slate-100">
          {filtered.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              Aucun chantier ne correspond à votre recherche.
            </div>
          ) : (
            filtered.map(ch => (
              <div key={ch.id} className="p-4 space-y-2.5">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm font-tech">{ch.name}</h4>
                    <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-emerald-100 text-emerald-800 mt-1 inline-block">
                      {ch.status || 'ACTIF'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setSelectedChantierDetail(ch)}
                      title="Détails"
                      className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleEdit(ch)}
                      title="Modifier"
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer le chantier ${ch.name} ?`)) {
                          onDeleteChantier(ch.id);
                        }
                      }}
                      title="Supprimer"
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="text-xs text-slate-600 space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                    <Building2 className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                    <span>{ch.clientName}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-600">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                    <span>{ch.wilaya} {ch.commune ? `• ${ch.commune}` : ''}</span>
                  </div>
                  {ch.contactPerson && (
                    <div className="text-[11px] text-slate-500">
                      Contact : {ch.contactPerson}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Desktop View: Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Désignation du Chantier</th>
                <th className="p-3">Client Associé</th>
                <th className="p-3">Wilaya & Commune</th>
                <th className="p-3">Conducteur de Travaux</th>
                <th className="p-3">Statut</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-500">
                    Aucun chantier enregistré ou correspondant à la recherche.
                  </td>
                </tr>
              ) : (
                filtered.map(ch => (
                  <tr key={ch.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 font-semibold text-slate-900">
                      {ch.name}
                      {ch.locationDescription && (
                        <div className="text-[11px] text-slate-400 font-normal">{ch.locationDescription}</div>
                      )}
                    </td>
                    <td className="p-3 text-slate-700">
                      {ch.clientName}
                    </td>
                    <td className="p-3">
                      <div className="font-medium text-slate-800">{ch.wilaya}</div>
                      <div className="text-[11px] text-slate-500">{ch.commune || '—'}</div>
                    </td>
                    <td className="p-3 text-slate-600">
                      {ch.contactPerson || '—'}
                    </td>
                    <td className="p-3">
                      <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-emerald-100 text-emerald-800">
                        {ch.status || 'ACTIF'}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setSelectedChantierDetail(ch)}
                          title="Consulter"
                          className="p-1.5 hover:bg-slate-100 text-slate-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEdit(ch)}
                          title="Modifier"
                          className="p-1.5 hover:bg-slate-100 text-blue-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Supprimer le chantier ${ch.name} ?`)) {
                              onDeleteChantier(ch.id);
                            }
                          }}
                          title="Supprimer"
                          className="p-1.5 hover:bg-red-50 text-red-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

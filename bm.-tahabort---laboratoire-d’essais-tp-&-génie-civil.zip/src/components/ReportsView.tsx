import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Search,
  Printer,
  Trash2,
  Eye,
  Edit,
  CheckCircle2,
  Calendar,
  Building2,
  HardHat,
  FileSpreadsheet,
  Shield
} from 'lucide-react';
import { LabReport, Project, Client, LabSettings } from '../types';
import { exportLabReportToExcel, exportReportsListToExcel } from '../utils/excelExport';
import { PrintPreviewModal } from './PrintPreviewModal';

interface ReportsViewProps {
  reports: LabReport[];
  projects: Project[];
  clients: Client[];
  settings?: LabSettings;
  onSaveReport: (report: LabReport) => void;
  onDeleteReport: (id: string) => void;
  getNextReportNumber: () => string;
  initialCreateTrigger?: boolean;
  onResetCreateTrigger?: () => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  reports,
  projects,
  clients,
  settings,
  onSaveReport,
  onDeleteReport,
  getNextReportNumber,
  initialCreateTrigger,
  onResetCreateTrigger
}) => {
  const [search, setSearch] = useState('');
  const [selectedReport, setSelectedReport] = useState<LabReport | null>(null);
  const [previewModalReport, setPreviewModalReport] = useState<LabReport | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<LabReport>>({});

  React.useEffect(() => {
    if (initialCreateTrigger) {
      handleStartNew();
      if (onResetCreateTrigger) onResetCreateTrigger();
    }
  }, [initialCreateTrigger]);

  const handleStartNew = () => {
    const today = new Date().toISOString().split('T')[0];
    const defaultProj = projects[0];

    setFormData({
      id: 'rep-' + Date.now(),
      reportNumber: getNextReportNumber(),
      title: 'Procès-Verbal d’Essais & Contrôle de Conformité',
      projectId: defaultProj ? defaultProj.id : '',
      projectName: defaultProj ? defaultProj.name : '',
      clientId: defaultProj ? defaultProj.clientId : '',
      clientName: defaultProj ? defaultProj.clientName : '',
      type: 'RAPPORT_ESSAI',
      date: today,
      preparedBy: settings?.technicianName || 'Technicien Supérieur Laboratoire',
      approvedBy: settings?.directorName || 'Directeur Technique (Ing. B. Mourad)',
      directorName: settings?.directorName || 'Directeur Technique (Ing. B. Mourad)',
      technicianName: settings?.technicianName || 'Technicien Supérieur Laboratoire',
      qualityManagerName: settings?.qualityManagerName || 'Responsable Assurance Qualité',
      status: 'VALIDE',
      contentSummary: 'Synthèse des essais géotechniques, granulats ou béton réalisés au laboratoire selon les normes algériennes et européennes (NA/NF EN).',
      conclusion: 'Les résultats d’essais consignés dans le présent rapport sont conformes aux spécifications techniques et aux normes contractuelles applicables.',
      createdAt: today
    });
    setIsEditing(true);
    setSelectedReport(null);
  };

  const handleEdit = (rep: LabReport) => {
    setFormData({
      ...rep,
      technicianName: rep.technicianName || rep.preparedBy || settings?.technicianName,
      directorName: rep.directorName || rep.approvedBy || settings?.directorName,
      qualityManagerName: rep.qualityManagerName || settings?.qualityManagerName
    });
    setIsEditing(true);
    setSelectedReport(null);
  };

  const handleView = (rep: LabReport) => {
    setSelectedReport(rep);
    setIsEditing(false);
  };

  const handlePrint = (rep: LabReport) => {
    setPreviewModalReport(rep);
  };

  const renderReportDocument = (rep: LabReport, isModal: boolean = false) => {
    return (
      <div className={`space-y-6 ${isModal ? 'p-6 bg-white text-slate-900 max-w-4xl mx-auto' : ''}`}>
        <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded bg-slate-900 text-teal-400 font-tech font-bold flex items-center justify-center text-sm border-2 border-teal-600">
              BM
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900 font-tech">
                {settings?.labName || 'BM. TAHABORT'}
              </h1>
              <p className="text-[11px] text-slate-700 font-semibold">
                Laboratoire d’Essais de Travaux Publics & Génie Civil
              </p>
              <p className="text-[10px] text-slate-500">
                {settings?.address || 'Zone Industrielle, Alger'} • NIF: {settings?.nif || '001916012345678'} • RC: {settings?.rc || '16/00-1234567B19'}
              </p>
            </div>
          </div>

          <div className="text-right">
            <div className="text-xs font-bold text-teal-900 font-mono">
              {rep.reportNumber}
            </div>
            <div className="text-[10px] text-slate-500">
              Date : {rep.date}
            </div>
            <div className="text-[10px] font-bold text-teal-800 uppercase">
              Document Technique Officiel
            </div>
          </div>
        </div>

        <div className="text-center py-2 bg-slate-100 rounded border border-slate-200">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
            {rep.title}
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-4 text-xs">
          <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
            <div>Projet : <strong>{rep.projectName}</strong></div>
            <div>Client : <strong>{rep.clientName}</strong></div>
          </div>

          <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
            <div>Type de Document : <strong>{rep.type}</strong></div>
            <div>Statut : <strong>{rep.status}</strong></div>
          </div>
        </div>

        <div className="text-xs space-y-4">
          <div className="p-3 bg-slate-50 rounded border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-1">Synthèse des Travaux de Contrôle :</h3>
            <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">
              {rep.contentSummary || 'Contrôles effectués selon les protocoles normalisés en vigueur.'}
            </p>
          </div>

          <div className="p-3 bg-teal-50/60 rounded border border-teal-200">
            <h3 className="font-bold text-teal-950 mb-1">Conclusion & Avis Technique :</h3>
            <p className="text-teal-900 font-medium leading-relaxed">
              {rep.conclusion || 'Matériaux déclarés conformes aux exigences du cahier des charges.'}
            </p>
          </div>
        </div>

        {/* Official Signatories Snapshot */}
        <div className="grid grid-cols-2 gap-8 pt-6 border-t border-slate-200 text-xs">
          <div>
            <div className="font-semibold text-slate-800">Rédigé par (Technicien) :</div>
            <div className="text-slate-600 mt-1 font-medium">
              {rep.technicianName || rep.preparedBy || settings?.technicianName || 'Technicien Laboratoire'}
            </div>
            <div className="h-16"></div>
            <div className="border-t border-slate-300 pt-1 text-[10px] text-slate-400">Signature</div>
          </div>

          <div className="text-right">
            <div className="font-semibold text-slate-800">Le Directeur Technique / Chef de Laboratoire :</div>
            <div className="text-slate-600 mt-1 font-bold">
              {rep.directorName || rep.approvedBy || settings?.directorName || 'Ing. B. Mourad'}
            </div>
            <div className="h-16"></div>
            <div className="border-t border-slate-300 pt-1 text-[10px] text-slate-400">Cachet & Signature Officielle</div>
          </div>
        </div>
      </div>
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.reportNumber || !formData.projectId) {
      alert('Veuillez renseigner le numéro de rapport et sélectionner un projet.');
      return;
    }

    const report: LabReport = {
      id: formData.id || 'rep-' + Date.now(),
      reportNumber: formData.reportNumber,
      title: formData.title || 'Procès-Verbal d’Essais',
      projectId: formData.projectId,
      projectName: formData.projectName || '',
      clientId: formData.clientId || '',
      clientName: formData.clientName || '',
      type: formData.type || 'RAPPORT_ESSAI',
      date: formData.date || new Date().toISOString().split('T')[0],
      preparedBy: formData.technicianName || formData.preparedBy || settings?.technicianName || 'Technicien',
      approvedBy: formData.directorName || formData.approvedBy || settings?.directorName || 'Directeur Technique',
      directorName: formData.directorName || settings?.directorName || 'Directeur Technique',
      technicianName: formData.technicianName || settings?.technicianName || 'Technicien',
      qualityManagerName: formData.qualityManagerName || settings?.qualityManagerName,
      status: formData.status || 'VALIDE',
      contentSummary: formData.contentSummary || '',
      conclusion: formData.conclusion || '',
      createdAt: formData.createdAt || new Date().toISOString().split('T')[0]
    };

    onSaveReport(report);
    setIsEditing(false);
    setSelectedReport(report);
  };

  const filtered = reports.filter(r => {
    const q = search.toLowerCase();
    return (
      r.reportNumber.toLowerCase().includes(q) ||
      r.title.toLowerCase().includes(q) ||
      (r.projectName && r.projectName.toLowerCase().includes(q)) ||
      (r.clientName && r.clientName.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4 no-print">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Rapports Techniques & PV d’Essais Officiels
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 font-semibold">
              Conformité Travaux Publics
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Dossiers d’essais, procès-verbaux de contrôle qualité, fiches de prélèvement et bilans récapitulatifs certifiés avec export direct Excel (.xls).
          </p>
        </div>

        <button
          onClick={handleStartNew}
          className="px-3.5 py-2 bg-teal-700 hover:bg-teal-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau Rapport Technique</span>
        </button>
      </div>

      {/* Editor Modal */}
      {isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6 no-print space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <h3 className="font-bold text-slate-900 text-sm font-tech">
              {formData.id ? 'Éditer le Rapport / PV' : 'Nouveau Rapport / PV d’Essai'}
            </h3>
            <button
              onClick={() => setIsEditing(false)}
              className="text-slate-400 hover:text-slate-700 text-xs px-2.5 py-1 rounded bg-slate-100 cursor-pointer"
            >
              Annuler
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  N° de Rapport <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.reportNumber || ''}
                  onChange={e => setFormData({ ...formData, reportNumber: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-medium mb-1">
                  Intitulé du Rapport <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.title || ''}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-medium text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Projet Rattaché <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={formData.projectId || ''}
                  onChange={e => {
                    const p = projects.find(item => item.id === e.target.value);
                    setFormData({
                      ...formData,
                      projectId: e.target.value,
                      projectName: p ? p.name : '',
                      clientId: p ? p.clientId : '',
                      clientName: p ? p.clientName : ''
                    });
                  }}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  <option value="">Sélectionner un projet...</option>
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.projectNumber} - {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Type de Rapport
                </label>
                <select
                  value={formData.type || 'RAPPORT_ESSAI'}
                  onChange={e => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 font-medium"
                >
                  <option value="PV_ECRASEMENT">PV d'Écrasement Béton (NF EN 12390-3)</option>
                  <option value="FICHE_FORMULATION">Fiche d'Étude de Formulation Béton</option>
                  <option value="RAPPORT_ESSAI">Rapport d'Essais Géotechniques / Granulats</option>
                  <option value="RECAPITULATIF_PROJET">Bilan Récapitulatif Projet</option>
                  <option value="FICHE_PRELEVEMENT">Bordereau de Prélèvement</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Date d'Émission
                </label>
                <input
                  type="date"
                  value={formData.date || ''}
                  onChange={e => setFormData({ ...formData, date: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>
            </div>

            {/* Signatories Snapshot */}
            <div className="p-3 bg-teal-50/50 rounded-lg border border-teal-200 space-y-2">
              <div className="flex items-center gap-1.5 font-bold text-teal-950">
                <Shield className="w-3.5 h-3.5 text-teal-700" />
                <span>Personnel & Signataires Officiels (Archivage Immuable)</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Technicien d'Essais / Rédacteur
                  </label>
                  <input
                    type="text"
                    value={formData.technicianName || ''}
                    onChange={e => setFormData({ ...formData, technicianName: e.target.value, preparedBy: e.target.value })}
                    className="w-full p-1.5 bg-white border border-slate-300 rounded font-medium text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Directeur Technique / Visa d'Approbation
                  </label>
                  <input
                    type="text"
                    value={formData.directorName || ''}
                    onChange={e => setFormData({ ...formData, directorName: e.target.value, approvedBy: e.target.value })}
                    className="w-full p-1.5 bg-white border border-slate-300 rounded font-bold text-slate-900"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Contenu & Synthèse Technique des Résultats
              </label>
              <textarea
                rows={4}
                value={formData.contentSummary || ''}
                onChange={e => setFormData({ ...formData, contentSummary: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-xs text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Conclusion & Avis Technique du Laboratoire
              </label>
              <textarea
                rows={2}
                value={formData.conclusion || ''}
                onChange={e => setFormData({ ...formData, conclusion: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-medium text-slate-900"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-3 py-1.5 border border-slate-300 rounded text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-teal-700 hover:bg-teal-600 text-white rounded font-semibold cursor-pointer"
              >
                Enregistrer le Rapport
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Report View Modal */}
      {selectedReport && !isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3 no-print">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold text-teal-900 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                {selectedReport.reportNumber}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                {selectedReport.type}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* EXCEL EXPORT BUTTON */}
              <button
                onClick={() => exportLabReportToExcel(selectedReport, settings)}
                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                title="Exporter ce rapport en Excel (.xlsx)"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Exporter en Excel</span>
              </button>

              <button
                onClick={() => handlePrint(selectedReport)}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                title="Aperçu avant impression et export PDF"
              >
                <Printer className="w-4 h-4" />
                <span>Aperçu & Impression</span>
              </button>

              <button
                onClick={() => handleEdit(selectedReport)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Edit className="w-4 h-4" />
                <span>Modifier</span>
              </button>

              <button
                onClick={() => setSelectedReport(null)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>

          {/* Document Content */}
          {renderReportDocument(selectedReport, false)}
        </div>
      )}

      {/* Reports Table List */}
      {!isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden no-print">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Rechercher un rapport..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => exportReportsListToExcel(filtered, settings)}
                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                title="Exporter tous les rapports filtrés vers Excel (.xlsx)"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Exporter le Registre Excel</span>
              </button>
              <span className="text-xs text-slate-500">
                {filtered.length} rapport{filtered.length > 1 ? 's' : ''}
              </span>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="p-12 text-center text-xs text-slate-400">
              Aucun rapport technique enregistré.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filtered.map(rep => (
                <div
                  key={rep.id}
                  className="p-3 sm:p-4 hover:bg-slate-50/80 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3"
                >
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className="p-2.5 bg-teal-100 text-teal-800 rounded-lg flex-shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs font-bold text-teal-900 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                          {rep.reportNumber}
                        </span>
                        <span className="text-xs font-bold text-slate-800">
                          {rep.title}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-slate-500">
                        <span>Projet : <strong>{rep.projectName}</strong></span>
                        <span>• Client : {rep.clientName}</span>
                        <span>• Date : {rep.date}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 self-end md:self-center">
                    <button
                      onClick={() => handleView(rep)}
                      title="Consulter"
                      className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => exportLabReportToExcel(rep, settings)}
                      title="Exporter en Excel"
                      className="p-2 text-emerald-700 hover:bg-emerald-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <FileSpreadsheet className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handlePrint(rep)}
                      title="Aperçu & Impression"
                      className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleEdit(rep)}
                      title="Modifier"
                      className="p-2 text-teal-700 hover:bg-teal-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer le rapport ${rep.reportNumber} ?`)) {
                          onDeleteReport(rep.id);
                        }
                      }}
                      title="Supprimer"
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Capacitor-Compatible Print Preview Modal */}
      {previewModalReport && (
        <PrintPreviewModal
          isOpen={!!previewModalReport}
          onClose={() => setPreviewModalReport(null)}
          title={`Rapport Technique ${previewModalReport.reportNumber}`}
          documentSubtitle={`${previewModalReport.title} • ${previewModalReport.projectName || ''}`}
        >
          {renderReportDocument(previewModalReport, true)}
        </PrintPreviewModal>
      )}
    </div>
  );
};

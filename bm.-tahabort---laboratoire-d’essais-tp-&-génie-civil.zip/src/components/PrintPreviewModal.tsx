import React, { useState, useRef } from 'react';
import {
  Printer,
  X,
  Share2,
  FileSpreadsheet,
  Download,
  ZoomIn,
  ZoomOut,
  Maximize2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { safeTriggerPrint, saveExportFile } from '../utils/fileExportUtils';

interface PrintPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  documentNumber?: string;
  documentSubtitle?: string;
  onExportExcel?: () => void;
  children: React.ReactNode;
}

export const PrintPreviewModal: React.FC<PrintPreviewModalProps> = ({
  isOpen,
  onClose,
  title,
  documentNumber,
  documentSubtitle,
  onExportExcel,
  children
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [statusNotice, setStatusNotice] = useState<{ type: 'success' | 'info' | 'error'; text: string } | null>(null);
  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handlePrint = () => {
    setStatusNotice({
      type: 'info',
      text: "Préparation de l'impression... Si vous êtes sur mobile, vous pouvez choisir 'Enregistrer au format PDF'."
    });

    const printDocName = (documentNumber || title || 'Document_BM_TAHABORT').replace(/[/\\?%*:|"<>]/g, '_');
    const result = safeTriggerPrint(printDocName);
    if (!result.success) {
      setStatusNotice({
        type: 'error',
        text: result.message
      });
    } else {
      setTimeout(() => {
        setStatusNotice(null);
      }, 5000);
    }
  };

  const handleShareOrDownloadHtml = async () => {
    if (!printAreaRef.current) return;

    try {
      const docHtml = `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>${title} - ${documentNumber || 'Laboratoire BM. TAHABORT'}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@600;700&family=JetBrains+Mono:wght@400;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
    body {
      font-family: 'Plus Jakarta Sans', Arial, sans-serif;
      background: #f8fafc;
      color: #0f172a;
      margin: 0;
      padding: 20px;
    }
    .print-sheet {
      background: #ffffff;
      max-width: 210mm;
      min-height: 297mm;
      margin: 0 auto;
      padding: 15mm;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
      box-sizing: border-box;
    }
    @media print {
      body {
        background: #ffffff !important;
        padding: 0 !important;
      }
      .print-sheet {
        box-shadow: none !important;
        max-width: 100% !important;
        padding: 0 !important;
      }
      .no-print {
        display: none !important;
      }
      @page {
        size: A4 portrait;
        margin: 10mm;
      }
    }
  </style>
</head>
<body>
  <div class="print-sheet">
    ${printAreaRef.current.innerHTML}
  </div>
  <script>
    // Auto-trigger print when opened standalone if requested
    if (window.location.search.includes('print=true')) {
      window.onload = function() { window.print(); };
    }
  </script>
</body>
</html>`;

      const safeDocName = (documentNumber || title || 'Document').replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `${safeDocName}_BM_TAHABORT.html`;

      const res = await saveExportFile(docHtml, filename, 'text/html');
      setStatusNotice({
        type: res.success ? 'success' : 'error',
        text: res.message
      });
      setTimeout(() => setStatusNotice(null), 5000);
    } catch (e: any) {
      setStatusNotice({
        type: 'error',
        text: "Erreur lors de la génération du document : " + (e?.message || 'Erreur inconnue')
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex flex-col items-center justify-start p-2 sm:p-4">
      {/* Top Floating Control Bar */}
      <div className="sticky top-2 z-50 w-full max-w-5xl bg-white border border-slate-200 rounded-xl shadow-xl px-3 sm:px-5 py-2.5 sm:py-3 mb-3 flex flex-wrap items-center justify-between gap-2.5 no-print">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-2.5 h-2.5 rounded-full bg-teal-600 animate-pulse"></span>
          <div className="min-w-0">
            <h3 className="font-bold text-xs sm:text-sm text-slate-900 truncate font-tech">
              {title}
            </h3>
            <p className="text-[10px] text-slate-500 truncate">
              {documentNumber ? `Réf : ${documentNumber} • ` : ''}
              {documentSubtitle || 'Aperçu normalisé A4 - Laboratoire BM. TAHABORT'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
          {/* Zoom controls (hidden on very small screens) */}
          <div className="hidden md:flex items-center bg-slate-100 rounded-lg p-0.5 text-xs text-slate-700">
            <button
              onClick={() => setZoomLevel(prev => Math.max(70, prev - 10))}
              title="Zoom arrière"
              className="p-1 hover:bg-white rounded cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 font-mono text-[11px] font-semibold">{zoomLevel}%</span>
            <button
              onClick={() => setZoomLevel(prev => Math.min(130, prev + 10))}
              title="Zoom avant"
              className="p-1 hover:bg-white rounded cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(100)}
              title="Réinitialiser zoom"
              className="p-1 hover:bg-white rounded text-[10px] cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Export Excel Button if available */}
          {onExportExcel && (
            <button
              onClick={onExportExcel}
              className="px-2.5 sm:px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              title="Exporter en Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Exporter en Excel</span>
              <span className="sm:hidden">Excel</span>
            </button>
          )}

          {/* Share / Offline HTML button */}
          <button
            onClick={handleShareOrDownloadHtml}
            className="px-2.5 sm:px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Partager ou enregistrer une copie"
          >
            <Share2 className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden sm:inline">Partager / Enregistrer</span>
            <span className="sm:hidden">Partager</span>
          </button>

          {/* Print / PDF Button */}
          <button
            onClick={handlePrint}
            className="px-3 sm:px-3.5 py-1.5 bg-teal-700 hover:bg-teal-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            title="Imprimer ou enregistrer au format PDF"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimer / PDF</span>
          </button>

          {/* Close Button */}
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer ml-1"
            title="Fermer l'aperçu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Status Notice Banner */}
      {statusNotice && (
        <div
          className={`w-full max-w-5xl mb-3 px-4 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-all ${
            statusNotice.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
              : statusNotice.type === 'error'
              ? 'bg-red-50 text-red-800 border border-red-300'
              : 'bg-teal-50 text-teal-800 border border-teal-300'
          }`}
        >
          {statusNotice.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
          )}
          <span className="flex-1">{statusNotice.text}</span>
          <button
            onClick={() => setStatusNotice(null)}
            className="text-slate-400 hover:text-slate-700 p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Scrollable Document Container */}
      <div className="w-full flex-1 overflow-x-auto flex justify-center pb-12">
        <div
          style={{
            transform: zoomLevel !== 100 ? `scale(${zoomLevel / 100})` : undefined,
            transformOrigin: 'top center'
          }}
          className="w-full max-w-4xl transition-transform duration-200"
        >
          <div
            ref={printAreaRef}
            className="bg-white rounded-lg shadow-2xl border border-slate-300 p-4 sm:p-8 md:p-10 text-slate-900 print-container"
          >
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};

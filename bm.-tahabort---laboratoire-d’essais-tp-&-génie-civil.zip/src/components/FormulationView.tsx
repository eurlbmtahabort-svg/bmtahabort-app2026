import React, { useState } from 'react';
import {
  Beaker,
  Plus,
  Search,
  Copy,
  Printer,
  Trash2,
  Edit,
  Eye,
  FileSpreadsheet,
  Calculator,
  Layers,
  ChevronLeft,
  ChevronRight,
  Save,
  CheckCircle2,
  AlertTriangle,
  FolderKanban,
  FileText,
  Shield,
  Clock
} from 'lucide-react';
import { ConcreteFormulation, Project, Client, Chantier, LabSettings, FormulationCustomSection } from '../types';
import { calculateConcreteFormulation } from '../utils/engineeringCalculations';
import { CONCRETE_STRENGTH_CLASSES, SLUMP_CONSISTENCY_CLASSES, CEMENT_TYPES_ALGERIA } from '../data/algeriaData';
import { exportFormulationToExcel, exportFormulationsListToExcel } from '../utils/excelExport';
import { PrintPreviewModal } from './PrintPreviewModal';

interface FormulationViewProps {
  formulations: ConcreteFormulation[];
  projects: Project[];
  clients: Client[];
  chantiers: Chantier[];
  settings?: LabSettings;
  onSave: (formulation: ConcreteFormulation) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
  getNextNumber: () => string;
  initialCreateTrigger?: boolean;
  onResetCreateTrigger?: () => void;
}

type FormulationTabKey = 'project' | 'materials' | 'granulometry' | 'mix' | 'tests' | 'custom_sections';

export const FormulationView: React.FC<FormulationViewProps> = ({
  formulations,
  projects,
  clients,
  chantiers,
  settings,
  onSave,
  onDuplicate,
  onDelete,
  getNextNumber,
  initialCreateTrigger,
  onResetCreateTrigger
}) => {
  const [search, setSearch] = useState('');
  const [selectedFormulation, setSelectedFormulation] = useState<ConcreteFormulation | null>(null);
  const [previewModalForm, setPreviewModalForm] = useState<ConcreteFormulation | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isPrintMode, setIsPrintMode] = useState(false);

  // Active section in multi-page dossier (both edit and view mode)
  const [activeTab, setActiveTab] = useState<FormulationTabKey>('project');
  const [viewTab, setViewTab] = useState<FormulationTabKey>('project');

  // Form State
  const [formData, setFormData] = useState<Partial<ConcreteFormulation>>({});
  const [customSections, setCustomSections] = useState<FormulationCustomSection[]>([]);

  // Trigger from parent if quick action was clicked
  React.useEffect(() => {
    if (initialCreateTrigger) {
      handleStartNew();
      if (onResetCreateTrigger) onResetCreateTrigger();
    }
  }, [initialCreateTrigger]);

  const handleStartNew = () => {
    const newNumber = getNextNumber();
    const today = new Date().toISOString().split('T')[0];
    const defaultProj = projects[0];

    setFormData({
      id: 'form-' + Date.now(),
      formulationNumber: newNumber,
      projectId: defaultProj ? defaultProj.id : '',
      projectName: defaultProj ? defaultProj.name : '',
      clientId: defaultProj ? defaultProj.clientId : '',
      clientName: defaultProj ? defaultProj.clientName : '',
      chantierId: defaultProj ? defaultProj.chantierId : '',
      chantierName: defaultProj ? defaultProj.chantierName : '',
      date: today,
      concreteType: 'Béton armé pour structures courantes',
      strengthClass: 'C25/30',
      consistency: 'S3',
      dMaxMm: 20,
      cementType: 'CPJ-CEM II/A 42.5',
      cementSource: 'Cimenterie Lafarge / GICA',
      sandType: 'Sable 0/4 concassé / alluvionnaire',
      sandSource: 'Carrière locale ou Oued',
      sandEquivalentEs: 78,
      gravelSource: 'Carrière concassée agréée',
      waterSource: 'Réseau public eau potable conforme NF EN 1008',
      cementDosageKg: 350,
      waterLiter: 175,
      wcRatio: 0.5,
      sandKg: 720,
      gravel1Kg: 450,
      gravel2Kg: 680,
      adjuvantType: 'Plastifiant réducteur d’eau',
      adjuvantBrand: 'Sika Plastiment / Granitex',
      adjuvantDosageKg: 2.8,
      theoreticalDensityKgM3: 2375,
      theoreticalVolumeM3: 1.0,
      bolomeyCoeffG: 0.50,
      targetAirPercent: 1.5,
      granulometryCurvesSummary: 'Courbe Dreux-Gorisse ajustée : 40% Sable, 25% Gravillon 3/8, 35% Gravillon 8/15. Point de brisure D/2 = 10 mm.',
      targetSlumpMm: 130,
      measuredSlumpMm: 125,
      targetStrength7jMpa: 20.0,
      measuredStrength7jMpa: 21.4,
      targetStrength14jMpa: 25.5,
      measuredStrength14jMpa: 26.8,
      targetStrength28jMpa: 30.0,
      measuredStrength28jMpa: 32.5,
      observations: 'Formulation optimisée selon la méthode Dreux-Gorisse. Essais de convenance satisfaisants.',
      preparedBy: settings?.technicianName || 'Technicien Supérieur Essais Béton',
      directorName: settings?.directorName || 'Ing. B. Mourad (Directeur Technique)',
      technicianName: settings?.technicianName || 'Technicien Supérieur Essais Béton',
      createdAt: today
    });
    setCustomSections([]);
    setActiveTab('project');
    setIsEditing(true);
    setSelectedFormulation(null);
    setIsPrintMode(false);
  };

  const handleEdit = (form: ConcreteFormulation) => {
    setFormData({ ...form });
    setCustomSections(form.customSections ? [...form.customSections] : []);
    setActiveTab('project');
    setIsEditing(true);
    setSelectedFormulation(null);
    setIsPrintMode(false);
  };

  const handleView = (form: ConcreteFormulation) => {
    setSelectedFormulation(form);
    setViewTab('project');
    setIsEditing(false);
    setIsPrintMode(false);
  };

  const handlePrint = (form: ConcreteFormulation) => {
    setSelectedFormulation(form);
    setPreviewModalForm(form);
  };

  // Recalculate auto properties when constituent inputs change
  const handleConstituentChange = (field: string, value: number) => {
    const updated = { ...formData, [field]: value };
    const cement = field === 'cementDosageKg' ? value : Number(updated.cementDosageKg || 0);
    const water = field === 'waterLiter' ? value : Number(updated.waterLiter || 0);
    const sand = field === 'sandKg' ? value : Number(updated.sandKg || 0);
    const g1 = field === 'gravel1Kg' ? value : Number(updated.gravel1Kg || 0);
    const g2 = field === 'gravel2Kg' ? value : Number(updated.gravel2Kg || 0);
    const adj = field === 'adjuvantDosageKg' ? value : Number(updated.adjuvantDosageKg || 0);

    const calc = calculateConcreteFormulation({
      cementKg: cement,
      waterL: water,
      sandKg: sand,
      gravel1Kg: g1,
      gravel2Kg: g2,
      adjuvantKg: adj
    });

    setFormData({
      ...updated,
      wcRatio: calc.wcRatio,
      theoreticalDensityKgM3: calc.theoreticalDensityKgM3
    });
  };

  // Add a new custom section to the dossier
  const handleAddCustomSection = () => {
    const newSec: FormulationCustomSection = {
      id: 'sec-' + Date.now(),
      title: 'Nouvelle section technique',
      category: 'MATERIAUX',
      content: '',
      dateRealized: new Date().toISOString().split('T')[0],
      technician: formData.technicianName || settings?.technicianName || ''
    };
    setCustomSections([...customSections, newSec]);
  };

  const handleRemoveCustomSection = (id: string) => {
    setCustomSections(customSections.filter(s => s.id !== id));
  };

  const handleUpdateCustomSection = (id: string, updates: Partial<FormulationCustomSection>) => {
    setCustomSections(customSections.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.formulationNumber || !formData.projectId) {
      alert('Veuillez remplir au minimum le numéro de formulation et associer un projet.');
      return;
    }

    const formulation: ConcreteFormulation = {
      id: formData.id || 'form-' + Date.now(),
      formulationNumber: formData.formulationNumber,
      projectId: formData.projectId,
      projectName: formData.projectName || '',
      clientId: formData.clientId || '',
      clientName: formData.clientName || '',
      chantierId: formData.chantierId,
      chantierName: formData.chantierName,
      date: formData.date || new Date().toISOString().split('T')[0],
      concreteType: formData.concreteType || 'Béton normalisé',
      strengthClass: formData.strengthClass || 'C25/30',
      consistency: formData.consistency || 'S3',
      dMaxMm: Number(formData.dMaxMm || 20),
      cementType: formData.cementType || 'CPJ-CEM II/A 42.5',
      cementSource: formData.cementSource,
      sandType: formData.sandType,
      sandSource: formData.sandSource,
      sandEquivalentEs: formData.sandEquivalentEs ? Number(formData.sandEquivalentEs) : undefined,
      gravelSource: formData.gravelSource,
      waterSource: formData.waterSource,
      adjuvantType: formData.adjuvantType,
      adjuvantBrand: formData.adjuvantBrand,
      adjuvantDosageKg: Number(formData.adjuvantDosageKg || 0),
      waterLiter: Number(formData.waterLiter || 175),
      cementDosageKg: Number(formData.cementDosageKg || 350),
      wcRatio: Number(formData.wcRatio || 0.5),
      sandKg: Number(formData.sandKg || 720),
      gravel1Kg: Number(formData.gravel1Kg || 450),
      gravel2Kg: Number(formData.gravel2Kg || 0),
      theoreticalDensityKgM3: Number(formData.theoreticalDensityKgM3 || 2375),
      theoreticalVolumeM3: 1.0,
      bolomeyCoeffG: formData.bolomeyCoeffG ? Number(formData.bolomeyCoeffG) : undefined,
      targetAirPercent: formData.targetAirPercent ? Number(formData.targetAirPercent) : undefined,
      granulometryCurvesSummary: formData.granulometryCurvesSummary,
      targetSlumpMm: Number(formData.targetSlumpMm || 130),
      measuredSlumpMm: formData.measuredSlumpMm !== undefined && formData.measuredSlumpMm !== null ? Number(formData.measuredSlumpMm) : undefined,
      targetStrength7jMpa: formData.targetStrength7jMpa ? Number(formData.targetStrength7jMpa) : undefined,
      measuredStrength7jMpa: formData.measuredStrength7jMpa ? Number(formData.measuredStrength7jMpa) : undefined,
      targetStrength14jMpa: formData.targetStrength14jMpa ? Number(formData.targetStrength14jMpa) : undefined,
      measuredStrength14jMpa: formData.measuredStrength14jMpa ? Number(formData.measuredStrength14jMpa) : undefined,
      targetStrength28jMpa: formData.targetStrength28jMpa ? Number(formData.targetStrength28jMpa) : undefined,
      measuredStrength28jMpa: formData.measuredStrength28jMpa ? Number(formData.measuredStrength28jMpa) : undefined,
      customSections: customSections,
      observations: formData.observations || '',
      preparedBy: formData.preparedBy || formData.technicianName || settings?.technicianName || 'Technicien Béton',
      directorName: formData.directorName || settings?.directorName || 'Ing. B. Mourad',
      technicianName: formData.technicianName || settings?.technicianName || 'Technicien Béton',
      createdAt: formData.createdAt || new Date().toISOString().split('T')[0]
    };

    onSave(formulation);
    setIsEditing(false);
    setSelectedFormulation(formulation);
  };

  const filtered = formulations.filter(f => {
    const q = search.toLowerCase();
    return (
      f.formulationNumber.toLowerCase().includes(q) ||
      (f.projectName && f.projectName.toLowerCase().includes(q)) ||
      (f.clientName && f.clientName.toLowerCase().includes(q)) ||
      (f.concreteType && f.concreteType.toLowerCase().includes(q)) ||
      (f.strengthClass && f.strengthClass.toLowerCase().includes(q))
    );
  });

  const dossierTabs: Array<{ id: FormulationTabKey; label: string; number: string }> = [
    { id: 'project', label: 'Projet & Spécifications', number: '1' },
    { id: 'materials', label: 'Matériaux & Provenances', number: '2' },
    { id: 'granulometry', label: 'Granulométrie & Dreux', number: '3' },
    { id: 'mix', label: 'Dosages & Proportions (1 m³)', number: '4' },
    { id: 'tests', label: 'Résultats d’Essais (7j, 14j, 28j)', number: '5' },
    { id: 'custom_sections', label: 'Annexes & Signatures', number: '6' }
  ];

  const navigateTab = (direction: 'prev' | 'next', current: FormulationTabKey, setTab: (k: FormulationTabKey) => void) => {
    const index = dossierTabs.findIndex(t => t.id === current);
    if (direction === 'prev' && index > 0) {
      setTab(dossierTabs[index - 1].id);
    } else if (direction === 'next' && index < dossierTabs.length - 1) {
      setTab(dossierTabs[index + 1].id);
    }
  };

  const renderFormulationDossier = (form: ConcreteFormulation, showAll: boolean) => (
    <div className="space-y-6 text-slate-800">
      {/* Laboratory Header */}
      <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded bg-slate-900 text-teal-400 font-tech font-bold flex items-center justify-center text-base border-2 border-teal-600">
            BM
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-slate-900 font-tech">
              {settings?.labName || 'BM. TAHABORT'}
            </h1>
            <p className="text-[11px] text-slate-700 font-semibold">
              {settings?.subName || 'Laboratoire d’Essais de Travaux Publics & Génie Civil'}
            </p>
            <p className="text-[10px] text-slate-500">
              {settings?.address || 'Zone Industrielle, Alger'} • NIF: {settings?.nif || '001916012345678'} • RC: {settings?.rc || '16/00-1234567B19'}
            </p>
          </div>
        </div>

        <div className="text-right">
          <div className="text-xs font-bold text-teal-900 font-mono">
            {form.formulationNumber}
          </div>
          <div className="text-[10px] text-slate-500">
            Date d'émission : <strong>{form.date}</strong>
          </div>
          <div className="text-[10px] font-bold text-teal-800 uppercase">
            Dossier d'Étude de Formulation
          </div>
        </div>
      </div>

      {/* Sub-view rendering based on viewTab or showAll */}
      {(showAll || viewTab === 'project') && (
        <div className="space-y-4">
          <div className="text-center py-2 bg-slate-100 rounded border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide font-tech">
              Section 1 : Renseignements & Cahier des Charges
            </h2>
          </div>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
              <div className="text-[10px] uppercase font-bold text-slate-400">Projet & Chantier</div>
              <div>Projet : <strong>{form.projectName}</strong></div>
              <div>Chantier : <strong>{form.chantierName || 'Non spécifié'}</strong></div>
              <div>Client / Maître d'Ouvrage : <strong>{form.clientName || 'N/A'}</strong></div>
            </div>

            <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
              <div className="text-[10px] uppercase font-bold text-slate-400">Exigences Prescrites</div>
              <div>Type de béton : <strong>{form.concreteType}</strong></div>
              <div>Classe de résistance : <strong>{form.strengthClass}</strong></div>
              <div>Classe de consistance : <strong>{form.consistency}</strong></div>
              <div>Diamètre maximal (Dmax) : <strong>{form.dMaxMm} mm</strong></div>
            </div>
          </div>
        </div>
      )}

      {(showAll || viewTab === 'materials') && (
        <div className="space-y-4">
          <div className="text-center py-2 bg-slate-100 rounded border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide font-tech">
              Section 2 : Identification & Provenances des Matériaux
            </h2>
          </div>
          <table className="w-full text-xs border border-slate-300 text-left">
            <thead className="bg-slate-100 text-slate-700 border-b border-slate-300 font-semibold">
              <tr>
                <th className="p-2 border-r border-slate-300">Constituant</th>
                <th className="p-2 border-r border-slate-300">Désignation / Spécification</th>
                <th className="p-2 border-r border-slate-300">Origine / Carrière / Fournisseur</th>
                <th className="p-2 text-right">Caractéristique Remarquable</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Ciment</td>
                <td className="p-2 border-r border-slate-200">{form.cementType}</td>
                <td className="p-2 border-r border-slate-200">{form.cementSource || 'Usine agréée'}</td>
                <td className="p-2 text-right font-mono">Classe 42.5</td>
              </tr>
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Sable</td>
                <td className="p-2 border-r border-slate-200">{form.sandType || 'Sable 0/4'}</td>
                <td className="p-2 border-r border-slate-200">{form.sandSource || 'Carrière / Oued'}</td>
                <td className="p-2 text-right font-mono">ES = {form.sandEquivalentEs || 78} %</td>
              </tr>
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Gravillons G1 & G2</td>
                <td className="p-2 border-r border-slate-200">Concassé calcaire normalisé</td>
                <td className="p-2 border-r border-slate-200">{form.gravelSource || 'Carrière agréée'}</td>
                <td className="p-2 text-right font-mono">Dmax = {form.dMaxMm} mm</td>
              </tr>
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Eau de gâchage</td>
                <td className="p-2 border-r border-slate-200">Eau propre de réseau</td>
                <td className="p-2 border-r border-slate-200">{form.waterSource || 'Réseau AEP'}</td>
                <td className="p-2 text-right font-mono">NF EN 1008</td>
              </tr>
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Adjuvant</td>
                <td className="p-2 border-r border-slate-200">{form.adjuvantType || 'Plastifiant'}</td>
                <td className="p-2 border-r border-slate-200">{form.adjuvantBrand || 'Normalisé'}</td>
                <td className="p-2 text-right font-mono">{form.adjuvantDosageKg} kg/m³</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {(showAll || viewTab === 'granulometry') && (
        <div className="space-y-4">
          <div className="text-center py-2 bg-slate-100 rounded border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide font-tech">
              Section 3 : Analyse Granulométrique & Méthode Dreux-Gorisse
            </h2>
          </div>
          <div className="grid grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded border border-slate-200 text-center">
              <span className="text-[10px] text-slate-500 block uppercase">Coefficient Granulaire (G)</span>
              <span className="font-mono font-bold text-sm text-slate-900">{form.bolomeyCoeffG || 0.50}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded border border-slate-200 text-center">
              <span className="text-[10px] text-slate-500 block uppercase">Air Occlus Estimé</span>
              <span className="font-mono font-bold text-sm text-slate-900">{form.targetAirPercent || 1.5} %</span>
            </div>
            <div className="p-3 bg-slate-50 rounded border border-slate-200 text-center">
              <span className="text-[10px] text-slate-500 block uppercase">Point de Brisure Théorique</span>
              <span className="font-mono font-bold text-sm text-slate-900">{(form.dMaxMm / 2).toFixed(1)} mm</span>
            </div>
          </div>
          <div className="p-3 bg-slate-50 rounded border border-slate-200 text-xs">
            <span className="font-bold text-slate-800 block mb-1">Résumé des Courbes Granulométriques :</span>
            <p className="font-mono text-slate-700 whitespace-pre-wrap">
              {form.granulometryCurvesSummary || 'Non spécifié.'}
            </p>
          </div>
        </div>
      )}

      {(showAll || viewTab === 'mix') && (
        <div className="space-y-4">
          <div className="text-center py-2 bg-slate-100 rounded border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide font-tech">
              Section 4 : Composition Théorique & Dosages pour 1 m³
            </h2>
          </div>
          <table className="w-full text-xs border border-slate-300 text-left">
            <thead className="bg-slate-100 text-slate-700 border-b border-slate-300 font-semibold">
              <tr>
                <th className="p-2 border-r border-slate-300">Constituant</th>
                <th className="p-2 border-r border-slate-300">Désignation</th>
                <th className="p-2 border-r border-slate-300 text-right">Dosage (kg/m³)</th>
                <th className="p-2 text-right">Proportion (%)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Ciment</td>
                <td className="p-2 border-r border-slate-200">{form.cementType}</td>
                <td className="p-2 font-mono text-right border-r border-slate-200">{form.cementDosageKg}</td>
                <td className="p-2 font-mono text-right text-slate-500">
                  {((form.cementDosageKg / (form.theoreticalDensityKgM3 || 2400)) * 100).toFixed(1)} %
                </td>
              </tr>
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Eau efficace</td>
                <td className="p-2 border-r border-slate-200">Eau de gâchage</td>
                <td className="p-2 font-mono text-right border-r border-slate-200">{form.waterLiter} L</td>
                <td className="p-2 font-mono text-right text-slate-500">
                  {((form.waterLiter / (form.theoreticalDensityKgM3 || 2400)) * 100).toFixed(1)} %
                </td>
              </tr>
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Sable 0/4</td>
                <td className="p-2 border-r border-slate-200">Sable de concassage / alluvionnaire</td>
                <td className="p-2 font-mono text-right border-r border-slate-200">{form.sandKg}</td>
                <td className="p-2 font-mono text-right text-slate-500">
                  {((form.sandKg / (form.theoreticalDensityKgM3 || 2400)) * 100).toFixed(1)} %
                </td>
              </tr>
              <tr>
                <td className="p-2 font-bold border-r border-slate-200">Gravillon G1</td>
                <td className="p-2 border-r border-slate-200">Granulats concassés</td>
                <td className="p-2 font-mono text-right border-r border-slate-200">{form.gravel1Kg}</td>
                <td className="p-2 font-mono text-right text-slate-500">
                  {((form.gravel1Kg / (form.theoreticalDensityKgM3 || 2400)) * 100).toFixed(1)} %
                </td>
              </tr>
              {form.gravel2Kg && form.gravel2Kg > 0 ? (
                <tr>
                  <td className="p-2 font-bold border-r border-slate-200">Gravillon G2</td>
                  <td className="p-2 border-r border-slate-200">Granulats classe supérieure</td>
                  <td className="p-2 font-mono text-right border-r border-slate-200">{form.gravel2Kg}</td>
                  <td className="p-2 font-mono text-right text-slate-500">
                    {((form.gravel2Kg / (form.theoreticalDensityKgM3 || 2400)) * 100).toFixed(1)} %
                  </td>
                </tr>
              ) : null}
              {form.adjuvantDosageKg && form.adjuvantDosageKg > 0 ? (
                <tr>
                  <td className="p-2 font-bold border-r border-slate-200">Adjuvant</td>
                  <td className="p-2 border-r border-slate-200">{form.adjuvantType || 'Plastifiant'}</td>
                  <td className="p-2 font-mono text-right border-r border-slate-200">{form.adjuvantDosageKg}</td>
                  <td className="p-2 font-mono text-right text-slate-500">
                    {((form.adjuvantDosageKg / (form.theoreticalDensityKgM3 || 2400)) * 100).toFixed(1)} %
                  </td>
                </tr>
              ) : null}
            </tbody>
            <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300">
              <tr>
                <td colSpan={2} className="p-2 border-r border-slate-300">
                  MASSE VOLUMIQUE THÉORIQUE ESTIMÉE DU BÉTON FRAIS :
                </td>
                <td className="p-2 font-mono text-right border-r border-slate-300 text-teal-900">
                  {form.theoreticalDensityKgM3} kg/m³
                </td>
                <td className="p-2 font-mono text-right text-teal-900">
                  100.0 %
                </td>
              </tr>
              <tr className="bg-slate-50 border-t border-slate-200">
                <td colSpan={2} className="p-2 border-r border-slate-300 font-medium text-slate-700">
                  Rapport Eau/Ciment effectif (E/C) :
                </td>
                <td colSpan={2} className="p-2 font-mono text-slate-800 font-semibold">
                  {form.wcRatio}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}

      {(showAll || viewTab === 'tests') && (
        <div className="space-y-4">
          <div className="text-center py-2 bg-slate-100 rounded border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide font-tech">
              Section 5 : Confrontation des Résultats d'Essais (7 jours, 14 jours et 28 jours)
            </h2>
          </div>
          <table className="w-full text-xs border border-slate-300 text-left">
            <thead className="bg-slate-100 text-slate-700 border-b border-slate-300 font-semibold">
              <tr>
                <th className="p-2 border-r border-slate-300">Paramètre d'Essai Contrôlé</th>
                <th className="p-2 border-r border-slate-300 text-right">Valeur Cible (Théorie)</th>
                <th className="p-2 border-r border-slate-300 text-right">Valeur Mesurée (Laboratoire)</th>
                <th className="p-2 text-center">Évaluation de Conformité</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              <tr>
                <td className="p-2 border-r border-slate-200 font-medium">Affaissement au cône d'Abrams</td>
                <td className="p-2 border-r border-slate-200 font-mono text-right">{form.targetSlumpMm} mm</td>
                <td className="p-2 border-r border-slate-200 font-mono text-right font-bold text-slate-900">
                  {form.measuredSlumpMm ? `${form.measuredSlumpMm} mm` : 'En attente'}
                </td>
                <td className="p-2 text-center">
                  <span className="text-emerald-700 font-semibold">Conforme classe {form.consistency}</span>
                </td>
              </tr>

              {/* 7 Jours */}
              <tr>
                <td className="p-2 border-r border-slate-200 font-medium">
                  Résistance à la compression à <strong>7 jours</strong> (Contrôle initial)
                </td>
                <td className="p-2 border-r border-slate-200 font-mono text-right">
                  {form.targetStrength7jMpa ? `${form.targetStrength7jMpa} MPa` : '-'}
                </td>
                <td className="p-2 border-r border-slate-200 font-mono text-right font-bold text-blue-900">
                  {form.measuredStrength7jMpa ? `${form.measuredStrength7jMpa} MPa` : 'En attente'}
                </td>
                <td className="p-2 text-center">
                  {form.measuredStrength7jMpa && form.targetStrength7jMpa ? (
                    form.measuredStrength7jMpa >= form.targetStrength7jMpa ? (
                      <span className="text-emerald-700 font-semibold">Conforme</span>
                    ) : (
                      <span className="text-amber-700 font-semibold">Inférieur</span>
                    )
                  ) : (
                    <span className="text-slate-400 italic">En cure</span>
                  )}
                </td>
              </tr>

              {/* 14 Jours */}
              <tr>
                <td className="p-2 border-r border-slate-200 font-medium">
                  Résistance à la compression à <strong>14 jours</strong> (Contrôle intermédiaire)
                </td>
                <td className="p-2 border-r border-slate-200 font-mono text-right">
                  {form.targetStrength14jMpa ? `${form.targetStrength14jMpa} MPa` : '-'}
                </td>
                <td className="p-2 border-r border-slate-200 font-mono text-right font-bold text-amber-900">
                  {form.measuredStrength14jMpa ? `${form.measuredStrength14jMpa} MPa` : 'En attente'}
                </td>
                <td className="p-2 text-center">
                  {form.measuredStrength14jMpa && form.targetStrength14jMpa ? (
                    form.measuredStrength14jMpa >= form.targetStrength14jMpa ? (
                      <span className="text-emerald-700 font-semibold">Conforme décoffrage</span>
                    ) : (
                      <span className="text-amber-700 font-semibold">Inférieur</span>
                    )
                  ) : (
                    <span className="text-slate-400 italic">En cure</span>
                  )}
                </td>
              </tr>

              {/* 28 Jours */}
              <tr>
                <td className="p-2 border-r border-slate-200 font-medium">
                  Résistance caractéristique à <strong>28 jours</strong> (Contractuelle fck)
                </td>
                <td className="p-2 border-r border-slate-200 font-mono text-right">
                  {form.targetStrength28jMpa ? `${form.targetStrength28jMpa} MPa` : '-'}
                </td>
                <td className="p-2 border-r border-slate-200 font-mono text-right font-bold text-teal-900">
                  {form.measuredStrength28jMpa ? `${form.measuredStrength28jMpa} MPa` : 'En attente'}
                </td>
                <td className="p-2 text-center">
                  {form.measuredStrength28jMpa && form.targetStrength28jMpa ? (
                    form.measuredStrength28jMpa >= form.targetStrength28jMpa ? (
                      <span className="text-emerald-700 font-semibold">Conforme fck ({form.strengthClass})</span>
                    ) : (
                      <span className="text-red-700 font-semibold">Non Conforme</span>
                    )
                  ) : (
                    <span className="text-slate-400 italic">En cure</span>
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {(showAll || viewTab === 'custom_sections') && (
        <div className="space-y-4">
          <div className="text-center py-2 bg-slate-100 rounded border border-slate-200">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide font-tech">
              Section 6 : Annexes & Sections Complémentaires
            </h2>
          </div>

          {form.customSections && form.customSections.length > 0 ? (
            <div className="space-y-3">
              {form.customSections.map(sec => (
                <div key={sec.id} className="p-3 bg-slate-50 rounded border border-slate-200 text-xs">
                  <h4 className="font-bold text-slate-900 mb-1">{sec.title}</h4>
                  <p className="text-slate-700 whitespace-pre-wrap">{sec.content}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400 italic p-3 text-center">
              Aucune annexe supplémentaire dans ce dossier.
            </p>
          )}

          {form.observations && (
            <div className="p-3 bg-slate-50 rounded border border-slate-200 text-xs">
              <span className="font-bold text-slate-800 block mb-1">Observations & Recommandations :</span>
              <p className="text-slate-700">{form.observations}</p>
            </div>
          )}
        </div>
      )}

      {/* Official Signatures (Immutable Snapshot) */}
      <div className="grid grid-cols-2 gap-8 pt-4 border-t border-slate-200 text-xs">
        <div>
          <div className="font-semibold text-slate-800">Le Technicien d'Essais :</div>
          <p className="text-[11px] text-slate-600 mt-1">
            {form.technicianName || form.preparedBy || 'Technicien Supérieur Béton'}
          </p>
          <div className="h-12"></div>
          <div className="text-[10px] text-slate-400 border-t border-slate-300 pt-1">
            Signature & Visa
          </div>
        </div>

        <div className="text-right">
          <div className="font-semibold text-slate-800">Le Directeur Technique :</div>
          <p className="text-[11px] text-slate-600 mt-1">
            {form.directorName || 'Ing. B. Mourad (Directeur Technique)'}
          </p>
          <div className="h-12"></div>
          <div className="text-[10px] text-slate-400 border-t border-slate-300 pt-1">
            Cachet & Signature de Validation
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4 no-print">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-800 border border-teal-200">
              Formulations Béton • Dreux-Gorisse & NF EN 206
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-tech text-slate-900">
            Dossiers d’Études de Formulation de Béton
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Dossier multi-sections complet : identification des granulats, courbes granulométriques, calculs de composition théorique, gâchées d'essais à 7, 14 et 28 jours, et export Excel officiel.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleStartNew}
            className="px-4 py-2 bg-teal-700 hover:bg-teal-600 text-white rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Nouveau Dossier de Formulation</span>
          </button>
        </div>
      </div>

      {/* =========================================================================
          MULTI-SECTION EDITOR MODAL (NO LONGER A SINGLE HUGE PAGE)
          ========================================================================= */}
      {isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-lg p-4 sm:p-6 no-print space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-teal-100 text-teal-800 rounded-lg">
                <Beaker className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-base font-tech">
                  {formData.id ? 'Dossier Technique d’Étude de Formulation' : 'Nouveau Dossier de Formulation'}
                </h3>
                <p className="text-xs text-slate-500 font-mono">
                  {formData.formulationNumber || 'Formulation sans référence'} • Classe {formData.strengthClass}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="text-slate-500 hover:text-slate-800 text-xs px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Fermer sans enregistrer
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                className="px-4 py-1.5 bg-teal-700 hover:bg-teal-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Enregistrer le Dossier</span>
              </button>
            </div>
          </div>

          {/* Dossier Multi-Section Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto border-b border-slate-200 pb-1 scrollbar-thin">
            {dossierTabs.map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`px-3.5 py-2 rounded-t-lg text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-2 cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-teal-50 text-teal-900 border-b-2 border-teal-600 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  activeTab === tab.id ? 'bg-teal-700 text-white' : 'bg-slate-200 text-slate-700'
                }`}>
                  {tab.number}
                </span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-6 pt-2">
            {/* SECTION 1: PROJET & SPECIFICATIONS */}
            {activeTab === 'project' && (
              <div className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900 mb-3 flex items-center gap-2">
                    <FolderKanban className="w-4 h-4 text-teal-700" />
                    <span>1. Renseignements Généraux & Affectation</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        N° Dossier Formulation <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.formulationNumber || ''}
                        onChange={e => setFormData({ ...formData, formulationNumber: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        Date d'étude
                      </label>
                      <input
                        type="date"
                        value={formData.date || ''}
                        onChange={e => setFormData({ ...formData, date: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        Projet rattaché <span className="text-red-500">*</span>
                      </label>
                      <select
                        required
                        value={formData.projectId || ''}
                        onChange={e => {
                          const p = projects.find(item => item.id === e.target.value);
                          setFormData({
                            ...formData,
                            projectId: e.target.value,
                            projectName: p ? p.name : '',
                            clientId: p ? p.clientId : '',
                            clientName: p ? p.clientName : '',
                            chantierId: p ? p.chantierId : '',
                            chantierName: p ? p.chantierName : ''
                          });
                        }}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-800"
                      >
                        <option value="">Sélectionner un projet...</option>
                        {projects.map(p => (
                          <option key={p.id} value={p.id}>
                            {p.projectNumber} - {p.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        Client / Maître d'Ouvrage
                      </label>
                      <input
                        type="text"
                        value={formData.clientName || ''}
                        onChange={e => setFormData({ ...formData, clientName: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-800"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-slate-700 font-medium mb-1">
                        Chantier / Localisation
                      </label>
                      <input
                        type="text"
                        value={formData.chantierName || ''}
                        onChange={e => setFormData({ ...formData, chantierName: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-800"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-slate-700 font-medium mb-1">
                        Désignation de l'ouvrage & Destination
                      </label>
                      <input
                        type="text"
                        placeholder="ex: Voiles, radiers, poteaux et poutres du bâtiment R+9"
                        value={formData.concreteType || ''}
                        onChange={e => setFormData({ ...formData, concreteType: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-800"
                      />
                    </div>
                  </div>
                </div>

                {/* Technical Specifications */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900 mb-3 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-teal-700" />
                    <span>Spécifications & Exigences Normatives (NF EN 206 / NA 437)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        Classe de résistance visée
                      </label>
                      <select
                        value={formData.strengthClass || 'C25/30'}
                        onChange={e => setFormData({ ...formData, strengthClass: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                      >
                        {CONCRETE_STRENGTH_CLASSES.map(c => (
                          <option key={c.code} value={c.code}>
                            {c.code} ({c.desc})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        Classe de consistance
                      </label>
                      <select
                        value={formData.consistency || 'S3'}
                        onChange={e => setFormData({ ...formData, consistency: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg text-slate-800"
                      >
                        {SLUMP_CONSISTENCY_CLASSES.map(s => (
                          <option key={s.code} value={s.code}>
                            {s.code} ({s.range} - {s.label})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        Dmax des granulats (mm)
                      </label>
                      <input
                        type="number"
                        value={formData.dMaxMm || 20}
                        onChange={e => setFormData({ ...formData, dMaxMm: Number(e.target.value) })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono text-slate-800"
                      />
                    </div>
                  </div>
                </div>

                {/* Official Signatories Snapshot */}
                <div className="p-4 bg-teal-50/50 rounded-xl border border-teal-200 space-y-3">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-teal-700" />
                    <span className="text-xs font-bold text-teal-950 uppercase">
                      Signataires Officiels de l’Étude (Intégrité & Traçabilité Métrologique)
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        Technicien / Responsable Formulation
                      </label>
                      <input
                        type="text"
                        value={formData.technicianName || ''}
                        onChange={e => setFormData({ ...formData, technicianName: e.target.value, preparedBy: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-medium text-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 font-medium mb-1">
                        Directeur Technique / Visa d’Approbation
                      </label>
                      <input
                        type="text"
                        value={formData.directorName || ''}
                        onChange={e => setFormData({ ...formData, directorName: e.target.value })}
                        className="w-full p-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 2: MATERIAUX & PROVENANCES */}
            {activeTab === 'materials' && (
              <div className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900 mb-3">
                    2. Identification & Caractéristiques des Matériaux Composants
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
                    {/* Ciment */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-2">
                      <div className="font-bold text-slate-800 flex items-center justify-between">
                        <span>Ciment</span>
                        <span className="text-[10px] text-teal-700 font-mono">Liant</span>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Type & Classe</label>
                        <select
                          value={formData.cementType || ''}
                          onChange={e => setFormData({ ...formData, cementType: e.target.value })}
                          className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded text-xs font-medium"
                        >
                          {CEMENT_TYPES_ALGERIA.map(t => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Cimenterie / Usine de provenance</label>
                        <input
                          type="text"
                          placeholder="ex: Lafarge M'Sila / GICA Meftah"
                          value={formData.cementSource || ''}
                          onChange={e => setFormData({ ...formData, cementSource: e.target.value })}
                          className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded text-xs"
                        />
                      </div>
                    </div>

                    {/* Sable */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-2">
                      <div className="font-bold text-slate-800 flex items-center justify-between">
                        <span>Sable</span>
                        <span className="text-[10px] text-teal-700 font-mono">Granulat fin</span>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Nature / Granulométrie</label>
                        <input
                          type="text"
                          placeholder="ex: Sable 0/4 concassé calcaire"
                          value={formData.sandType || ''}
                          onChange={e => setFormData({ ...formData, sandType: e.target.value })}
                          className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Équivalent de Sable (ES %)</label>
                        <input
                          type="number"
                          placeholder="ex: 78"
                          value={formData.sandEquivalentEs || ''}
                          onChange={e => setFormData({ ...formData, sandEquivalentEs: Number(e.target.value) })}
                          className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded font-mono text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Carrière / Oued de provenance</label>
                        <input
                          type="text"
                          placeholder="ex: Oued Soummam / Carrière Bouira"
                          value={formData.sandSource || ''}
                          onChange={e => setFormData({ ...formData, sandSource: e.target.value })}
                          className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded text-xs"
                        />
                      </div>
                    </div>

                    {/* Gravillons */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-2">
                      <div className="font-bold text-slate-800 flex items-center justify-between">
                        <span>Gravillons G1 & G2</span>
                        <span className="text-[10px] text-teal-700 font-mono">Gros granulats</span>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Carrière de concassage</label>
                        <input
                          type="text"
                          placeholder="ex: Carrière Calcaire Djebel Oust"
                          value={formData.gravelSource || ''}
                          onChange={e => setFormData({ ...formData, gravelSource: e.target.value })}
                          className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-0.5">Eau de gâchage</label>
                        <input
                          type="text"
                          placeholder="ex: Eau potable réseau AEP NF EN 1008"
                          value={formData.waterSource || ''}
                          onChange={e => setFormData({ ...formData, waterSource: e.target.value })}
                          className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded text-xs"
                        />
                      </div>
                    </div>

                    {/* Adjuvant */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-2 sm:col-span-2 lg:col-span-3">
                      <div className="font-bold text-slate-800 flex items-center justify-between">
                        <span>Adjuvant Chimique & Marque Commerciale</span>
                        <span className="text-[10px] text-teal-700 font-mono">Additif NF EN 934-2</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-500 mb-0.5">Fonction d'adjuvant</label>
                          <input
                            type="text"
                            placeholder="ex: Haut réducteur d'eau / Plastifiant"
                            value={formData.adjuvantType || ''}
                            onChange={e => setFormData({ ...formData, adjuvantType: e.target.value })}
                            className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-500 mb-0.5">Fournisseur & Nom commercial</label>
                          <input
                            type="text"
                            placeholder="ex: Sika ViscoCrete / Granitex Medafluid"
                            value={formData.adjuvantBrand || ''}
                            onChange={e => setFormData({ ...formData, adjuvantBrand: e.target.value })}
                            className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 3: GRANULOMETRIE & DREUX-GORISSE */}
            {activeTab === 'granulometry' && (
              <div className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900 mb-3">
                    3. Paramètres de la Méthode Dreux-Gorisse & Granulométrie
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div className="p-3 bg-white rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Coefficient Granulaire (G)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={formData.bolomeyCoeffG || 0.50}
                        onChange={e => setFormData({ ...formData, bolomeyCoeffG: Number(e.target.value) })}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                      />
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        Généralement 0.50 pour gravillons roulés, 0.55 à 0.60 pour concassés.
                      </span>
                    </div>

                    <div className="p-3 bg-white rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Air Occlus Estimé (%)
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        value={formData.targetAirPercent || 1.5}
                        onChange={e => setFormData({ ...formData, targetAirPercent: Number(e.target.value) })}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                      />
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        Volume d'air occlus après vibration (1 à 2% pour béton usuel).
                      </span>
                    </div>

                    <div className="p-3 bg-white rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Point de Brisure Théorique
                      </label>
                      <div className="font-mono text-xs font-bold text-teal-900 p-2 bg-teal-50 rounded border border-teal-200">
                        D / 2 = {(Number(formData.dMaxMm || 20) / 2).toFixed(1)} mm
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        Position de la brisure de la courbe granulaire idéale Dreux.
                      </span>
                    </div>

                    <div className="sm:col-span-3 p-3 bg-white rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Synthèse de la Courbe Granulométrique & Tamisats
                      </label>
                      <textarea
                        rows={3}
                        value={formData.granulometryCurvesSummary || ''}
                        onChange={e => setFormData({ ...formData, granulometryCurvesSummary: e.target.value })}
                        placeholder="Détaillez ici les pourcentages retenus au tamis pour chaque classe de sable et gravillons..."
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-xs text-slate-800 font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 4: DOSAGES & PROPORTIONS AU M³ */}
            {activeTab === 'mix' && (
              <div className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-3 border-b border-slate-200 gap-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900 flex items-center gap-2">
                      <Calculator className="w-4 h-4 text-emerald-600" />
                      <span>4. Dosages Pondéraux des Constituants pour 1 m³ de Béton</span>
                    </h4>
                    <div className="text-xs font-mono bg-emerald-50 text-emerald-900 px-2.5 py-1 rounded border border-emerald-200 font-bold">
                      Densité : {formData.theoreticalDensityKgM3 || 0} kg/m³ • Rapport E/C : {formData.wcRatio || 0}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                    {/* Ciment */}
                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Ciment (kg/m³)
                      </label>
                      <input
                        type="number"
                        value={formData.cementDosageKg || 0}
                        onChange={e => handleConstituentChange('cementDosageKg', Number(e.target.value))}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-sm text-slate-900"
                      />
                    </div>

                    {/* Eau */}
                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Eau efficace (L ou kg/m³)
                      </label>
                      <input
                        type="number"
                        value={formData.waterLiter || 0}
                        onChange={e => handleConstituentChange('waterLiter', Number(e.target.value))}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-sm text-slate-900"
                      />
                    </div>

                    {/* Sable */}
                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Sable 0/4 (kg/m³)
                      </label>
                      <input
                        type="number"
                        value={formData.sandKg || 0}
                        onChange={e => handleConstituentChange('sandKg', Number(e.target.value))}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-sm text-slate-900"
                      />
                    </div>

                    {/* Gravillon 1 */}
                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Gravillon G1 (3/8 ou 8/15) (kg/m³)
                      </label>
                      <input
                        type="number"
                        value={formData.gravel1Kg || 0}
                        onChange={e => handleConstituentChange('gravel1Kg', Number(e.target.value))}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-sm text-slate-900"
                      />
                    </div>

                    {/* Gravillon 2 */}
                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Gravillon G2 (15/25) (kg/m³) (Optionnel)
                      </label>
                      <input
                        type="number"
                        value={formData.gravel2Kg || 0}
                        onChange={e => handleConstituentChange('gravel2Kg', Number(e.target.value))}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-sm text-slate-900"
                      />
                    </div>

                    {/* Adjuvant */}
                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Adjuvant (kg/m³)
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        value={formData.adjuvantDosageKg || 0}
                        onChange={e => handleConstituentChange('adjuvantDosageKg', Number(e.target.value))}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-sm text-slate-900"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 5: GACHEES & RESULTATS (7J, 14J, 28J) - EQUAL PROMINENCE */}
            {activeTab === 'tests' && (
              <div className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-teal-700" />
                      <span>5. Gâchées d'Essais & Résistances aux 3 Âges (7j, 14j, 28j)</span>
                    </h4>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-teal-100 text-teal-800 font-semibold">
                      Statut Équivalent 7j - 14j - 28j
                    </span>
                  </div>

                  {/* Consistency & Slump */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs mb-4">
                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Affaissement au cône d'Abrams Visé (mm)
                      </label>
                      <input
                        type="number"
                        value={formData.targetSlumpMm || 130}
                        onChange={e => setFormData({ ...formData, targetSlumpMm: Number(e.target.value) })}
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                      />
                    </div>

                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <label className="block font-bold text-slate-800 mb-1">
                        Affaissement Mesuré en Gâchée d'Essai (mm)
                      </label>
                      <input
                        type="number"
                        value={formData.measuredSlumpMm ?? ''}
                        onChange={e => setFormData({ ...formData, measuredSlumpMm: e.target.value === '' ? undefined : Number(e.target.value) })}
                        placeholder="Mesuré en laboratoire"
                        className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                      />
                    </div>
                  </div>

                  {/* 3 EQUAL COMPRESSIVE STRENGTH BLOCKS */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    {/* 7 Jours */}
                    <div className="p-3.5 bg-blue-50/60 rounded-xl border border-blue-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-blue-900 uppercase">Échéance à 7 Jours</span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                          Initial
                        </span>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-600 mb-0.5">Résistance Cible (MPa)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={formData.targetStrength7jMpa || ''}
                          onChange={e => setFormData({ ...formData, targetStrength7jMpa: Number(e.target.value) })}
                          className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-600 mb-0.5">Résistance Obtenue (MPa)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={formData.measuredStrength7jMpa ?? ''}
                          onChange={e => setFormData({ ...formData, measuredStrength7jMpa: e.target.value === '' ? undefined : Number(e.target.value) })}
                          placeholder="Écrasé à 7j"
                          className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold text-blue-950"
                        />
                      </div>
                    </div>

                    {/* 14 Jours */}
                    <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-amber-950 uppercase">Échéance à 14 Jours</span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-900">
                          Intermédiaire
                        </span>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-600 mb-0.5">Résistance Cible (MPa)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={formData.targetStrength14jMpa || ''}
                          onChange={e => setFormData({ ...formData, targetStrength14jMpa: Number(e.target.value) })}
                          className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-600 mb-0.5">Résistance Obtenue (MPa)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={formData.measuredStrength14jMpa ?? ''}
                          onChange={e => setFormData({ ...formData, measuredStrength14jMpa: e.target.value === '' ? undefined : Number(e.target.value) })}
                          placeholder="Écrasé à 14j"
                          className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold text-amber-950"
                        />
                      </div>
                    </div>

                    {/* 28 Jours */}
                    <div className="p-3.5 bg-teal-50/60 rounded-xl border border-teal-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-teal-950 uppercase">Échéance à 28 Jours (fck)</span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-teal-100 text-teal-900">
                          Contractuel
                        </span>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-600 mb-0.5">Résistance Cible (MPa)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={formData.targetStrength28jMpa || ''}
                          onChange={e => setFormData({ ...formData, targetStrength28jMpa: Number(e.target.value) })}
                          className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-600 mb-0.5">Résistance Obtenue (MPa)</label>
                        <input
                          type="number"
                          step="0.1"
                          value={formData.measuredStrength28jMpa ?? ''}
                          onChange={e => setFormData({ ...formData, measuredStrength28jMpa: e.target.value === '' ? undefined : Number(e.target.value) })}
                          placeholder="Écrasé à 28j"
                          className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold text-teal-950"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 6: SECTIONS PERSONNALISEES & ANNEXES */}
            {activeTab === 'custom_sections' && (
              <div className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900">
                      6. Sections Additionnelles du Dossier & Annexes Libres
                    </h4>
                    <button
                      type="button"
                      onClick={handleAddCustomSection}
                      className="px-2.5 py-1 bg-teal-700 hover:bg-teal-600 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Ajouter une Section</span>
                    </button>
                  </div>

                  {customSections.length === 0 ? (
                    <p className="text-xs text-slate-400 italic p-4 text-center bg-white rounded border border-dashed border-slate-300">
                      Aucune section personnalisée ajoutée. Cliquez sur « Ajouter une Section » pour documenter des essais particuliers (adsorption, absorption d'eau, ressuage, etc.).
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {customSections.map((sec, index) => (
                        <div key={sec.id} className="p-3 bg-white rounded-lg border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <input
                              type="text"
                              value={sec.title}
                              onChange={e => handleUpdateCustomSection(sec.id, { title: e.target.value })}
                              placeholder="Titre de la section (ex: Essai de Ressuage et Masse Volumique)"
                              className="font-bold text-xs text-slate-800 p-1 border-b border-slate-200 flex-1 mr-2"
                            />
                            <button
                              type="button"
                              onClick={() => handleRemoveCustomSection(sec.id)}
                              className="text-red-500 hover:text-red-700 p-1 cursor-pointer"
                              title="Supprimer la section"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                          <textarea
                            rows={2}
                            value={sec.content}
                            onChange={e => handleUpdateCustomSection(sec.id, { content: e.target.value })}
                            placeholder="Observations techniques, protocole d'essai ou résultats détaillés..."
                            className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-xs text-slate-800"
                          />
                        </div>
                      ))}
                    </div>
                  )}

                  {/* General observations */}
                  <div className="mt-4 pt-3 border-t border-slate-200">
                    <label className="block font-bold text-slate-800 text-xs mb-1">
                      Observations Générales & Recommandations de Mise en Œuvre
                    </label>
                    <textarea
                      rows={3}
                      value={formData.observations || ''}
                      onChange={e => setFormData({ ...formData, observations: e.target.value })}
                      placeholder="Indiquez ici les recommandations sur la vibration, la cure humide, les adjuvants ou les conditions climatiques..."
                      className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Dossier Bottom Stepper Navigation */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={() => navigateTab('prev', activeTab, setActiveTab)}
                disabled={activeTab === 'project'}
                className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 text-xs font-medium flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Section Précédente</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => navigateTab('next', activeTab, setActiveTab)}
                  disabled={activeTab === 'custom_sections'}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 text-xs font-medium flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 cursor-pointer"
                >
                  <span>Section Suivante</span>
                  <ChevronRight className="w-4 h-4" />
                </button>

                <button
                  type="submit"
                  className="px-5 py-1.5 bg-teal-700 hover:bg-teal-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Enregistrer le Dossier</span>
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* =========================================================================
          VIEWER MODAL (MULTI-PAGE DOSSIER WITH PROMINENT EXCEL EXPORT & PRINT)
          ========================================================================= */}
      {selectedFormulation && !isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-lg p-4 sm:p-6 space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between pb-4 border-b border-slate-200 gap-3 no-print">
            <div className="flex items-center gap-2.5">
              <span className="font-mono text-sm font-bold text-teal-900 bg-teal-50 px-2.5 py-1 rounded border border-teal-200">
                {selectedFormulation.formulationNumber}
              </span>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Dossier d'Étude de Formulation de Béton
                </h3>
                <span className="text-xs text-slate-500">
                  Classe {selectedFormulation.strengthClass} • {selectedFormulation.concreteType}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* PROMINENT EXCEL EXPORT BUTTON */}
              <button
                onClick={() => exportFormulationToExcel(selectedFormulation, settings)}
                className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                title="Télécharger le fichier Excel (.xlsx) officiel de ce dossier de formulation"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Exporter en Excel</span>
              </button>

              <button
                onClick={() => handlePrint(selectedFormulation)}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                title="Aperçu complet avant impression et export PDF"
              >
                <Printer className="w-4 h-4" />
                <span>Aperçu & Impression</span>
              </button>

              <button
                onClick={() => handleEdit(selectedFormulation)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Edit className="w-4 h-4" />
                <span>Modifier</span>
              </button>

              <button
                onClick={() => setSelectedFormulation(null)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>

          {/* Dossier Tabs in Viewer Mode */}
          <div className="flex items-center gap-1 overflow-x-auto border-b border-slate-200 pb-1 scrollbar-thin no-print">
            {dossierTabs.map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setViewTab(tab.id)}
                className={`px-3.5 py-2 rounded-t-lg text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-2 cursor-pointer ${
                  viewTab === tab.id
                    ? 'bg-teal-50 text-teal-900 border-b-2 border-teal-600 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  viewTab === tab.id ? 'bg-teal-700 text-white' : 'bg-slate-200 text-slate-700'
                }`}>
                  {tab.number}
                </span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Official Document Body */}
          {renderFormulationDossier(selectedFormulation, false)}
        </div>
      )}

      {/* =========================================================================
          FORMULATIONS LIST TABLE (WITH DIRECT EXCEL EXPORT BUTTON)
          ========================================================================= */}
      {!isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden no-print">
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Rechercher par N°, projet, classe..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => exportFormulationsListToExcel(filtered, settings)}
                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                title="Exporter la liste complète des dossiers de formulation en Excel"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Exporter le Registre Excel</span>
              </button>
              <span className="text-xs text-slate-500">
                {filtered.length} dossier{filtered.length > 1 ? 's' : ''}
              </span>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="p-12 text-center text-xs text-slate-400">
              Aucune étude de formulation trouvée. Cliquez sur « Nouveau Dossier de Formulation ».
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filtered.map(form => (
                <div
                  key={form.id}
                  className="p-3 sm:p-4 hover:bg-slate-50/80 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3"
                >
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className="p-2.5 bg-teal-100 text-teal-800 rounded-lg flex-shrink-0">
                      <Beaker className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs font-bold text-teal-900 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                          {form.formulationNumber}
                        </span>
                        <span className="text-xs font-bold text-slate-800">
                          {form.projectName}
                        </span>
                        <span className="text-xs text-slate-500 truncate">
                          • {form.clientName}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 mt-1 text-xs">
                        <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-bold font-mono">
                          {form.strengthClass}
                        </span>
                        <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                          {form.concreteType}
                        </span>
                        <span className="text-slate-500">
                          Ciment: {form.cementDosageKg} kg/m³
                        </span>
                        <span className="text-slate-500">
                          E/C: {form.wcRatio}
                        </span>
                        <span className="text-teal-800 font-semibold">
                          7j: {form.measuredStrength7jMpa || '-'} MPa • 14j: {form.measuredStrength14jMpa || '-'} MPa • 28j: {form.measuredStrength28jMpa || '-'} MPa
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions: View, Excel Export, Print, Duplicate, Edit, Delete */}
                  <div className="flex items-center gap-1 self-end md:self-center">
                    <button
                      onClick={() => handleView(form)}
                      title="Consulter le dossier multi-sections"
                      className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => exportFormulationToExcel(form, settings)}
                      title="Exporter en Excel"
                      className="p-2 text-emerald-700 hover:bg-emerald-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <FileSpreadsheet className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handlePrint(form)}
                      title="Aperçu & Impression"
                      className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDuplicate(form.id)}
                      title="Dupliquer"
                      className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleEdit(form)}
                      title="Modifier"
                      className="p-2 text-teal-700 hover:bg-teal-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer la formulation ${form.formulationNumber} ?`)) {
                          onDelete(form.id);
                        }
                      }}
                      title="Supprimer"
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Capacitor-Compatible Print Preview Modal */}
      {previewModalForm && (
        <PrintPreviewModal
          isOpen={!!previewModalForm}
          onClose={() => setPreviewModalForm(null)}
          title={`Étude de Formulation Béton - ${previewModalForm.formulationNumber}`}
          documentSubtitle={`Dossier d'Étude de Formulation • ${previewModalForm.projectName || ''}`}
        >
          {renderFormulationDossier(previewModalForm, true)}
        </PrintPreviewModal>
      )}
    </div>
  );
};

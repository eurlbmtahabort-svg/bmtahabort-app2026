import React, { useState } from 'react';
import {
  FolderKanban,
  Plus,
  Search,
  Building2,
  MapPin,
  Calendar,
  ClockAlert,
  Edit,
  Trash2,
  CheckCircle2,
  AlertCircle,
  FileText,
  Eye,
  Lock
} from 'lucide-react';
import { Project, Client, Chantier } from '../types';
import { ALGERIAN_WILAYAS } from '../data/algeriaData';
import { compute14DayTracking } from '../utils/engineeringCalculations';

interface ProjectsViewProps {
  projects: Project[];
  clients: Client[];
  chantiers: Chantier[];
  onSaveProject: (project: Project) => void;
  onDeleteProject: (id: string) => void;
  getNextProjectNumber: () => string;
  initialCreateTrigger?: boolean;
  onResetCreateTrigger?: () => void;
  selectedProject?: Project | null;
  onClearSelectedProject?: () => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  clients,
  chantiers,
  onSaveProject,
  onDeleteProject,
  getNextProjectNumber,
  initialCreateTrigger,
  onResetCreateTrigger,
  selectedProject,
  onClearSelectedProject
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [isEditing, setIsEditing] = useState(false);
  const [activeProject, setActiveProject] = useState<Project | null>(selectedProject || null);
  const [formData, setFormData] = useState<Partial<Project>>({});

  React.useEffect(() => {
    if (selectedProject) {
      setActiveProject(selectedProject);
      setIsEditing(false);
    }
  }, [selectedProject]);

  React.useEffect(() => {
    if (initialCreateTrigger) {
      handleStartNew();
      if (onResetCreateTrigger) onResetCreateTrigger();
    }
  }, [initialCreateTrigger]);

  const handleStartNew = () => {
    const today = new Date().toISOString().split('T')[0];
    const defaultClient = clients[0];

    setFormData({
      id: 'prj-' + Date.now(),
      projectNumber: getNextProjectNumber(),
      name: '',
      clientId: defaultClient ? defaultClient.id : '',
      clientName: defaultClient ? defaultClient.name : '',
      chantierId: '',
      chantierName: '',
      wilaya: '16 - Alger',
      commune: '',
      description: '',
      status: 'EN_COURS',
      startDate: today,
      tracking14Days: {
        enabled: true,
        startDate: today,
        targetDurationDays: 14,
        notes: 'Suivi de la cure et maturation des bétons d’infrastructure.'
      },
      createdAt: today
    });
    setIsEditing(true);
    setActiveProject(null);
  };

  const handleEdit = (p: Project) => {
    setFormData({
      ...p,
      tracking14Days: p.tracking14Days || {
        enabled: false,
        startDate: p.startDate,
        targetDurationDays: 14
      }
    });
    setIsEditing(true);
    setActiveProject(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.projectNumber || !formData.clientId) {
      alert('Veuillez remplir le nom, le numéro et sélectionner un client.');
      return;
    }

    const client = clients.find(c => c.id === formData.clientId);
    const complete: Project = {
      id: formData.id || 'prj-' + Date.now(),
      projectNumber: formData.projectNumber,
      name: formData.name,
      clientId: formData.clientId,
      clientName: client ? client.name : formData.clientName || '',
      chantierId: formData.chantierId,
      chantierName: formData.chantierName,
      wilaya: formData.wilaya || '16 - Alger',
      commune: formData.commune,
      description: formData.description || '',
      status: formData.status as any || 'EN_COURS',
      startDate: formData.startDate || new Date().toISOString().split('T')[0],
      endDate: formData.endDate,
      tracking14Days: formData.tracking14Days || {
        enabled: true,
        startDate: formData.startDate || new Date().toISOString().split('T')[0],
        targetDurationDays: 14
      },
      createdAt: formData.createdAt || new Date().toISOString().split('T')[0]
    };

    onSaveProject(complete);
    setIsEditing(false);
    setActiveProject(complete);
  };

  const filtered = projects.filter(p => {
    const q = search.toLowerCase();
    const matchesSearch =
      p.projectNumber.toLowerCase().includes(q) ||
      p.name.toLowerCase().includes(q) ||
      p.clientName.toLowerCase().includes(q) ||
      p.wilaya.toLowerCase().includes(q);

    if (statusFilter === 'ALL') return matchesSearch;
    return matchesSearch && p.status === statusFilter;
  });

  return (
    <div className="space-y-6">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Gestion des Projets de Travaux Publics & BTP
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
              {projects.length} dossiers
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Suivi des opérations, rattachement des chantiers, prélèvements et traçabilité de l'échéance des 14 jours.
          </p>
        </div>

        <button
          onClick={handleStartNew}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau Projet</span>
        </button>
      </div>

      {/* Editor Modal */}
      {isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <FolderKanban className="w-5 h-5 text-emerald-600" />
              <h3 className="font-bold text-slate-900 text-base font-tech">
                {formData.id ? 'Éditer le Projet' : 'Nouveau Projet de Génie Civil'}
              </h3>
            </div>
            <button
              onClick={() => setIsEditing(false)}
              className="text-slate-400 hover:text-slate-700 text-xs px-2.5 py-1 rounded bg-slate-100"
            >
              Annuler
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5 text-xs">
            {/* General info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Code / N° Projet <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.projectNumber || ''}
                  onChange={e => setFormData({ ...formData, projectNumber: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-medium mb-1">
                  Intitulé du Projet / Ouvrage <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: Réalisation d’un Pont à Poutres Précontraintes RN 01"
                  value={formData.name || ''}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-medium text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Client / Demandeur <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={formData.clientId || ''}
                  onChange={e => {
                    const cl = clients.find(c => c.id === e.target.value);
                    setFormData({
                      ...formData,
                      clientId: e.target.value,
                      clientName: cl ? cl.name : ''
                    });
                  }}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  <option value="">Sélectionner un client...</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.type})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Chantier rattaché
                </label>
                {chantiers && chantiers.length > 0 ? (
                  <select
                    value={formData.chantierId || ''}
                    onChange={e => {
                      const ch = chantiers.find(c => c.id === e.target.value);
                      setFormData({
                        ...formData,
                        chantierId: e.target.value || undefined,
                        chantierName: ch ? ch.name : undefined
                      });
                    }}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                  >
                    <option value="">Sélectionner un chantier...</option>
                    {chantiers.map(ch => (
                      <option key={ch.id} value={ch.id}>
                        {ch.name} ({ch.wilaya})
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    placeholder="Nom du tronçon ou lot"
                    value={formData.chantierName || ''}
                    onChange={e => setFormData({ ...formData, chantierName: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                  />
                )}
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Wilaya (Algérie)
                </label>
                <select
                  value={formData.wilaya || '16 - Alger'}
                  onChange={e => setFormData({ ...formData, wilaya: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  {ALGERIAN_WILAYAS.map(w => {
                    const str = `${w.code} - ${w.name}`;
                    return (
                      <option key={w.code} value={str}>
                        {str}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Commune / Localisation
                </label>
                <input
                  type="text"
                  placeholder="ex: Dar El Beïda"
                  value={formData.commune || ''}
                  onChange={e => setFormData({ ...formData, commune: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Statut du Projet
                </label>
                <select
                  value={formData.status || 'EN_COURS'}
                  onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-semibold text-slate-900"
                >
                  <option value="EN_COURS">EN COURS</option>
                  <option value="TERMINE">TERMINÉ</option>
                  <option value="SUSPENDU">SUSPENDU</option>
                  <option value="ARCHIVE">ARCHIVÉ</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Date de démarrage
                </label>
                <input
                  type="date"
                  value={formData.startDate || ''}
                  onChange={e => setFormData({ ...formData, startDate: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Description technique / Consignes particulières
              </label>
              <textarea
                rows={2}
                value={formData.description || ''}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
              />
            </div>

            {/* Mandatory 14-day requirement block */}
            <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ClockAlert className="w-4 h-4 text-amber-700" />
                  <span className="font-bold text-amber-900">
                    Suivi Obligatoire de la Règle des 14 Jours
                  </span>
                </div>
                <label className="flex items-center gap-1.5 cursor-pointer text-amber-950 font-semibold">
                  <input
                    type="checkbox"
                    checked={formData.tracking14Days?.enabled ?? true}
                    onChange={e =>
                      setFormData({
                        ...formData,
                        tracking14Days: {
                          enabled: e.target.checked,
                          startDate: formData.tracking14Days?.startDate || formData.startDate || '',
                          targetDurationDays: formData.tracking14Days?.targetDurationDays || 14,
                          notes: formData.tracking14Days?.notes || ''
                        }
                      })
                    }
                    className="rounded text-amber-600"
                  />
                  <span>Activer la surveillance des 14 jours</span>
                </label>
              </div>

              {formData.tracking14Days?.enabled && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                  <div>
                    <label className="block text-slate-700 font-medium mb-1 flex items-center gap-1">
                      <Lock className="w-3 h-3 text-slate-400" />
                      <span>Date d'origine (Point de départ)</span>
                    </label>
                    <input
                      type="date"
                      value={formData.tracking14Days?.startDate || formData.startDate || ''}
                      onChange={e =>
                        setFormData({
                          ...formData,
                          tracking14Days: {
                            ...formData.tracking14Days!,
                            startDate: e.target.value
                          }
                        })
                      }
                      className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-medium mb-1">
                      Durée réglementaire visée (jours)
                    </label>
                    <input
                      type="number"
                      value={formData.tracking14Days?.targetDurationDays || 14}
                      onChange={e =>
                        setFormData({
                          ...formData,
                          tracking14Days: {
                            ...formData.tracking14Days!,
                            targetDurationDays: Number(e.target.value)
                          }
                        })
                      }
                      className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-medium mb-1">
                      Remarques sur le cycle
                    </label>
                    <input
                      type="text"
                      placeholder="Lot radier, cure humide..."
                      value={formData.tracking14Days?.notes || ''}
                      onChange={e =>
                        setFormData({
                          ...formData,
                          tracking14Days: {
                            ...formData.tracking14Days!,
                            notes: e.target.value
                          }
                        })
                      }
                      className="w-full p-1.5 bg-white border border-slate-300 rounded"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Submit buttons */}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Enregistrer le Projet</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Selected Project Full Profile Drawer/View */}
      {activeProject && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="flex items-start justify-between border-b border-slate-200 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold bg-emerald-50 text-emerald-800 px-2.5 py-0.5 rounded border border-emerald-200">
                  {activeProject.projectNumber}
                </span>
                <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                  activeProject.status === 'EN_COURS'
                    ? 'bg-emerald-100 text-emerald-800'
                    : activeProject.status === 'TERMINE'
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-slate-100 text-slate-700'
                }`}>
                  {activeProject.status}
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mt-1 font-tech">
                {activeProject.name}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Client : <strong>{activeProject.clientName}</strong> • Chantier : {activeProject.chantierName || 'Principal'} • Wilaya : {activeProject.wilaya}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleEdit(activeProject)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Modifier</span>
              </button>
              <button
                onClick={() => {
                  setActiveProject(null);
                  if (onClearSelectedProject) onClearSelectedProject();
                }}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>

          {/* 14-day tracking status banner if enabled */}
          {activeProject.tracking14Days && activeProject.tracking14Days.enabled && activeProject.tracking14Days.startDate && (
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              {(() => {
                const track = compute14DayTracking(
                  activeProject.tracking14Days.startDate,
                  activeProject.tracking14Days.targetDurationDays || 14
                );
                if (!track) return null;
                return (
                  <>
                    <div className="flex items-center gap-2.5">
                      <ClockAlert className="w-4 h-4 text-amber-600 flex-shrink-0" />
                      <div>
                        <div className="font-semibold text-slate-900">
                          Cycle de 14 Jours : {track.elapsedDays} jours écoulés sur {track.targetDays}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Date d'origine : <strong>{activeProject.tracking14Days.startDate}</strong> • Échéance : <strong>{track.dueDateFormatted}</strong>
                        </div>
                      </div>
                    </div>

                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                      track.statusColor === 'emerald'
                        ? 'bg-emerald-100 text-emerald-800'
                        : track.statusColor === 'amber'
                        ? 'bg-amber-100 text-amber-900 font-extrabold'
                        : track.statusColor === 'red'
                        ? 'bg-red-100 text-red-900 font-extrabold'
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      {track.statusLabel}
                    </span>
                  </>
                );
              })()}
            </div>
          )}

          <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
            <span className="font-bold text-slate-800 block mb-1">Description du Projet :</span>
            {activeProject.description || 'Aucune description spécifique renseignée.'}
          </div>
        </div>
      )}

      {/* Projects List Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher par N°, nom, client, wilaya..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
            />
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            {['ALL', 'EN_COURS', 'TERMINE', 'SUSPENDU'].map(st => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                  statusFilter === st
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {st === 'ALL' ? 'Tous' : st}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            Aucun projet ne correspond à votre recherche.
          </div>
        ) : (
          <>
            {/* Mobile View: Cards */}
            <div className="md:hidden divide-y divide-slate-100">
              {filtered.map(p => {
                const track = p.tracking14Days?.startDate
                  ? compute14DayTracking(p.tracking14Days.startDate, p.tracking14Days.targetDurationDays || 14)
                  : null;

                return (
                  <div key={p.id} className="p-4 space-y-2.5">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            {p.projectNumber}
                          </span>
                          <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                            p.status === 'EN_COURS'
                              ? 'bg-emerald-100 text-emerald-800'
                              : p.status === 'TERMINE'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}>
                            {p.status}
                          </span>
                        </div>
                        <h4 className="font-bold text-slate-900 text-sm font-tech mt-1">{p.name}</h4>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setActiveProject(p)}
                          title="Détails"
                          className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEdit(p)}
                          title="Modifier"
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Supprimer le projet ${p.projectNumber} ?`)) {
                              onDeleteProject(p.id);
                            }
                          }}
                          title="Supprimer"
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="text-xs text-slate-600 space-y-1">
                      <div className="flex items-center gap-1.5 text-slate-800 font-medium">
                        <Building2 className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span>{p.clientName} {p.chantierName ? `• Chantier: ${p.chantierName}` : ''}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-600">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span>{p.wilaya} {p.commune ? `• ${p.commune}` : ''}</span>
                      </div>
                      {track && (
                        <div className="pt-1 flex items-center gap-2">
                          <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full font-semibold ${
                            track.statusColor === 'emerald'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : track.statusColor === 'amber'
                              ? 'bg-amber-50 text-amber-900 border border-amber-300'
                              : track.statusColor === 'red'
                              ? 'bg-red-50 text-red-900 border border-red-300'
                              : 'bg-slate-100 text-slate-700'
                          }`}>
                            <ClockAlert className="w-3 h-3" />
                            14J : {track.statusLabel} ({track.elapsedDays}/{track.targetDays}j)
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Desktop View: Full Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Numéro</th>
                    <th className="p-3">Intitulé de l'Ouvrage</th>
                    <th className="p-3">Client & Wilaya</th>
                    <th className="p-3">Statut</th>
                    <th className="p-3">Suivi des 14 Jours</th>
                    <th className="p-3">Date Début</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map(p => {
                    const track = p.tracking14Days?.startDate
                      ? compute14DayTracking(p.tracking14Days.startDate, p.tracking14Days.targetDurationDays || 14)
                      : null;

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3 font-mono font-bold text-slate-900">
                          {p.projectNumber}
                        </td>
                        <td className="p-3">
                          <div className="font-semibold text-slate-800 truncate max-w-xs">{p.name}</div>
                          {p.chantierName && (
                            <div className="text-[11px] text-slate-500">Chantier : {p.chantierName}</div>
                          )}
                        </td>
                        <td className="p-3">
                          <div className="font-medium text-slate-800">{p.clientName}</div>
                          <div className="text-[11px] text-slate-500">{p.wilaya}</div>
                        </td>
                        <td className="p-3">
                          <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                            p.status === 'EN_COURS'
                              ? 'bg-emerald-100 text-emerald-800'
                              : p.status === 'TERMINE'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}>
                            {p.status}
                          </span>
                        </td>
                        <td className="p-3">
                          {track ? (
                            <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full font-semibold ${
                              track.statusColor === 'emerald'
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : track.statusColor === 'amber'
                                ? 'bg-amber-50 text-amber-900 border border-amber-300'
                                : track.statusColor === 'red'
                                ? 'bg-red-50 text-red-900 border border-red-300'
                                : 'bg-slate-100 text-slate-700'
                            }`}>
                              {track.statusLabel}
                            </span>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </td>
                        <td className="p-3 font-mono text-slate-500">
                          {p.startDate}
                        </td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => setActiveProject(p)}
                              title="Consulter le dossier"
                              className="p-1.5 hover:bg-slate-100 text-slate-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleEdit(p)}
                              title="Modifier"
                              className="p-1.5 hover:bg-slate-100 text-blue-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Supprimer le projet ${p.projectNumber} ?`)) {
                                  onDeleteProject(p.id);
                                }
                              }}
                              title="Supprimer"
                              className="p-1.5 hover:bg-red-50 text-red-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

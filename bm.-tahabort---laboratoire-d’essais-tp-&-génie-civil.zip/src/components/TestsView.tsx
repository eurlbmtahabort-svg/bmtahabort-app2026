import React, { useState } from 'react';
import {
  FlaskConical,
  Plus,
  Search,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Clock,
  Printer,
  Trash2,
  Edit,
  Eye,
  Filter,
  FileSpreadsheet
} from 'lucide-react';
import { LabTest, Project, Client, Chantier, LabSettings } from '../types';
import { CIVIL_ENGINEERING_TESTS_STANDARDS } from '../data/algeriaData';
import { exportTestsListToExcel } from '../utils/excelExport';
import { PrintPreviewModal } from './PrintPreviewModal';

interface TestsViewProps {
  tests: LabTest[];
  projects: Project[];
  clients: Client[];
  chantiers: Chantier[];
  settings?: LabSettings;
  onSaveTest: (test: LabTest) => void;
  onDeleteTest: (id: string) => void;
  getNextTestNumber: () => string;
  initialCreateTrigger?: boolean;
  onResetCreateTrigger?: () => void;
}

export const TestsView: React.FC<TestsViewProps> = ({
  tests,
  projects,
  clients,
  chantiers,
  settings,
  onSaveTest,
  onDeleteTest,
  getNextTestNumber,
  initialCreateTrigger,
  onResetCreateTrigger
}) => {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [selectedTest, setSelectedTest] = useState<LabTest | null>(null);
  const [previewModalTest, setPreviewModalTest] = useState<LabTest | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<LabTest>>({});

  React.useEffect(() => {
    if (initialCreateTrigger) {
      handleStartNew();
      if (onResetCreateTrigger) onResetCreateTrigger();
    }
  }, [initialCreateTrigger]);

  const handleStartNew = () => {
    const today = new Date().toISOString().split('T')[0];
    const defaultProj = projects[0];
    const defaultStd = CIVIL_ENGINEERING_TESTS_STANDARDS[0];

    setFormData({
      id: 'test-' + Date.now(),
      testNumber: getNextTestNumber(),
      testType: defaultStd.name,
      standardRef: defaultStd.standard,
      category: defaultStd.category as any,
      projectId: defaultProj ? defaultProj.id : '',
      projectName: defaultProj ? defaultProj.name : '',
      clientId: defaultProj ? defaultProj.clientId : '',
      clientName: defaultProj ? defaultProj.clientName : '',
      chantierId: defaultProj ? defaultProj.chantierId : '',
      chantierName: defaultProj ? defaultProj.chantierName : '',
      sampleNumber: 'ECH-' + new Date().getFullYear() + '-0001',
      dateRealized: today,
      operator: 'Technicien Laboratoire BM. TAHABORT',
      equipmentUsed: 'Matériel normalisé étalonné',
      measurementsSummary: '',
      resultValue: undefined,
      resultUnit: '',
      status: 'CONFORME',
      complianceObservation: 'Résultat conforme aux spécifications du CCTP.',
      observations: '',
      createdAt: today
    });
    setIsEditing(true);
    setSelectedTest(null);
  };

  const handleEdit = (t: LabTest) => {
    setFormData({ ...t });
    setIsEditing(true);
    setSelectedTest(null);
  };

  const handleStandardSelect = (testName: string) => {
    const std = CIVIL_ENGINEERING_TESTS_STANDARDS.find(s => s.name === testName);
    if (std) {
      setFormData(prev => ({
        ...prev,
        testType: std.name,
        standardRef: std.standard,
        category: std.category as any,
        resultUnit: std.defaultUnit
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.testNumber || !formData.projectId || !formData.testType) {
      alert('Veuillez remplir le numéro, le projet et le type d’essai.');
      return;
    }

    const proj = projects.find(p => p.id === formData.projectId);
    const complete: LabTest = {
      id: formData.id || 'test-' + Date.now(),
      testNumber: formData.testNumber,
      testType: formData.testType,
      standardRef: formData.standardRef || 'NF EN',
      category: formData.category || 'BETON',
      projectId: formData.projectId,
      projectName: proj ? proj.name : formData.projectName || '',
      clientId: formData.clientId || (proj ? proj.clientId : ''),
      clientName: formData.clientName || (proj ? proj.clientName : ''),
      chantierId: formData.chantierId,
      chantierName: formData.chantierName,
      sampleNumber: formData.sampleNumber || 'ECH-001',
      dateRealized: formData.dateRealized || new Date().toISOString().split('T')[0],
      operator: formData.operator || 'Opérateur Labo',
      equipmentUsed: formData.equipmentUsed || 'Matériel normalisé',
      measurementsSummary: formData.measurementsSummary || '',
      resultValue: formData.resultValue,
      resultUnit: formData.resultUnit || '',
      status: formData.status as any || 'VALIDE',
      complianceObservation: formData.complianceObservation || '',
      conclusion: formData.conclusion || formData.complianceObservation || 'Résultat conforme aux spécifications.',
      observations: formData.observations || '',
      createdAt: formData.createdAt || new Date().toISOString().split('T')[0]
    };

    onSaveTest(complete);
    setIsEditing(false);
    setSelectedTest(complete);
  };

  const filtered = tests.filter(t => {
    const q = search.toLowerCase();
    const matchSearch =
      t.testNumber.toLowerCase().includes(q) ||
      t.testType.toLowerCase().includes(q) ||
      t.standardRef.toLowerCase().includes(q) ||
      (t.projectName && t.projectName.toLowerCase().includes(q));

    if (categoryFilter === 'ALL') return matchSearch;
    return matchSearch && t.category === categoryFilter;
  });

  const renderTestDocument = (t: LabTest, isModal: boolean = false) => {
    const labName = settings?.labName || 'BM. TAHABORT';
    const labSubtitle = settings?.labSubtitle || 'Laboratoire d’Essais de Travaux Publics & Génie Civil';
    const labAddress = settings?.address || 'Zone Industrielle, Oued Smar, Alger';
    const labPhone = settings?.phone || '+213 (0) 23 92 11 22';
    const labEmail = settings?.email || 'contact@bm-tahabort-labo.dz';
    const labNif = settings?.nif || '001916012345678';
    const labRc = settings?.rc || '16/00-1234567B19';

    return (
      <div className={`space-y-6 ${isModal ? 'bg-white text-slate-900 p-2 sm:p-4 text-xs' : 'text-xs'}`}>
        {/* Lab Header */}
        <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded bg-slate-900 text-teal-400 font-tech font-bold flex items-center justify-center text-base border-2 border-teal-600">
              BM
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900 font-tech">
                {labName}
              </h1>
              <p className="text-[11px] text-slate-700 font-semibold">
                {labSubtitle}
              </p>
              <p className="text-[10px] text-slate-500">
                {labAddress} • Tél: {labPhone} • {labEmail}
              </p>
              <p className="text-[10px] text-slate-400">
                NIF: {labNif} • RC: {labRc}
              </p>
            </div>
          </div>
          <div className="text-right text-[11px]">
            <div className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-1 rounded border border-slate-200">
              FICHE D'ESSAI N° {t.testNumber}
            </div>
            <div className="text-slate-500 mt-1">Date réalisation : <strong>{t.dateRealized}</strong></div>
            <div className="text-slate-500">Norme : <strong>{t.standardRef}</strong></div>
          </div>
        </div>

        {/* Document Title Banner */}
        <div className="text-center py-2 bg-slate-100 rounded border border-slate-200">
          <h2 className="text-sm font-bold tracking-wider text-slate-900 uppercase font-tech">
            FICHE D'ESSAI TECHNIQUE & MÉTROLOGIQUE
          </h2>
          <p className="text-[11px] text-slate-600 font-semibold">
            {t.testType} ({t.category})
          </p>
        </div>

        {/* Identification Section */}
        <div className="grid grid-cols-2 gap-4">
          <div className="border border-slate-200 rounded p-3 space-y-1.5 bg-slate-50/50">
            <div className="text-[11px] font-bold text-slate-800 border-b border-slate-200 pb-1 uppercase tracking-wide">
              Identification Chantier & Client
            </div>
            <div><span className="text-slate-500">Projet :</span> <strong className="text-slate-900">{t.projectName || '—'}</strong></div>
            <div><span className="text-slate-500">Client / Maître d'ouvrage :</span> <strong className="text-slate-900">{t.clientName || '—'}</strong></div>
            <div><span className="text-slate-500">Chantier / Wilaya :</span> <span className="text-slate-800">{t.chantierName || '—'}</span></div>
          </div>

          <div className="border border-slate-200 rounded p-3 space-y-1.5 bg-slate-50/50">
            <div className="text-[11px] font-bold text-slate-800 border-b border-slate-200 pb-1 uppercase tracking-wide">
              Paramètres d'Échantillonnage & Matériel
            </div>
            <div><span className="text-slate-500">N° d'Échantillon :</span> <strong className="font-mono text-slate-900">{t.sampleNumber || '—'}</strong></div>
            <div><span className="text-slate-500">Opérateur / Technicien :</span> <span className="text-slate-800">{t.operator || '—'}</span></div>
            <div><span className="text-slate-500">Matériel normalisé :</span> <span className="text-slate-800">{t.equipmentUsed || '—'}</span></div>
          </div>
        </div>

        {/* Measurements / Raw Data */}
        {t.measurementsSummary && (
          <div className="border border-slate-200 rounded p-3 space-y-1.5">
            <div className="text-[11px] font-bold text-slate-800 border-b border-slate-200 pb-1 uppercase tracking-wide">
              Mesures Brutes & Données d'Essai
            </div>
            <p className="text-slate-800 whitespace-pre-wrap leading-relaxed">
              {t.measurementsSummary}
            </p>
          </div>
        )}

        {/* Results & Conclusion */}
        <div className="border-2 border-slate-900 rounded-lg p-4 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-[11px] uppercase tracking-wide text-slate-600 font-bold">
              Résultat Métrologique Certifié
            </div>
            <div className="text-2xl font-bold font-mono text-slate-900">
              {t.resultValue !== undefined ? `${t.resultValue} ${t.resultUnit || ''}` : 'En cours'}
            </div>
            <div className="text-xs text-slate-700">
              {t.conclusion || t.complianceObservation || 'Résultat conforme aux spécifications réglementaires.'}
            </div>
          </div>
          <div className="text-right">
            <span className={`inline-block text-xs px-3 py-1 rounded-full font-bold uppercase tracking-wide ${
              t.status === 'CONFORME'
                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                : t.status === 'NON_CONFORME'
                ? 'bg-red-100 text-red-900 border border-red-300'
                : 'bg-slate-200 text-slate-800 border border-slate-300'
            }`}>
              STATUT : {t.status}
            </span>
          </div>
        </div>

        {/* Signatures */}
        <div className="pt-6 border-t border-slate-300 grid grid-cols-2 gap-8 text-[11px]">
          <div>
            <div className="font-semibold text-slate-800">L'Opérateur / Technicien d'Essai :</div>
            <div className="text-slate-600 mt-1 font-bold">{t.operator || 'Technicien Laboratoire'}</div>
            <div className="h-16"></div>
            <div className="border-t border-slate-300 pt-1 text-[10px] text-slate-400">Visa & Signature</div>
          </div>
          <div className="text-right">
            <div className="font-semibold text-slate-800">Le Directeur Technique / Chef de Laboratoire :</div>
            <div className="text-slate-600 mt-1 font-bold">Ing. B. Mourad</div>
            <div className="h-16"></div>
            <div className="border-t border-slate-300 pt-1 text-[10px] text-slate-400">Cachet & Signature Officielle</div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Essais de Laboratoire & Contrôles In Situ
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold">
              Bétons • Granulats • Sols • Géotechnique • Enrobés
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Enregistrement des essais géotechniques et de mécanique des matériaux selon normes algériennes et internationales (NF / NA / EN / ASTM).
          </p>
        </div>

        <button
          onClick={handleStartNew}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nouvel Essai</span>
        </button>
      </div>

      {/* Editor Modal */}
      {isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6 no-print">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-blue-600" />
              <h3 className="font-bold text-slate-900 text-base font-tech">
                {formData.id ? 'Modifier la Fiche d’Essai' : 'Nouvel Essai de Laboratoire'}
              </h3>
            </div>
            <button
              onClick={() => setIsEditing(false)}
              className="text-slate-400 hover:text-slate-700 text-xs px-2.5 py-1 rounded bg-slate-100"
            >
              Annuler
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  N° de l'Essai <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.testNumber || ''}
                  onChange={e => setFormData({ ...formData, testNumber: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Projet Rattaché <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={formData.projectId || ''}
                  onChange={e => {
                    const p = projects.find(item => item.id === e.target.value);
                    setFormData({
                      ...formData,
                      projectId: e.target.value,
                      projectName: p ? p.name : '',
                      clientId: p ? p.clientId : '',
                      clientName: p ? p.clientName : '',
                      chantierId: p ? p.chantierId : '',
                      chantierName: p ? p.chantierName : ''
                    });
                  }}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  <option value="">Sélectionner un projet...</option>
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.projectNumber} - {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  N° Échantillon Prélevé
                </label>
                <input
                  type="text"
                  value={formData.sampleNumber || ''}
                  onChange={e => setFormData({ ...formData, sampleNumber: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Type d'Essai (Catalogue Normalisé) <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.testType || ''}
                  onChange={e => handleStandardSelect(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-semibold text-slate-900"
                >
                  {CIVIL_ENGINEERING_TESTS_STANDARDS.map(s => (
                    <option key={s.name} value={s.name}>
                      [{s.category}] {s.name} ({s.standard})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Norme de Référence
                </label>
                <input
                  type="text"
                  value={formData.standardRef || ''}
                  onChange={e => setFormData({ ...formData, standardRef: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Date de Réalisation
                </label>
                <input
                  type="date"
                  value={formData.dateRealized || ''}
                  onChange={e => setFormData({ ...formData, dateRealized: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Opérateur / Technicien
                </label>
                <input
                  type="text"
                  value={formData.operator || ''}
                  onChange={e => setFormData({ ...formData, operator: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Équipement utilisé (Machine / Étuve / Tamiseur)
                </label>
                <input
                  type="text"
                  value={formData.equipmentUsed || ''}
                  onChange={e => setFormData({ ...formData, equipmentUsed: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Statut de Conformité
                </label>
                <select
                  value={formData.status || 'CONFORME'}
                  onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-bold text-slate-900"
                >
                  <option value="CONFORME">CONFORME (Valide)</option>
                  <option value="NON_CONFORME">NON CONFORME</option>
                  <option value="EN_COURS">EN COURS D'ANALYSE</option>
                  <option value="EN_ATTENTE">EN ATTENTE D'ÉCRÈVEMENT</option>
                </select>
              </div>
            </div>

            {/* Measurements and Results */}
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-medium mb-1">
                    Mesures & Paramètres Bruts Enregistrés
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Détail des pesées, masses sèches, lectures métrologiques..."
                    value={formData.measurementsSummary || ''}
                    onChange={e => setFormData({ ...formData, measurementsSummary: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Résultat Final & Unité
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      step="0.01"
                      placeholder="Valeur"
                      value={formData.resultValue ?? ''}
                      onChange={e => setFormData({ ...formData, resultValue: e.target.value ? Number(e.target.value) : undefined })}
                      className="w-2/3 p-2 bg-white border border-slate-300 rounded font-mono font-bold text-slate-900"
                    />
                    <input
                      type="text"
                      placeholder="Unité (ex: %, MPa)"
                      value={formData.resultUnit || ''}
                      onChange={e => setFormData({ ...formData, resultUnit: e.target.value })}
                      className="w-1/3 p-2 bg-white border border-slate-300 rounded font-mono text-slate-900"
                    />
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    Valeur métrologique certifiée
                  </div>
                </div>
              </div>
            </div>

            {/* Observations */}
            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Conclusion / Conformité CCTP
              </label>
              <input
                type="text"
                value={formData.complianceObservation || ''}
                onChange={e => setFormData({ ...formData, complianceObservation: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Enregistrer l'Essai</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Selected Test Detail Modal */}
      {selectedTest && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-5 space-y-4">
          <div className="flex items-start justify-between border-b border-slate-200 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold bg-blue-50 text-blue-800 px-2.5 py-0.5 rounded border border-blue-200">
                  {selectedTest.testNumber}
                </span>
                <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                  selectedTest.status === 'CONFORME'
                    ? 'bg-emerald-100 text-emerald-800'
                    : selectedTest.status === 'NON_CONFORME'
                    ? 'bg-red-100 text-red-800'
                    : 'bg-slate-100 text-slate-700'
                }`}>
                  {selectedTest.status}
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mt-1 font-tech">
                {selectedTest.testType}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Norme : <strong>{selectedTest.standardRef}</strong> • Projet : {selectedTest.projectName} • Date : {selectedTest.dateRealized}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setPreviewModalTest(selectedTest)}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="Aperçu avant impression et export PDF de cette fiche"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Aperçu & Impression</span>
              </button>
              <button
                onClick={() => handleEdit(selectedTest)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Modifier</span>
              </button>
              <button
                onClick={() => setSelectedTest(null)}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
              <div>Échantillon : <strong className="font-mono">{selectedTest.sampleNumber}</strong></div>
              <div>Opérateur : <strong>{selectedTest.operator}</strong></div>
              <div>Matériel : <strong>{selectedTest.equipmentUsed}</strong></div>
            </div>

            <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
              <div className="text-slate-500">Résultat métrologique certifié :</div>
              <div className="text-xl font-bold font-mono text-emerald-800">
                {selectedTest.resultValue !== undefined ? `${selectedTest.resultValue} ${selectedTest.resultUnit}` : 'N/A'}
              </div>
              <div className="text-[11px] text-slate-600">
                {selectedTest.complianceObservation || 'Conforme'}
              </div>
            </div>
          </div>

          {selectedTest.measurementsSummary && (
            <div className="p-3 bg-slate-50 rounded border border-slate-200 text-xs">
              <span className="font-bold text-slate-800 block mb-1">Détails des mesures brutes :</span>
              <p className="text-slate-700 whitespace-pre-wrap">{selectedTest.measurementsSummary}</p>
            </div>
          )}
        </div>
      )}

      {/* Tests List Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher par N°, essai, norme, projet..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 text-xs overflow-x-auto">
              {['ALL', 'BETON', 'GRANULAT', 'SOL_GEOTECH', 'LIANT_CIMENT'].map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                    categoryFilter === cat
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat === 'ALL' ? 'Tous' : cat}
                </button>
              ))}
            </div>

            <button
              onClick={() => exportTestsListToExcel(filtered, settings)}
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              title="Exporter le registre des essais filtrés vers Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Exporter en Excel</span>
            </button>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            Aucun essai géotechnique ou de génie civil ne correspond à vos critères.
          </div>
        ) : (
          <>
            {/* Mobile View: Cards */}
            <div className="md:hidden divide-y divide-slate-100">
              {filtered.map(t => (
                <div key={t.id} className="p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                          {t.testNumber}
                        </span>
                        <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                          t.status === 'CONFORME'
                            ? 'bg-emerald-100 text-emerald-800'
                            : t.status === 'NON_CONFORME'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {t.status}
                        </span>
                      </div>
                      <h4 className="font-bold text-slate-900 text-sm font-tech mt-1">{t.testType}</h4>
                      <div className="text-[11px] font-mono text-slate-500">{t.standardRef}</div>
                      <div className="text-xs text-slate-600 mt-1">{t.projectName}</div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setSelectedTest(t)}
                        title="Consulter"
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setPreviewModalTest(t)}
                        title="Aperçu & Impression de la fiche"
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleEdit(t)}
                        title="Modifier"
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Supprimer l'essai ${t.testNumber} ?`)) {
                            onDeleteTest(t.id);
                          }
                        }}
                        title="Supprimer"
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                    <span className="text-slate-500 font-mono text-[11px]">Date: {t.dateRealized}</span>
                    <span className="font-mono font-bold text-slate-900 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                      {t.resultValue !== undefined ? `${t.resultValue} ${t.resultUnit}` : 'En cours'}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop View: Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Numéro</th>
                    <th className="p-3">Désignation de l'Essai & Norme</th>
                    <th className="p-3">Projet & Échantillon</th>
                    <th className="p-3">Date</th>
                    <th className="p-3">Résultat</th>
                    <th className="p-3">Statut</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map(t => (
                    <tr key={t.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-slate-900">
                        {t.testNumber}
                      </td>
                      <td className="p-3">
                        <div className="font-semibold text-slate-900">{t.testType}</div>
                        <div className="text-[11px] font-mono text-slate-500">{t.standardRef}</div>
                      </td>
                      <td className="p-3">
                        <div className="text-slate-800 font-medium truncate max-w-xs">{t.projectName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">Éch: {t.sampleNumber}</div>
                      </td>
                      <td className="p-3 font-mono text-slate-600">
                        {t.dateRealized}
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-900">
                        {t.resultValue !== undefined ? `${t.resultValue} ${t.resultUnit}` : '—'}
                      </td>
                      <td className="p-3">
                        <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                          t.status === 'CONFORME'
                            ? 'bg-emerald-100 text-emerald-800'
                            : t.status === 'NON_CONFORME'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {t.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setSelectedTest(t)}
                            title="Consulter"
                            className="p-1.5 hover:bg-slate-100 text-slate-600 rounded cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setPreviewModalTest(t)}
                            title="Aperçu & Impression de la fiche"
                            className="p-1.5 hover:bg-slate-100 text-slate-600 rounded cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleEdit(t)}
                            title="Modifier"
                            className="p-1.5 hover:bg-slate-100 text-blue-600 rounded cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Supprimer l'essai ${t.testNumber} ?`)) {
                                onDeleteTest(t.id);
                              }
                            }}
                            title="Supprimer"
                            className="p-1.5 hover:bg-red-50 text-red-600 rounded cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* Capacitor-Compatible Print Preview Modal */}
      {previewModalTest && (
        <PrintPreviewModal
          isOpen={!!previewModalTest}
          onClose={() => setPreviewModalTest(null)}
          title={`Fiche d'Essai ${previewModalTest.testNumber}`}
          documentSubtitle={`${previewModalTest.testType} • ${previewModalTest.projectName || ''}`}
        >
          {renderTestDocument(previewModalTest, true)}
        </PrintPreviewModal>
      )}
    </div>
  );
};

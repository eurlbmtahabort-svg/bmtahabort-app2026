import React, { useState } from 'react';
import {
  Tag,
  Plus,
  Search,
  Calendar,
  Thermometer,
  MapPin,
  Edit,
  Trash2,
  CheckCircle2,
  Eye
} from 'lucide-react';
import { Sample, Project, Client, Chantier } from '../types';

interface SamplesViewProps {
  samples: Sample[];
  projects: Project[];
  clients: Client[];
  chantiers: Chantier[];
  onSaveSample: (sample: Sample) => void;
  onDeleteSample: (id: string) => void;
  getNextSampleNumber: () => string;
}

export const SamplesView: React.FC<SamplesViewProps> = ({
  samples,
  projects,
  clients,
  chantiers,
  onSaveSample,
  onDeleteSample,
  getNextSampleNumber
}) => {
  const [search, setSearch] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<Sample>>({});
  const [selectedSample, setSelectedSample] = useState<Sample | null>(null);

  const handleStartNew = () => {
    const today = new Date().toISOString().split('T')[0];
    const defaultProj = projects[0];

    setFormData({
      id: 'ech-' + Date.now(),
      sampleNumber: getNextSampleNumber(),
      projectId: defaultProj ? defaultProj.id : '',
      projectName: defaultProj ? defaultProj.name : '',
      clientId: defaultProj ? defaultProj.clientId : '',
      clientName: defaultProj ? defaultProj.clientName : '',
      chantierId: defaultProj ? defaultProj.chantierId : '',
      chantierName: defaultProj ? defaultProj.chantierName : '',
      materialType: 'Béton frais',
      samplingDate: today,
      samplingLocation: 'Sur toupie à la livraison / Centrale à béton',
      sampledBy: 'Technicien Préleveur BM. TAHABORT',
      ambientTempC: 22,
      conservationConditions: 'Bac d’eau thermostaté à 20°C ± 2°C',
      status: 'RECU',
      observations: '',
      createdAt: today
    });
    setIsEditing(true);
  };

  const handleEdit = (s: Sample) => {
    setFormData({ ...s });
    setIsEditing(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.sampleNumber || !formData.projectId) {
      alert('Veuillez renseigner le numéro d’échantillon et le projet.');
      return;
    }

    const proj = projects.find(p => p.id === formData.projectId);
    const complete: Sample = {
      id: formData.id || 'ech-' + Date.now(),
      sampleNumber: formData.sampleNumber,
      projectId: formData.projectId,
      projectName: proj ? proj.name : formData.projectName || '',
      clientId: formData.clientId || (proj ? proj.clientId : ''),
      clientName: formData.clientName || (proj ? proj.clientName : ''),
      chantierId: formData.chantierId,
      chantierName: formData.chantierName,
      materialType: formData.materialType || 'Matériau',
      samplingDate: formData.samplingDate || new Date().toISOString().split('T')[0],
      samplingLocation: formData.samplingLocation || '',
      sampledBy: formData.sampledBy || '',
      ambientTempC: formData.ambientTempC ? Number(formData.ambientTempC) : undefined,
      conservationConditions: formData.conservationConditions || '',
      status: formData.status as any || 'RECU',
      observations: formData.observations || '',
      createdAt: formData.createdAt || new Date().toISOString().split('T')[0]
    };

    onSaveSample(complete);
    setIsEditing(false);
  };

  const filtered = samples.filter(s => {
    const q = search.toLowerCase();
    return (
      s.sampleNumber.toLowerCase().includes(q) ||
      s.materialType.toLowerCase().includes(q) ||
      (s.projectName && s.projectName.toLowerCase().includes(q)) ||
      (s.clientName && s.clientName.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Échantillons & Prélèvements de Chantier
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold">
              {samples.length} fiches de prélèvement
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Traçabilité de la chaîne de prélèvement : lieu, date, température ambiante et conditions de conservation.
          </p>
        </div>

        <button
          onClick={handleStartNew}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nouvel Échantillon</span>
        </button>
      </div>

      {isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
            <h3 className="font-bold text-slate-900 text-base font-tech">
              {formData.id ? 'Modifier l’Échantillon' : 'Enregistrer un Nouveau Prélèvement'}
            </h3>
            <button
              onClick={() => setIsEditing(false)}
              className="text-slate-400 hover:text-slate-700 text-xs px-2.5 py-1 rounded bg-slate-100"
            >
              Annuler
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  N° de Prélèvement / Échantillon <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.sampleNumber || ''}
                  onChange={e => setFormData({ ...formData, sampleNumber: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Projet Associé <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={formData.projectId || ''}
                  onChange={e => {
                    const p = projects.find(item => item.id === e.target.value);
                    setFormData({
                      ...formData,
                      projectId: e.target.value,
                      projectName: p ? p.name : '',
                      clientId: p ? p.clientId : '',
                      clientName: p ? p.clientName : '',
                      chantierId: p ? p.chantierId : '',
                      chantierName: p ? p.chantierName : ''
                    });
                  }}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  <option value="">Sélectionner un projet...</option>
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.projectNumber} - {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Nature du Matériau
                </label>
                <input
                  type="text"
                  placeholder="ex: Béton frais B25, Sable 0/4, Sol tuffeux"
                  value={formData.materialType || ''}
                  onChange={e => setFormData({ ...formData, materialType: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-medium text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Date de Prélèvement
                </label>
                <input
                  type="date"
                  value={formData.samplingDate || ''}
                  onChange={e => setFormData({ ...formData, samplingDate: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Lieu exact de prélèvement
                </label>
                <input
                  type="text"
                  placeholder="ex: Semelle S12 axe 4"
                  value={formData.samplingLocation || ''}
                  onChange={e => setFormData({ ...formData, samplingLocation: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Prélevé par (Technicien)
                </label>
                <input
                  type="text"
                  value={formData.sampledBy || ''}
                  onChange={e => setFormData({ ...formData, sampledBy: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Température ambiante (°C)
                </label>
                <input
                  type="number"
                  value={formData.ambientTempC || 20}
                  onChange={e => setFormData({ ...formData, ambientTempC: Number(e.target.value) })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-medium mb-1">
                  Conditions de Conservation & Cure
                </label>
                <input
                  type="text"
                  placeholder="ex: Chambre humide 20°C ± 2°C / immersion dans l'eau"
                  value={formData.conservationConditions || ''}
                  onChange={e => setFormData({ ...formData, conservationConditions: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Enregistrer le Prélèvement</span>
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher par N°, matériau, projet..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            Aucun prélèvement enregistré. Cliquez sur « Nouveau Prélèvement » pour identifier un échantillon.
          </div>
        ) : (
          <>
            {/* Mobile View: Cards */}
            <div className="md:hidden divide-y divide-slate-100">
              {filtered.map(s => (
                <div key={s.id} className="p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                          {s.sampleNumber}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-emerald-100 text-emerald-800">
                          {s.status}
                        </span>
                      </div>
                      <h4 className="font-bold text-slate-900 text-sm font-tech mt-1">{s.materialType}</h4>
                      <div className="text-xs text-slate-600">{s.projectName}</div>
                      <div className="text-[11px] text-slate-400">{s.clientName}</div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setSelectedSample(s)}
                        title="Détails"
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleEdit(s)}
                        title="Modifier"
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Supprimer l'échantillon ${s.sampleNumber} ?`)) {
                            onDeleteSample(s.id);
                          }
                        }}
                        title="Supprimer"
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span className="font-mono text-[11px]">{s.samplingDate}</span>
                    {s.samplingLocation && (
                      <span className="truncate max-w-[200px]">📍 {s.samplingLocation}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop View: Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Numéro Échantillon</th>
                    <th className="p-3">Matériau</th>
                    <th className="p-3">Projet & Client</th>
                    <th className="p-3">Date Prélèvement</th>
                    <th className="p-3">Lieu & Préleveur</th>
                    <th className="p-3">Statut</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map(s => (
                    <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-slate-900">
                        {s.sampleNumber}
                      </td>
                      <td className="p-3 font-medium text-slate-800">
                        {s.materialType}
                      </td>
                      <td className="p-3">
                        <div className="font-semibold text-slate-800 truncate max-w-xs">{s.projectName}</div>
                        <div className="text-[11px] text-slate-500">{s.clientName}</div>
                      </td>
                      <td className="p-3 font-mono text-slate-600">
                        {s.samplingDate}
                      </td>
                      <td className="p-3">
                        <div className="text-slate-800">{s.samplingLocation || '—'}</div>
                        <div className="text-[11px] text-slate-400">{s.sampledBy}</div>
                      </td>
                      <td className="p-3">
                        <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-emerald-100 text-emerald-800">
                          {s.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setSelectedSample(s)}
                            title="Voir les détails"
                            className="p-1.5 hover:bg-slate-100 text-slate-600 rounded cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleEdit(s)}
                            title="Modifier"
                            className="p-1.5 hover:bg-slate-100 text-blue-600 rounded cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Supprimer l'échantillon ${s.sampleNumber} ?`)) {
                                onDeleteSample(s.id);
                              }
                            }}
                            title="Supprimer"
                            className="p-1.5 hover:bg-red-50 text-red-600 rounded cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* Sample Details Modal */}
      {selectedSample && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="font-mono text-xs font-bold text-slate-500 uppercase">Fiche d'Échantillonnage</span>
                <h3 className="text-lg font-bold font-tech text-slate-900">{selectedSample.sampleNumber}</h3>
              </div>
              <button
                onClick={() => setSelectedSample(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg">
                <span className="text-slate-400 block mb-1">Matériau</span>
                <span className="font-bold text-slate-900">{selectedSample.materialType}</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg">
                <span className="text-slate-400 block mb-1">Statut</span>
                <span className="font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  {selectedSample.status}
                </span>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg col-span-2">
                <span className="text-slate-400 block mb-1">Projet & Chantier</span>
                <span className="font-bold text-slate-900 block">{selectedSample.projectName}</span>
                <span className="text-slate-500 text-[11px]">{selectedSample.clientName}</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg">
                <span className="text-slate-400 block mb-1">Date de Prélèvement</span>
                <span className="font-mono font-medium text-slate-800">{selectedSample.samplingDate}</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg">
                <span className="text-slate-400 block mb-1">Température Ambiante</span>
                <span className="font-mono font-medium text-slate-800">
                  {selectedSample.ambientTempC !== undefined ? `${selectedSample.ambientTempC} °C` : '—'}
                </span>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg col-span-2">
                <span className="text-slate-400 block mb-1">Lieu & Conditions</span>
                <span className="text-slate-800 block">{selectedSample.samplingLocation || '—'}</span>
                {selectedSample.conservationConditions && (
                  <span className="text-slate-600 text-[11px] block mt-1 italic">
                    Conservation : {selectedSample.conservationConditions}
                  </span>
                )}
              </div>
              <div className="bg-slate-50 p-3 rounded-lg col-span-2">
                <span className="text-slate-400 block mb-1">Préleveur</span>
                <span className="text-slate-800">{selectedSample.sampledBy || 'Laboratoire BM. TAHABORT'}</span>
              </div>
              {selectedSample.observations && (
                <div className="bg-slate-50 p-3 rounded-lg col-span-2">
                  <span className="text-slate-400 block mb-1">Observations</span>
                  <p className="text-slate-700 italic">{selectedSample.observations}</p>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-100">
              <button
                onClick={() => setSelectedSample(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

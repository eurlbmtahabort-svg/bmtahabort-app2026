import React from 'react';
import { 
  Building2, 
  Search, 
  UserCheck, 
  AlertCircle, 
  Trash2, 
  RotateCcw,
  Clock,
  Menu,
  X,
  FileSpreadsheet
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';

export interface NavbarProps {
  currentUser?: UserProfile;
  availableUsers?: UserProfile[];
  onSelectUser?: (user: UserProfile) => void;
  isDemoData?: boolean;
  onClearDemoData?: () => void;
  onRestoreDemoData?: () => void;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
  active14DayAlertsCount?: number;
  onNavigateTo14Days?: () => void;
  onToggleMobileMenu?: () => void;
  isMobileMenuOpen?: boolean;
  // Alternate props for flexible integrations
  onToggleSidebar?: () => void;
  projects?: any[];
  compressionPVs?: any[];
  currentRole?: UserRole;
  onRoleChange?: (role: UserRole) => void;
  onNavigate?: (tab: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  availableUsers = [],
  onSelectUser,
  isDemoData = false,
  onClearDemoData,
  onRestoreDemoData,
  searchQuery = '',
  onSearchChange,
  active14DayAlertsCount = 0,
  onNavigateTo14Days,
  onToggleMobileMenu,
  isMobileMenuOpen = false,
  onToggleSidebar,
  projects,
  compressionPVs,
  currentRole,
  onRoleChange,
  onNavigate
}) => {
  // Safe default user if not passed
  const effectiveUser: UserProfile = currentUser || {
    id: 'u-admin',
    name: 'Directeur Technique',
    title: 'Ingénieur en Chef Génie Civil',
    role: (currentRole as UserRole) || 'ADMIN',
    email: 'direction@bm-tahabort.dz',
    active: true
  };

  const getRoleBadge = (role?: UserRole) => {
    switch (role) {
      case 'ADMIN':
        return { label: 'Administrateur', bg: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
      case 'LAB_MANAGER':
        return { label: 'Resp. Laboratoire', bg: 'bg-blue-100 text-blue-800 border-blue-300' };
      case 'TECHNICIAN':
        return { label: 'Technicien', bg: 'bg-amber-100 text-amber-800 border-amber-300' };
      case 'VIEWER':
        return { label: 'Consultation', bg: 'bg-slate-100 text-slate-700 border-slate-300' };
      default:
        return { label: 'Ingénieur Labo', bg: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
    }
  };

  const badge = getRoleBadge(effectiveUser?.role);

  // Compute 14-day alert count if not directly passed
  const calculatedAlertsCount = active14DayAlertsCount || (
    projects ? projects.filter(p => p.tracking14Days && p.tracking14Days.enabled && p.status === 'EN_COURS').length : 0
  );

  const handleToggleMenu = () => {
    if (onToggleMobileMenu) onToggleMobileMenu();
    if (onToggleSidebar) onToggleSidebar();
  };

  const handleNavigate14Days = () => {
    if (onNavigateTo14Days) onNavigateTo14Days();
    else if (onNavigate) onNavigate('tracking_14d');
  };

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs no-print">
      {/* Demo Data Banner if active */}
      {isDemoData && (
        <div className="bg-amber-500 text-slate-950 px-4 py-1.5 text-xs sm:text-sm font-medium flex flex-wrap items-center justify-between gap-2 shadow-inner border-b border-amber-600">
          <div className="flex items-center gap-2">
            <span className="font-bold bg-slate-950 text-amber-400 px-2 py-0.5 rounded text-xs tracking-wider uppercase">
              Données de Démonstration
            </span>
            <span className="hidden md:inline text-slate-900">
              Ces exemples illustrent le fonctionnement du laboratoire. Ils ne constituent pas des résultats réels.
            </span>
          </div>
          <div className="flex items-center gap-2">
            {onClearDemoData && (
              <button
                onClick={onClearDemoData}
                title="Effacer les données de démonstration pour démarrer avec une base vide"
                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
                <span>Vider la démo (Production)</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Header Bar */}
      <div className="px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2 sm:gap-4">
        {/* Left: Brand Identity / Logo placeholder */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleToggleMenu}
            className="md:hidden p-1.5 text-slate-600 hover:text-slate-900 rounded-lg border border-slate-200 hover:bg-slate-100 cursor-pointer"
            aria-label="Menu"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-3">
            {/* Logo BM. TAHABORT clean placeholder with Algerian national touch */}
            <div className="relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-lg bg-slate-900 border-2 border-emerald-600 text-white shadow-xs flex-shrink-0">
              <div className="absolute top-0 right-0 w-2 h-2 rounded-full bg-red-600 ring-2 ring-white"></div>
              <div className="text-center font-tech font-bold leading-none tracking-tighter">
                <span className="text-emerald-400 text-xs sm:text-sm">BM</span>
                <span className="block text-[8px] sm:text-[9px] text-white">LAB</span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight font-tech">
                  BM. TAHABORT
                </h1>
                <span className="hidden sm:inline-block text-[10px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200">
                  Algérie • TP & GC
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-500 font-medium truncate max-w-[200px] sm:max-w-md">
                Laboratoire d’Essais de Travaux Publics & Génie Civil
              </p>
            </div>
          </div>
        </div>

        {/* Center: Quick Search Input */}
        <div className="hidden lg:flex items-center flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher projet, client, chantier, essai, PV..."
              value={searchQuery}
              onChange={e => onSearchChange && onSearchChange(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 text-xs sm:text-sm bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-800 placeholder-slate-400 transition-all"
            />
            {searchQuery && onSearchChange && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Right: Actions, 14-Day alerts, & User Role Switcher */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* 14-Day Mandatory Tracking Alert Button */}
          <button
            onClick={handleNavigate14Days}
            title="Suivi métrologique de la règle des 14 jours (Délais & Échéances de contrôle)"
            className={`relative p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
              calculatedAlertsCount > 0
                ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100 animate-pulse'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <Clock className={`w-4 h-4 ${calculatedAlertsCount > 0 ? 'text-amber-600' : 'text-slate-500'}`} />
            <span className="hidden xl:inline">Suivi 14 Jours</span>
            {calculatedAlertsCount > 0 && (
              <span className="px-1.5 py-0.2 bg-red-600 text-white rounded-full text-[10px] font-bold">
                {calculatedAlertsCount}
              </span>
            )}
          </button>

          {/* User Role Selector */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            <div className="hidden sm:block text-right">
              <div className="text-xs font-semibold text-slate-900 leading-tight flex items-center gap-1 justify-end">
                <span>{effectiveUser.name}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded border font-medium ${badge.bg}`}>
                  {badge.label}
                </span>
              </div>
              <span className="text-[10px] text-slate-500 truncate block max-w-[130px]">
                {effectiveUser.title}
              </span>
            </div>

            <div className="relative group">
              <select
                aria-label="Changer d'utilisateur ou rôle de laboratoire"
                value={effectiveUser.id}
                onChange={e => {
                  const targetId = e.target.value;
                  const u = availableUsers.find(item => item.id === targetId);
                  if (u && onSelectUser) {
                    onSelectUser(u);
                  } else if (onRoleChange) {
                    onRoleChange(targetId as UserRole);
                  }
                }}
                className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-800 py-1.5 px-2 rounded-lg border border-slate-300 font-medium cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-600"
              >
                {availableUsers.length > 0 ? (
                  availableUsers.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.role})
                    </option>
                  ))
                ) : (
                  <>
                    <option value="ADMIN">Direction (ADMIN)</option>
                    <option value="LAB_MANAGER">Ingénieur Responsable (LAB_MANAGER)</option>
                    <option value="TECHNICIAN">Technicien Supérieur (TECHNICIAN)</option>
                    <option value="VIEWER">Consultation Seule (VIEWER)</option>
                  </>
                )}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile search bar if screen is small */}
      {onSearchChange && (
        <div className="lg:hidden px-3 pb-2 pt-1 border-t border-slate-100">
          <div className="relative w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher (projet, client, essai, PV...)"
              value={searchQuery}
              onChange={e => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400"
            />
          </div>
        </div>
      )}
    </header>
  );
};

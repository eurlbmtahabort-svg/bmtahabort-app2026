import React, { useState, useRef } from 'react';
import {
  Settings,
  Building2,
  ClockAlert,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Shield,
  Sliders,
  Scale,
  Download,
  Upload,
  Database
} from 'lucide-react';
import { LaboratorySettings } from '../types';

interface SettingsViewProps {
  settings: LaboratorySettings;
  onSaveSettings: (newSettings: LaboratorySettings) => void;
  onResetDemoData: () => void;
  onExportBackup?: () => Promise<{ success: boolean; message: string; summary?: any }> | void;
  onImportBackup?: (jsonStr: string) => boolean;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onSaveSettings,
  onResetDemoData,
  onExportBackup,
  onImportBackup
}) => {
  const [formData, setFormData] = useState<LaboratorySettings>({ ...settings });
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [backupSuccess, setBackupSuccess] = useState<string | null>(null);
  const [backupError, setBackupError] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [copiedToClipboard, setCopiedToClipboard] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleTriggerExport = async () => {
    if (!onExportBackup) return;
    setIsExporting(true);
    setBackupSuccess(null);
    setBackupError(null);

    try {
      const res = await onExportBackup();
      if (res && typeof res === 'object') {
        if (res.success) {
          setBackupSuccess(res.message);
        } else {
          setBackupError(res.message);
        }
      } else {
        setBackupSuccess("Sauvegarde complète compilée et exportée avec succès !");
      }
    } catch (err: any) {
      setBackupError("Erreur lors de l'exportation : " + (err?.message || 'Erreur inattendue'));
    } finally {
      setIsExporting(false);
    }
  };

  const handleCopyRawBackup = () => {
    try {
      const rawData = localStorage.getItem('bmtahabort_db');
      if (rawData) {
        navigator.clipboard.writeText(rawData);
        setCopiedToClipboard(true);
        setTimeout(() => setCopiedToClipboard(false), 3000);
        setBackupSuccess("Base de données JSON copiée dans le presse-papier avec succès !");
      } else {
        setBackupError("Aucune donnée locale trouvée à copier.");
      }
    } catch (e) {
      setBackupError("Impossible d'accéder au presse-papier sur ce terminal.");
    }
  };

  const handleFileProcess = (file: File) => {
    setBackupSuccess(null);
    setBackupError(null);
    if (!file.name.endsWith('.json')) {
      setBackupError('Le fichier sélectionné doit être un document JSON valide.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        if (onImportBackup) {
          const ok = onImportBackup(content);
          if (ok) {
            setBackupSuccess('La base de données du laboratoire a été restaurée avec succès !');
            setTimeout(() => setBackupSuccess(null), 4000);
          } else {
            setBackupError('Structure JSON invalide ou incompatible avec le schéma du laboratoire BM. TAHABORT.');
          }
        }
      } catch (err) {
        setBackupError('Erreur de lecture du fichier de sauvegarde.');
      }
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
            Paramètres Généraux du Laboratoire
          </h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-semibold">
            Configuration Métrologique
          </span>
        </div>
        <p className="text-xs text-slate-500">
          Identité légale du laboratoire BM. TAHABORT, réglage de la durée cible des 14 jours, et gestion des équipements étalonnés.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-800 rounded-lg text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Paramètres enregistrés avec succès !</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 text-xs">
        {/* Mandatory 14-day rule configuration */}
        <div className="bg-white rounded-xl border border-amber-300 p-5 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-amber-900">
            <ClockAlert className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-sm font-tech">
              Configuration de la Règle Obligatoire des 14 Jours
            </h3>
          </div>
          <p className="text-slate-600 text-xs">
            Délai cible par défaut pour les alertes de suivi des projets et d'écrasement des éprouvettes à mi-parcours (par défaut : 14 jours).
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Délai de suivi par défaut (jours)
              </label>
              <input
                type="number"
                min={1}
                max={90}
                required
                value={formData.target14DaysDuration || 14}
                onChange={e => setFormData({ ...formData, target14DaysDuration: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
              />
              <div className="text-[10px] text-slate-400 mt-1">
                Standard réglementaire : 14 jours (écrasement intermédiaire ou décoffrage).
              </div>
            </div>

            <div className="flex items-center">
              <label className="flex items-center gap-2 cursor-pointer p-3 bg-slate-50 rounded-lg border border-slate-200 w-full">
                <input
                  type="checkbox"
                  checked={formData.enable14DaysNotification ?? true}
                  onChange={e => setFormData({ ...formData, enable14DaysNotification: e.target.checked })}
                  className="rounded text-amber-600"
                />
                <span className="font-medium text-slate-800">
                  Activer le badge d'alerte visuelle sur la barre de navigation
                </span>
              </label>
            </div>
          </div>
        </div>

        {/* Company Identity */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-slate-900">
            <Building2 className="w-5 h-5 text-emerald-600" />
            <h3 className="font-bold text-sm font-tech">
              Identité de la Société (En-tête des Rapports & PV)
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Raison Sociale
              </label>
              <input
                type="text"
                value={formData.companyName}
                onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-bold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Sous-titre d'Activité
              </label>
              <input
                type="text"
                value={formData.activitySubtitle}
                onChange={e => setFormData({ ...formData, activitySubtitle: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Adresse du Laboratoire
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={e => setFormData({ ...formData, address: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Téléphone & Email
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-1/2 p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-1/2 p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                NIF (Numéro d'Identification Fiscale)
              </label>
              <input
                type="text"
                value={formData.nif}
                onChange={e => setFormData({ ...formData, nif: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                RC (Registre du Commerce)
              </label>
              <input
                type="text"
                value={formData.rc}
                onChange={e => setFormData({ ...formData, rc: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
              />
            </div>
          </div>
        </div>

        {/* Laboratory Personnel & Official Signatories */}
        <div className="bg-white rounded-xl border border-teal-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-slate-900">
            <Shield className="w-5 h-5 text-teal-600" />
            <div className="flex-1">
              <h3 className="font-bold text-sm font-tech text-teal-950">
                Personnel du Laboratoire & Signataires des Rapports / PV
              </h3>
              <p className="text-[11px] text-slate-500">
                Définissez les noms officiels du Directeur et des Techniciens pour les nouveaux documents émis.
              </p>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200 font-semibold">
              Traçabilité Légale
            </span>
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 text-[11px] flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong>Règle d'intégrité historique :</strong> La modification du nom du Directeur ou du Technicien responsable ne modifie <em>JAMAIS</em> rétroactivement les anciens procès-verbaux et rapports déjà validés ou archivés. Les anciens documents conservent fidèlement les signataires d'origine.
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Nom du Directeur Technique (Approbation & Visa Final) *
              </label>
              <input
                type="text"
                required
                value={formData.directorName || ''}
                onChange={e => setFormData({ ...formData, directorName: e.target.value })}
                placeholder="ex: Ing. B. Mourad (Directeur Technique)"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900 focus:bg-white focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Ce nom figurera sur le cachet et la signature de validation de chaque PV et rapport.
              </span>
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                Nom du Technicien Responsable des Essais *
              </label>
              <input
                type="text"
                required
                value={formData.technicianName || ''}
                onChange={e => setFormData({ ...formData, technicianName: e.target.value })}
                placeholder="ex: Y. Amrani (Technicien Supérieur Essais Béton)"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-medium text-slate-900 focus:bg-white focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Opérateur désigné pour les essais de laboratoire et l'étalonnage.
              </span>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-slate-700 font-medium mb-1">
                Responsable Contrôle Qualité & Métrologie (Optionnel)
              </label>
              <input
                type="text"
                value={formData.qualityManagerName || ''}
                onChange={e => setFormData({ ...formData, qualityManagerName: e.target.value })}
                placeholder="ex: K. Hadj (Responsable Assurance Qualité)"
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:bg-white focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
              />
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-between pt-4">
          <button
            type="button"
            onClick={() => {
              if (confirm('Réinitialiser toutes les données aux valeurs de démonstration d’origine ?')) {
                onResetDemoData();
              }
            }}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-slate-500" />
            <span>Réinitialiser les Données Démo</span>
          </button>

          <button
            type="submit"
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Enregistrer les Paramètres</span>
          </button>
        </div>
      </form>

      {/* Backup and Restore Database */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-slate-900">
          <Database className="w-5 h-5 text-blue-600" />
          <h3 className="font-bold text-sm font-tech">
            Sauvegarde & Restauration de la Base de Données (JSON)
          </h3>
        </div>
        <p className="text-slate-600 text-xs">
          Exportez l'intégralité des dossiers clients, chantiers, essais, formulations, PV d'écrasement et rapports sous forme de fichier JSON sécurisé, ou restaurez une archive existante.
        </p>

        {backupSuccess && (
          <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-lg text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{backupSuccess}</span>
          </div>
        )}

        {backupError && (
          <div className="p-3 bg-red-50 border border-red-300 text-red-800 rounded-lg text-xs font-semibold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <span>{backupError}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          {/* Export Box */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col justify-between space-y-3">
            <div>
              <div className="font-semibold text-slate-800 text-xs mb-1 flex items-center gap-1.5">
                <Download className="w-4 h-4 text-blue-600" />
                <span>Exporter la Sauvegarde Complète</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Télécharger une archive JSON intégrale contenant tous les dossiers, chantiers, essais, formulations et PV du laboratoire.
              </p>
            </div>
            <div className="space-y-2">
              <button
                type="button"
                disabled={isExporting}
                onClick={handleTriggerExport}
                className="w-full px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-400 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              >
                <Download className={`w-4 h-4 ${isExporting ? 'animate-bounce' : ''}`} />
                <span>{isExporting ? 'Compilation de la Sauvegarde...' : 'Exporter la Sauvegarde Complète'}</span>
              </button>

              <button
                type="button"
                onClick={handleCopyRawBackup}
                className="w-full px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-[11px] font-medium flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                title="Copier les données brutes dans le presse-papier en cas de blocage de téléchargement sur mobile"
              >
                <span>{copiedToClipboard ? '✓ JSON Copié dans le Presse-papier' : '📋 Copier le JSON (Secours Mobile)'}</span>
              </button>
            </div>
          </div>

          {/* Import Box */}
          <div
            onDragOver={e => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`p-4 rounded-xl border-2 border-dashed flex flex-col justify-between space-y-3 transition-colors ${
              isDragging ? 'border-blue-500 bg-blue-50/50' : 'border-slate-300 bg-slate-50'
            }`}
          >
            <div>
              <div className="font-semibold text-slate-800 text-xs mb-1 flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-emerald-600" />
                <span>Restaurer une Base de Données</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Glissez-déposez votre archive .json ici ou sélectionnez-la depuis votre ordinateur.
              </p>
            </div>

            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              className="hidden"
              onChange={e => {
                if (e.target.files && e.target.files.length > 0) {
                  handleFileProcess(e.target.files[0]);
                  e.target.value = '';
                }
              }}
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full px-4 py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <Upload className="w-4 h-4 text-slate-600" />
              <span>Choisir un Fichier de Sauvegarde</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { 
  Calendar, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronRight, 
  Info, 
  ShieldAlert,
  FolderKanban,
  FileCheck2,
  Clock,
  Layers,
  TrendingUp,
  Activity
} from 'lucide-react';
import { Project, CompressionPV } from '../types';

interface Tracking14DaysWidgetProps {
  projects: Project[];
  compressionPVs: CompressionPV[];
  targetDaysDefault?: number;
  onSelectProject?: (project: Project) => void;
  onSelectPV?: (pv: CompressionPV) => void;
  isFullView?: boolean;
}

export const Tracking14DaysWidget: React.FC<Tracking14DaysWidgetProps> = ({
  projects,
  compressionPVs,
  onSelectProject,
  onSelectPV,
  isFullView = false
}) => {
  const [selectedAge, setSelectedAge] = useState<7 | 14 | 28 | 'ALL'>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'READY' | 'URGENT' | 'OVERDUE' | 'IN_PROGRESS'>('ALL');

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Helper to compute tracking for an age target
  const evaluateAgeDeadline = (confectionDateStr: string, ageDays: number) => {
    const confectionDate = new Date(confectionDateStr);
    confectionDate.setHours(0, 0, 0, 0);
    const dueDate = new Date(confectionDate.getTime() + ageDays * 24 * 60 * 60 * 1000);
    const elapsedDays = Math.floor((today.getTime() - confectionDate.getTime()) / (24 * 60 * 60 * 1000));
    const remainingDays = ageDays - elapsedDays;
    
    let status: 'IN_PROGRESS' | 'URGENT' | 'READY' | 'OVERDUE' = 'IN_PROGRESS';
    let statusLabel = `J-${remainingDays}`;
    let statusColor = 'slate';

    if (remainingDays === 0) {
      status = 'READY';
      statusLabel = 'Échéance aujourd’hui';
      statusColor = 'emerald';
    } else if (remainingDays > 0 && remainingDays <= 2) {
      status = 'URGENT';
      statusLabel = `Dans ${remainingDays} j`;
      statusColor = 'amber';
    } else if (remainingDays < 0) {
      status = 'OVERDUE';
      statusLabel = `Dépassement +${Math.abs(remainingDays)} j`;
      statusColor = 'red';
    } else {
      status = 'IN_PROGRESS';
      statusLabel = `Dans ${remainingDays} j`;
      statusColor = 'blue';
    }

    return {
      ageDays,
      dueDateFormatted: dueDate.toISOString().split('T')[0],
      elapsedDays,
      remainingDays,
      status,
      statusLabel,
      statusColor
    };
  };

  // Compile items: each sample/project with confection date
  const items = compressionPVs.map(pv => {
    const confection = pv.confectionDate || pv.samplingDate;
    const t7 = evaluateAgeDeadline(confection, 7);
    const t14 = evaluateAgeDeadline(confection, 14);
    const t28 = evaluateAgeDeadline(confection, 28);

    return {
      id: pv.id,
      pvNumber: pv.pvNumber,
      projectName: pv.projectName,
      clientName: pv.clientName,
      chantierName: pv.chantierName,
      sampleNumber: pv.sampleNumber,
      concreteClass: pv.concreteClass,
      confectionDate: confection,
      crushingDate: pv.crushingDate,
      activeAge: pv.concreteAgeDays,
      pv,
      deadlines: { 7: t7, 14: t14, 28: t28 }
    };
  });

  // Calculate statistics across all 3 ages equally
  const countAgeReady = (age: 7 | 14 | 28) => items.filter(i => i.deadlines[age].status === 'READY').length;
  const countAgeUrgent = (age: 7 | 14 | 28) => items.filter(i => i.deadlines[age].status === 'URGENT').length;
  const countAgeOverdue = (age: 7 | 14 | 28) => items.filter(i => i.deadlines[age].status === 'OVERDUE').length;
  const countAgeTotal = (age: 7 | 14 | 28) => items.filter(i => i.activeAge === age).length;

  const filteredItems = items.filter(item => {
    // If an age is selected, check that age's status
    if (selectedAge !== 'ALL') {
      const d = item.deadlines[selectedAge];
      if (item.activeAge !== selectedAge && selectedAge !== item.activeAge) {
        // Can also match if activeAge is the one or user wants to inspect all samples at that age
      }
      if (statusFilter !== 'ALL' && d.status !== statusFilter) return false;
      return item.activeAge === selectedAge;
    }

    if (statusFilter !== 'ALL') {
      const activeDeadline = item.deadlines[item.activeAge as 7 | 14 | 28] || item.deadlines[28];
      return activeDeadline.status === statusFilter;
    }

    return true;
  });

  return (
    <div className={`bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden ${isFullView ? 'p-4 sm:p-6' : 'p-4 sm:p-5'}`}>
      {/* Header with clear 7j / 14j / 28j equal importance */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-teal-100 text-teal-800 rounded-lg flex-shrink-0">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-900 font-tech">
                Suivi Cadencé des Échéances d’Écrasement : 7, 14 et 28 Jours
              </h3>
              <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 font-mono border border-teal-200 font-semibold">
                Norme NF EN 12390-3
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Contrôle strict et équilibré de la résistance mécanique aux 3 âges réglementaires : 7 jours (durcissement initial), 14 jours (décoffrage & convenance) et 28 jours (résistance caractéristique contractuelle fck).
            </p>
          </div>
        </div>

        {/* Age Selector Tabs - Equal prominence */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg text-xs font-semibold self-start lg:self-center">
          <button
            onClick={() => setSelectedAge('ALL')}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer ${
              selectedAge === 'ALL'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Tous les âges
          </button>
          <button
            onClick={() => setSelectedAge(7)}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedAge === 7
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>7 Jours</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20">
              {countAgeTotal(7)}
            </span>
          </button>
          <button
            onClick={() => setSelectedAge(14)}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedAge === 14
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>14 Jours</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20">
              {countAgeTotal(14)}
            </span>
          </button>
          <button
            onClick={() => setSelectedAge(28)}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedAge === 28
                ? 'bg-teal-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>28 Jours (fck)</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20">
              {countAgeTotal(28)}
            </span>
          </button>
        </div>
      </div>

      {/* 3 EQUAL STAT CARDS FOR 7J, 14J, AND 28J */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 my-4">
        {/* Card 7 Jours */}
        <div 
          onClick={() => setSelectedAge(7)}
          className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
            selectedAge === 7
              ? 'bg-blue-50/70 border-blue-400 ring-2 ring-blue-200'
              : 'bg-slate-50 border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-blue-600"></div>
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Échéances à 7 Jours
              </span>
            </div>
            <span className="text-[10px] font-semibold text-blue-700 px-2 py-0.5 rounded bg-blue-100">
              Contrôle Initial
            </span>
          </div>
          <div className="mt-2.5 flex items-baseline justify-between">
            <div>
              <span className="text-2xl font-bold font-tech text-slate-900">
                {countAgeTotal(7)}
              </span>
              <span className="text-xs text-slate-500 ml-1.5">PV actifs</span>
            </div>
            <div className="text-[11px] text-slate-500 text-right">
              {countAgeReady(7) > 0 && <span className="text-emerald-700 font-bold block">{countAgeReady(7)} prêt(s)</span>}
              {countAgeUrgent(7) > 0 && <span className="text-amber-700 font-bold block">{countAgeUrgent(7)} urgent(s)</span>}
              {countAgeReady(7) === 0 && countAgeUrgent(7) === 0 && <span>En cours de cure</span>}
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Indicateur de durcissement précoce (≈ 65-75% de fck)
          </div>
        </div>

        {/* Card 14 Jours */}
        <div 
          onClick={() => setSelectedAge(14)}
          className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
            selectedAge === 14
              ? 'bg-amber-50/70 border-amber-400 ring-2 ring-amber-200'
              : 'bg-slate-50 border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-600"></div>
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Échéances à 14 Jours
              </span>
            </div>
            <span className="text-[10px] font-semibold text-amber-800 px-2 py-0.5 rounded bg-amber-100">
              Intermédiaire
            </span>
          </div>
          <div className="mt-2.5 flex items-baseline justify-between">
            <div>
              <span className="text-2xl font-bold font-tech text-slate-900">
                {countAgeTotal(14)}
              </span>
              <span className="text-xs text-slate-500 ml-1.5">PV actifs</span>
            </div>
            <div className="text-[11px] text-slate-500 text-right">
              {countAgeReady(14) > 0 && <span className="text-emerald-700 font-bold block">{countAgeReady(14)} prêt(s)</span>}
              {countAgeUrgent(14) > 0 && <span className="text-amber-700 font-bold block">{countAgeUrgent(14)} urgent(s)</span>}
              {countAgeReady(14) === 0 && countAgeUrgent(14) === 0 && <span>En cours de cure</span>}
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Contrôle d’autorisation de décoffrage & pré-mise en charge
          </div>
        </div>

        {/* Card 28 Jours */}
        <div 
          onClick={() => setSelectedAge(28)}
          className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
            selectedAge === 28
              ? 'bg-teal-50/70 border-teal-400 ring-2 ring-teal-200'
              : 'bg-slate-50 border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-teal-700"></div>
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Échéances à 28 Jours
              </span>
            </div>
            <span className="text-[10px] font-semibold text-teal-800 px-2 py-0.5 rounded bg-teal-100">
              Réglementaire fck
            </span>
          </div>
          <div className="mt-2.5 flex items-baseline justify-between">
            <div>
              <span className="text-2xl font-bold font-tech text-slate-900">
                {countAgeTotal(28)}
              </span>
              <span className="text-xs text-slate-500 ml-1.5">PV actifs</span>
            </div>
            <div className="text-[11px] text-slate-500 text-right">
              {countAgeReady(28) > 0 && <span className="text-emerald-700 font-bold block">{countAgeReady(28)} prêt(s)</span>}
              {countAgeUrgent(28) > 0 && <span className="text-amber-700 font-bold block">{countAgeUrgent(28)} urgent(s)</span>}
              {countAgeReady(28) === 0 && countAgeUrgent(28) === 0 && <span>En cours de cure</span>}
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Résistance caractéristique contractuelle officielle (100% de fck)
          </div>
        </div>
      </div>

      {/* Status Sub-Filters */}
      <div className="flex flex-wrap items-center justify-between gap-2 py-2 text-xs border-y border-slate-100 mb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <span className="text-slate-400 text-[11px] mr-1">Filtrer l'état :</span>
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
              statusFilter === 'ALL'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Tous ({filteredItems.length})
          </button>
          <button
            onClick={() => setStatusFilter('READY')}
            className={`px-2.5 py-1 rounded-md font-medium cursor-pointer flex items-center gap-1 ${
              statusFilter === 'READY'
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            <CheckCircle2 className="w-3 h-3" />
            Échéance atteinte
          </button>
          <button
            onClick={() => setStatusFilter('URGENT')}
            className={`px-2.5 py-1 rounded-md font-medium cursor-pointer flex items-center gap-1 ${
              statusFilter === 'URGENT'
                ? 'bg-amber-600 text-white'
                : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
            }`}
          >
            <AlertTriangle className="w-3 h-3" />
            Urgent (≤ 2j)
          </button>
          <button
            onClick={() => setStatusFilter('OVERDUE')}
            className={`px-2.5 py-1 rounded-md font-medium cursor-pointer flex items-center gap-1 ${
              statusFilter === 'OVERDUE'
                ? 'bg-red-600 text-white'
                : 'bg-red-50 text-red-900 hover:bg-red-100 border border-red-200'
            }`}
          >
            <ShieldAlert className="w-3 h-3" />
            En retard
          </button>
        </div>

        <div className="text-[11px] text-slate-500 italic">
          Affichage des PV d'essais individuels pour l'âge {selectedAge === 'ALL' ? '7j, 14j et 28j' : `${selectedAge} jours`}
        </div>
      </div>

      {/* Item List with all 3 age milestones clearly visible */}
      {filteredItems.length === 0 ? (
        <div className="py-8 text-center text-slate-400 text-xs">
          Aucun procès-verbal d'écrasement ne correspond aux filtres sélectionnés.
        </div>
      ) : (
        <div className="divide-y divide-slate-100">
          {filteredItems.map(item => {
            const activeDeadline = item.deadlines[item.activeAge as 7 | 14 | 28] || item.deadlines[28];
            return (
              <div
                key={item.id}
                className="py-3 px-2 sm:px-3 hover:bg-slate-50/80 rounded-lg transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-3"
              >
                {/* Left Details */}
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div
                    className={`p-2 rounded-lg flex-shrink-0 font-tech font-bold text-xs flex flex-col items-center justify-center w-12 text-center ${
                      item.activeAge === 7
                        ? 'bg-blue-100 text-blue-900 border border-blue-200'
                        : item.activeAge === 14
                        ? 'bg-amber-100 text-amber-900 border border-amber-200'
                        : 'bg-teal-100 text-teal-900 border border-teal-200'
                    }`}
                  >
                    <span className="text-sm font-extrabold">{item.activeAge}j</span>
                    <span className="text-[9px] uppercase">Âge</span>
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-900">
                        {item.pvNumber}
                      </span>
                      <span className={`text-[10px] px-2 py-0.2 rounded font-bold uppercase ${
                        item.activeAge === 7
                          ? 'bg-blue-100 text-blue-800'
                          : item.activeAge === 14
                          ? 'bg-amber-100 text-amber-900'
                          : 'bg-teal-100 text-teal-900'
                      }`}>
                        PV {item.activeAge} Jours
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 font-mono">
                        Éch. {item.sampleNumber}
                      </span>
                      {item.clientName && (
                        <span className="text-xs text-slate-500 truncate max-w-xs">
                          • {item.clientName}
                        </span>
                      )}
                    </div>

                    <h4 className="text-xs sm:text-sm font-semibold text-slate-800 mt-0.5 truncate">
                      Béton {item.concreteClass} — {item.projectName}
                    </h4>

                    {/* All 3 Age milestones displayed equally */}
                    <div className="flex flex-wrap items-center gap-2 sm:gap-4 mt-1.5 text-[11px]">
                      <div className="flex items-center gap-1 text-slate-500">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>Confection : <strong>{item.confectionDate}</strong></span>
                      </div>

                      {/* 7d milestone */}
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 ${
                        item.activeAge === 7
                          ? 'bg-blue-100 text-blue-900 border border-blue-300 font-bold'
                          : 'bg-slate-100 text-slate-600'
                      }`}>
                        7j : {item.deadlines[7].dueDateFormatted} ({item.deadlines[7].statusLabel})
                      </span>

                      {/* 14d milestone */}
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 ${
                        item.activeAge === 14
                          ? 'bg-amber-100 text-amber-950 border border-amber-300 font-bold'
                          : 'bg-slate-100 text-slate-600'
                      }`}>
                        14j : {item.deadlines[14].dueDateFormatted} ({item.deadlines[14].statusLabel})
                      </span>

                      {/* 28d milestone */}
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 ${
                        item.activeAge === 28
                          ? 'bg-teal-100 text-teal-950 border border-teal-300 font-bold'
                          : 'bg-slate-100 text-slate-600'
                      }`}>
                        28j : {item.deadlines[28].dueDateFormatted} ({item.deadlines[28].statusLabel})
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right Status & Direct Action */}
                <div className="flex items-center justify-between lg:justify-end gap-3 self-end lg:self-center">
                  <div className="text-right">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${
                        activeDeadline.statusColor === 'emerald'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : activeDeadline.statusColor === 'amber'
                          ? 'bg-amber-100 text-amber-900 border border-amber-400'
                          : activeDeadline.statusColor === 'red'
                          ? 'bg-red-100 text-red-900 border border-red-400'
                          : 'bg-blue-50 text-blue-900 border border-blue-200'
                      }`}
                    >
                      {activeDeadline.status === 'READY' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                      {activeDeadline.status === 'URGENT' && <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />}
                      {activeDeadline.status === 'OVERDUE' && <ShieldAlert className="w-3.5 h-3.5 text-red-600" />}
                      {activeDeadline.status === 'IN_PROGRESS' && <Clock className="w-3.5 h-3.5 text-blue-600" />}
                      {activeDeadline.statusLabel}
                    </span>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      {activeDeadline.elapsedDays} jours de cure écoulés
                    </div>
                  </div>

                  {onSelectPV && (
                    <button
                      onClick={() => onSelectPV(item.pv)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
                      title="Consulter ce procès-verbal"
                    >
                      <span>Ouvrir PV</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

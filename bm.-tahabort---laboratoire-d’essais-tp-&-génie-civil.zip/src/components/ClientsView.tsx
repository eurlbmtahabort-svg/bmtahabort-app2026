import React, { useState } from 'react';
import {
  Users,
  Plus,
  Search,
  Building2,
  Phone,
  Mail,
  MapPin,
  Edit,
  Trash2,
  CheckCircle2,
  FileText,
  Eye,
  X
} from 'lucide-react';
import { Client } from '../types';
import { ALGERIAN_WILAYAS } from '../data/algeriaData';

interface ClientsViewProps {
  clients: Client[];
  onSaveClient: (client: Client) => void;
  onDeleteClient: (id: string) => void;
}

export const ClientsView: React.FC<ClientsViewProps> = ({
  clients,
  onSaveClient,
  onDeleteClient
}) => {
  const [search, setSearch] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [selectedClientDetail, setSelectedClientDetail] = useState<Client | null>(null);
  const [formData, setFormData] = useState<Partial<Client>>({});

  const handleStartNew = () => {
    setFormData({
      id: 'cli-' + Date.now(),
      name: '',
      type: 'ENTREPRISE',
      contactPerson: '',
      phone: '',
      email: '',
      address: '',
      wilaya: '16 - Alger',
      commune: '',
      nif: '',
      nis: '',
      rc: '',
      notes: '',
      createdAt: new Date().toISOString().split('T')[0]
    });
    setIsEditing(true);
    setSelectedClientDetail(null);
  };

  const handleEdit = (c: Client) => {
    setFormData({ ...c });
    setIsEditing(true);
    setSelectedClientDetail(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name?.trim()) {
      alert('Veuillez renseigner la raison sociale du client.');
      return;
    }

    const complete: Client = {
      id: formData.id || 'cli-' + Date.now(),
      name: formData.name.trim(),
      type: formData.type || 'ENTREPRISE',
      contactPerson: formData.contactPerson?.trim() || '',
      phone: formData.phone?.trim() || '',
      email: formData.email?.trim() || '',
      address: formData.address?.trim() || '',
      wilaya: formData.wilaya || '16 - Alger',
      commune: formData.commune?.trim() || '',
      nif: formData.nif?.trim() || undefined,
      nis: formData.nis?.trim() || undefined,
      rc: formData.rc?.trim() || undefined,
      notes: formData.notes?.trim() || '',
      createdAt: formData.createdAt || new Date().toISOString().split('T')[0]
    };

    onSaveClient(complete);
    setIsEditing(false);
  };

  const filtered = clients.filter(c => {
    const q = search.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.contactPerson?.toLowerCase().includes(q) ||
      c.wilaya?.toLowerCase().includes(q) ||
      c.commune?.toLowerCase().includes(q) ||
      c.phone?.includes(q) ||
      c.nif?.toLowerCase().includes(q) ||
      c.rc?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-tech">
              Clients, Entreprises de BTP & Maîtres d'Ouvrage
            </h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
              {clients.length} organismes
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Répertoire des donneurs d'ordre, entreprises de réalisation, bureaux d'études et directions des travaux publics.
          </p>
        </div>

        <button
          onClick={handleStartNew}
          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau Client</span>
        </button>
      </div>

      {isEditing && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-4 sm:p-6">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
            <h3 className="font-bold text-slate-900 text-base font-tech">
              {formData.id && clients.some(c => c.id === formData.id) ? 'Modifier le Client' : 'Nouveau Client'}
            </h3>
            <button
              onClick={() => setIsEditing(false)}
              className="text-slate-400 hover:text-slate-700 text-xs px-2.5 py-1 rounded bg-slate-100 cursor-pointer min-h-[36px]"
            >
              Annuler
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-medium mb-1">
                  Raison Sociale / Nom de l'Organisme <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ex: SARL BATIMENT SAHARA, DTP Ouargla..."
                  value={formData.name || ''}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:bg-white focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Type d'Organisme
                </label>
                <select
                  value={formData.type || 'ENTREPRISE'}
                  onChange={e => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  <option value="ENTREPRISE">Entreprise de Réalisation (BTP / Travaux Publics)</option>
                  <option value="MAITRE_OUVRAGE">Maître d’Ouvrage (DTP, DUC, Entreprise Publique)</option>
                  <option value="BUREAU_ETUDES">Bureau d'Études Techniques (BET)</option>
                  <option value="PARTICULIER">Particulier / Promoteur Privé</option>
                  <option value="AUTRE">Autre Organisme</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Personne à Contacter (Vis-à-vis)
                </label>
                <input
                  type="text"
                  placeholder="Nom & Prénom, Fonction"
                  value={formData.contactPerson || ''}
                  onChange={e => setFormData({ ...formData, contactPerson: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Téléphone
                </label>
                <input
                  type="text"
                  placeholder="+213 29 XX XX XX / 05XX..."
                  value={formData.phone || ''}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Email
                </label>
                <input
                  type="email"
                  placeholder="contact@entreprise.dz"
                  value={formData.email || ''}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Wilaya (Algérie)
                </label>
                <select
                  value={formData.wilaya || '16 - Alger'}
                  onChange={e => setFormData({ ...formData, wilaya: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                >
                  {ALGERIAN_WILAYAS.map(w => {
                    const str = `${w.code} - ${w.name}`;
                    return (
                      <option key={w.code} value={str}>
                        {str}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Commune / Localité
                </label>
                <input
                  type="text"
                  placeholder="ex: Hassi Messaoud, Rouiba..."
                  value={formData.commune || ''}
                  onChange={e => setFormData({ ...formData, commune: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-medium mb-1">
                  Adresse Siège / Chantier
                </label>
                <input
                  type="text"
                  placeholder="Zone Industrielle, Rue, Lotissement..."
                  value={formData.address || ''}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Numéro NIF (Fiscal)
                </label>
                <input
                  type="text"
                  placeholder="ex: 001916012345678"
                  value={formData.nif || ''}
                  onChange={e => setFormData({ ...formData, nif: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Numéro NIS (Statistique)
                </label>
                <input
                  type="text"
                  placeholder="ex: 099816001234"
                  value={formData.nis || ''}
                  onChange={e => setFormData({ ...formData, nis: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Numéro Registre de Commerce (RC)
                </label>
                <input
                  type="text"
                  placeholder="ex: 16/00-1234567B19"
                  value={formData.rc || ''}
                  onChange={e => setFormData({ ...formData, rc: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded font-mono text-slate-900"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-slate-700 font-medium mb-1">
                  Observations / Spécifications particulières
                </label>
                <textarea
                  rows={2}
                  placeholder="Délai de paiement, exigences particulières, agrément..."
                  value={formData.notes || ''}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold cursor-pointer min-h-[44px]"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer min-h-[44px]"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Enregistrer le Client</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Details View Modal */}
      {selectedClientDetail && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-3">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-slate-100 text-slate-700">
                  {selectedClientDetail.type}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1 font-tech">
                  {selectedClientDetail.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedClientDetail(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs text-slate-700">
              <div>
                <span className="font-semibold text-slate-500">Contact / Vis-à-vis : </span>
                <span className="font-medium text-slate-900">{selectedClientDetail.contactPerson || '—'}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500">Téléphone : </span>
                <span className="font-mono text-slate-900">{selectedClientDetail.phone || '—'}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500">Email : </span>
                <span className="text-slate-900">{selectedClientDetail.email || '—'}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500">Localisation : </span>
                <span className="text-slate-900">{selectedClientDetail.wilaya} {selectedClientDetail.commune ? `(${selectedClientDetail.commune})` : ''}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500">Adresse : </span>
                <span className="text-slate-900">{selectedClientDetail.address || '—'}</span>
              </div>

              <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-2 font-mono text-[11px]">
                <div className="p-2 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 font-sans">NIF :</div>
                  <div className="font-bold text-slate-800">{selectedClientDetail.nif || 'Non renseigné'}</div>
                </div>
                <div className="p-2 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[10px] text-slate-500 font-sans">RC :</div>
                  <div className="font-bold text-slate-800">{selectedClientDetail.rc || 'Non renseigné'}</div>
                </div>
                {selectedClientDetail.nis && (
                  <div className="p-2 bg-slate-50 rounded border border-slate-200 col-span-2">
                    <div className="text-[10px] text-slate-500 font-sans">NIS :</div>
                    <div className="font-bold text-slate-800">{selectedClientDetail.nis}</div>
                  </div>
                )}
              </div>

              {selectedClientDetail.notes && (
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="font-semibold text-slate-700 mb-0.5">Notes :</div>
                  <p className="text-slate-600 leading-relaxed">{selectedClientDetail.notes}</p>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
              <button
                onClick={() => {
                  handleEdit(selectedClientDetail);
                  setSelectedClientDetail(null);
                }}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold cursor-pointer"
              >
                Modifier ce client
              </button>
              <button
                onClick={() => setSelectedClientDetail(null)}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main List Container */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher par raison sociale, wilaya, téléphone..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white"
            />
          </div>
        </div>

        {/* Mobile View: Cards */}
        <div className="md:hidden divide-y divide-slate-100">
          {filtered.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              Aucun client ne correspond à votre recherche.
            </div>
          ) : (
            filtered.map(c => (
              <div key={c.id} className="p-4 space-y-2.5">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm font-tech">{c.name}</h4>
                    <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-slate-100 text-slate-700 mt-1 inline-block">
                      {c.type}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setSelectedClientDetail(c)}
                      title="Détails"
                      className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleEdit(c)}
                      title="Modifier"
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer le client ${c.name} ?`)) {
                          onDeleteClient(c.id);
                        }
                      }}
                      title="Supprimer"
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="text-xs text-slate-600 space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                    <span>{c.wilaya} {c.commune ? `• ${c.commune}` : ''}</span>
                  </div>
                  {c.phone && (
                    <div className="flex items-center gap-1.5 text-slate-700">
                      <Phone className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span className="font-mono">{c.phone}</span>
                    </div>
                  )}
                  {(c.nif || c.rc) && (
                    <div className="text-[11px] font-mono text-slate-500 pt-1">
                      {c.nif && <span>NIF: {c.nif} </span>}
                      {c.rc && <span>• RC: {c.rc}</span>}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Desktop View: Full Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Raison Sociale</th>
                <th className="p-3">Type</th>
                <th className="p-3">Contact</th>
                <th className="p-3">Wilaya & Coordonnées</th>
                <th className="p-3">Identifiants Légaux (NIF/RC)</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-500">
                    Aucun client enregistré ou correspondant à la recherche.
                  </td>
                </tr>
              ) : (
                filtered.map(c => (
                  <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 font-semibold text-slate-900">
                      {c.name}
                    </td>
                    <td className="p-3">
                      <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-slate-100 text-slate-700">
                        {c.type}
                      </span>
                    </td>
                    <td className="p-3 text-slate-700">
                      {c.contactPerson || '—'}
                    </td>
                    <td className="p-3">
                      <div className="font-medium text-slate-800">{c.wilaya} {c.commune ? `(${c.commune})` : ''}</div>
                      <div className="text-[11px] text-slate-500">{c.phone || c.email || '—'}</div>
                    </td>
                    <td className="p-3 font-mono text-[11px] text-slate-600">
                      {c.nif && <div>NIF: {c.nif}</div>}
                      {c.rc && <div>RC: {c.rc}</div>}
                      {!c.nif && !c.rc && '—'}
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setSelectedClientDetail(c)}
                          title="Consulter la fiche"
                          className="p-1.5 hover:bg-slate-100 text-slate-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEdit(c)}
                          title="Modifier"
                          className="p-1.5 hover:bg-slate-100 text-blue-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Supprimer le client ${c.name} ?`)) {
                              onDeleteClient(c.id);
                            }
                          }}
                          title="Supprimer"
                          className="p-1.5 hover:bg-red-50 text-red-600 rounded cursor-pointer min-h-[32px] min-w-[32px] flex items-center justify-center"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

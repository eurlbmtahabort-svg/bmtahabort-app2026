import { SpecimenType } from '../types';

/**
 * Calculates cross-sectional area in mm² for standard civil engineering specimens
 */
export function getSpecimenAreaMm2(type: SpecimenType, customAreaMm2?: number): number {
  switch (type) {
    case 'CYLINDRIQUE_16_32':
      // Diameter 160 mm, Height 320 mm. S = pi * d^2 / 4 = pi * 160^2 / 4 = 20106.19 mm²
      return 20106.19;
    case 'CYLINDRIQUE_11_22':
      // Diameter 113 mm, Height 220 mm. S = pi * 113^2 / 4 = 10028.75 mm²
      return 10028.75;
    case 'CUBIQUE_15_15':
      // 150 mm x 150 mm = 22500 mm²
      return 22500.0;
    case 'CUBIQUE_10_10':
      // 100 mm x 100 mm = 10000 mm²
      return 10000.0;
    case 'AUTRE':
    default:
      return customAreaMm2 && customAreaMm2 > 0 ? customAreaMm2 : 20106.19;
  }
}

/**
 * Calculates compressive strength in MPa (N/mm²)
 * Formula: sigma = (F * 1000) / S
 * where F is in kN and S is in mm²
 */
export function calculateCompressiveStrengthMpa(loadKn: number, areaMm2: number): number {
  if (!loadKn || loadKn <= 0 || !areaMm2 || areaMm2 <= 0) {
    return 0;
  }
  const strength = (loadKn * 1000) / areaMm2;
  return Math.round(strength * 100) / 100; // Round to 2 decimal places
}

/**
 * Calculates average compressive strength of valid specimens
 */
export function calculateAverageStrength(strengths: number[]): number {
  const valid = strengths.filter(s => typeof s === 'number' && s > 0);
  if (valid.length === 0) return 0;
  const sum = valid.reduce((acc, curr) => acc + curr, 0);
  return Math.round((sum / valid.length) * 100) / 100;
}

/**
 * Calculates sample standard deviation (écart-type s) in MPa according to NF EN 12390-3
 * Formula: s = sqrt( sum( (x_i - mean)^2 ) / (n - 1) )
 */
export function calculateStandardDeviation(strengths: number[]): number {
  const valid = strengths.filter(s => typeof s === 'number' && s > 0);
  if (valid.length <= 1) return 0;
  const mean = valid.reduce((acc, curr) => acc + curr, 0) / valid.length;
  const variance = valid.reduce((acc, curr) => acc + Math.pow(curr - mean, 2), 0) / (valid.length - 1);
  return Math.round(Math.sqrt(variance) * 100) / 100;
}

/**
 * Dreux-Gorisse / Bolomey target compressive strength calculation:
 * f_cm28 = G * sigma_c * (C/E - 0.5)
 * where:
 * - G = aggregate granular quality coefficient (0.45 to 0.55, default 0.50)
 * - sigma_c = true cement strength class (e.g. 42.5 MPa)
 * - C/E = cement to water ratio
 */
export function calculateBolomeyTargetStrength(params: {
  cementDosageKg: number;
  waterLiter: number;
  cementClassMpa?: number;
  granularCoeffG?: number;
}): number {
  const { cementDosageKg, waterLiter, cementClassMpa = 42.5, granularCoeffG = 0.50 } = params;
  if (!cementDosageKg || !waterLiter || waterLiter <= 0) return 0;
  const cOverE = cementDosageKg / waterLiter;
  if (cOverE <= 0.5) return 0;
  const fcm28 = granularCoeffG * cementClassMpa * (cOverE - 0.5);
  return Math.round(fcm28 * 100) / 100;
}

/**
 * Concrete formulation calculations
 */
export interface FormulationCalculationsResult {
  totalMassKg: number;
  wcRatio: number;
  aggregateSandRatio: number;
  theoreticalDensityKgM3: number;
  formulaNotes: string[];
}

export function calculateConcreteFormulation(params: {
  cementKg: number;
  waterL: number;
  sandKg: number;
  gravel1Kg: number;
  gravel2Kg?: number;
  adjuvantKg?: number;
}): FormulationCalculationsResult {
  const { cementKg, waterL, sandKg, gravel1Kg, gravel2Kg = 0, adjuvantKg = 0 } = params;

  const totalMassKg = (cementKg || 0) + (waterL || 0) + (sandKg || 0) + (gravel1Kg || 0) + (gravel2Kg || 0) + (adjuvantKg || 0);
  
  const wcRatio = cementKg > 0 ? Math.round(((waterL || 0) / cementKg) * 100) / 100 : 0;
  
  const totalGravel = (gravel1Kg || 0) + (gravel2Kg || 0);
  const aggregateSandRatio = sandKg > 0 ? Math.round((totalGravel / sandKg) * 100) / 100 : 0;
  
  // Theoretical density per m³ (typically around 2350 - 2450 kg/m³)
  const theoreticalDensityKgM3 = Math.round(totalMassKg);

  const formulaNotes: string[] = [
    `Rapport Eau/Ciment (E/C) = ${waterL} L / ${cementKg} kg = ${wcRatio}`,
    `Rapport Gravillon/Sable (G/S) = ${totalGravel} kg / ${sandKg} kg = ${aggregateSandRatio}`,
    `Masse totale théorique des constituants pour 1 m³ = ${totalMassKg} kg`
  ];

  return {
    totalMassKg,
    wcRatio,
    aggregateSandRatio,
    theoreticalDensityKgM3,
    formulaNotes
  };
}

/**
 * 14-Day Mandatory Requirement tracking calculation
 * Calculates elapsed days, remaining days and status accurately
 */
export interface Tracking14DaysResult {
  startDate: string;
  targetDays: number;
  elapsedDays: number;
  remainingDays: number;
  isReached: boolean;
  isOverdue: boolean;
  statusLabel: string;
  statusColor: 'emerald' | 'amber' | 'red' | 'slate';
  dueDateFormatted: string;
}

export function compute14DayTracking(startDateStr?: string, targetDurationDays = 14): Tracking14DaysResult | null {
  if (!startDateStr) return null;

  try {
    const start = new Date(startDateStr);
    if (isNaN(start.getTime())) return null;

    // Reset times to midnight for clean calendar-day comparison
    const startDateClean = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    const now = new Date();
    const todayClean = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const diffMs = todayClean.getTime() - startDateClean.getTime();
    const elapsedDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const remainingDays = targetDurationDays - elapsedDays;

    const dueDate = new Date(startDateClean);
    dueDate.setDate(dueDate.getDate() + targetDurationDays);
    const dueDateFormatted = dueDate.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });

    const isReached = remainingDays === 0;
    const isOverdue = remainingDays < 0;

    let statusLabel = '';
    let statusColor: 'emerald' | 'amber' | 'red' | 'slate' = 'emerald';

    if (elapsedDays < 0) {
      statusLabel = `Démarre dans ${Math.abs(elapsedDays)} j`;
      statusColor = 'slate';
    } else if (remainingDays > 3) {
      statusLabel = `${remainingDays} j restants (${elapsedDays}/${targetDurationDays} j)`;
      statusColor = 'emerald';
    } else if (remainingDays > 0) {
      statusLabel = `Urgent : ${remainingDays} j restants (${elapsedDays}/${targetDurationDays} j)`;
      statusColor = 'amber';
    } else if (remainingDays === 0) {
      statusLabel = `Échéance 14 jours atteinte aujourd'hui !`;
      statusColor = 'amber';
    } else {
      statusLabel = `Délai 14 jours dépassé de ${Math.abs(remainingDays)} j`;
      statusColor = 'red';
    }

    return {
      startDate: startDateStr,
      targetDays: targetDurationDays,
      elapsedDays,
      remainingDays,
      isReached,
      isOverdue,
      statusLabel,
      statusColor,
      dueDateFormatted
    };
  } catch {
    return null;
  }
}

import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Capacitor } from '@capacitor/core';

/**
 * Utility to reliably save, share and download files (Excel, JSON, CSV, printable HTML)
 * across mobile browsers, Capacitor Android WebViews, and desktop browsers.
 */

export interface ExportResult {
  success: boolean;
  method: 'share' | 'download' | 'fallback';
  message: string;
}

/**
 * Helper to convert various content types to base64 for Capacitor Filesystem
 */
async function toBase64(content: Blob | ArrayBuffer | Uint8Array | string): Promise<string> {
  if (typeof content === 'string') {
    if (content.startsWith('data:')) {
      return content.split(',')[1];
    }
    // Encode utf-8 string to base64
    return btoa(unescape(encodeURIComponent(content)));
  }

  let arrayBuffer: ArrayBuffer;
  if (content instanceof Blob) {
    arrayBuffer = await content.arrayBuffer();
  } else if (content instanceof Uint8Array) {
    arrayBuffer = content.buffer.slice(content.byteOffset, content.byteOffset + content.byteLength);
  } else {
    arrayBuffer = content;
  }

  let binary = '';
  const bytes = new Uint8Array(arrayBuffer);
  const len = bytes.byteLength;
  const CHUNK_SIZE = 8192;
  for (let i = 0; i < len; i += CHUNK_SIZE) {
    const chunk = bytes.subarray(i, Math.min(i + CHUNK_SIZE, len));
    binary += String.fromCharCode.apply(null, chunk as any);
  }
  return btoa(binary);
}

/**
 * Robust file saver that supports:
 * 1. Capacitor Filesystem & Share Sheet (Native Android APK / iOS)
 * 2. Web Share API (Mobile Web / browsers)
 * 3. Standard Blob ObjectURL + <a> download click (Desktop)
 * 4. Data URI fallback for restricted webviews
 */
export async function saveExportFile(
  content: Blob | ArrayBuffer | Uint8Array | string,
  filename: string,
  mimeType: string
): Promise<ExportResult> {
  try {
    const isNativeCapacitor = Capacitor.isNativePlatform() || (window as any).Capacitor !== undefined;

    // 1. Native Capacitor Android / iOS integration: write to cache and share via Android Share Sheet
    if (isNativeCapacitor) {
      try {
        const base64Data = await toBase64(content);

        // Write file to Cache directory (handled cleanly by FileProvider)
        const writeResult = await Filesystem.writeFile({
          path: filename,
          data: base64Data,
          directory: Directory.Cache
        });

        const fileUri = writeResult.uri;

        // Trigger native Android Share Sheet
        await Share.share({
          title: filename,
          text: `Document Laboratoire BM. TAHABORT : ${filename}`,
          url: fileUri,
          dialogTitle: `Partager / Enregistrer ${filename}`
        });

        return {
          success: true,
          method: 'share',
          message: `Le fichier "${filename}" a été partagé / enregistré via la feuille Android.`
        };
      } catch (capErr: any) {
        // User dismissed share dialog
        if (
          capErr?.message?.includes('canceled') ||
          capErr?.message?.includes('cancelled') ||
          capErr?.name === 'AbortError'
        ) {
          return {
            success: true,
            method: 'share',
            message: `Opération d'exportation terminée.`
          };
        }
        console.warn('Capacitor native share failed, falling back to Web API:', capErr);
      }
    }

    // Prepare standard blob for Web Share or download anchor
    let blob: Blob;
    if (content instanceof Blob) {
      blob = content;
    } else if (typeof content === 'string') {
      blob = new Blob([content], { type: mimeType });
    } else {
      blob = new Blob([content], { type: mimeType });
    }

    const isMobile =
      /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

    // 2. Web Share API fallback (for mobile browsers)
    if (isMobile && typeof navigator !== 'undefined' && 'share' in navigator) {
      try {
        const file = new File([blob], filename, { type: mimeType });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: filename,
            text: `Document exporté du laboratoire BM. TAHABORT : ${filename}`
          });
          return {
            success: true,
            method: 'share',
            message: `Le fichier "${filename}" a été partagé / enregistré avec succès.`
          };
        }
      } catch (shareErr: any) {
        if (shareErr?.name === 'AbortError') {
          return {
            success: true,
            method: 'share',
            message: `Opération d'exportation annulée par l'utilisateur.`
          };
        }
        console.warn('Web Share API failed, falling back to download anchor:', shareErr);
      }
    }

    // 3. Standard Blob URL download fallback (Desktop browsers)
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();

    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 1000);

    return {
      success: true,
      method: 'download',
      message: `Téléchargement du fichier "${filename}" démarré avec succès.`
    };
  } catch (err: any) {
    console.error('saveExportFile error:', err);

    // 4. Fallback: try Data URI for text/JSON
    if (typeof content === 'string') {
      try {
        const dataUri = `data:${mimeType};charset=utf-8,` + encodeURIComponent(content);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = dataUri;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => document.body.removeChild(a), 1000);
        return {
          success: true,
          method: 'fallback',
          message: `Téléchargement de secours initié pour "${filename}".`
        };
      } catch (dataUriErr) {
        console.error('Data URI download failed:', dataUriErr);
      }
    }

    return {
      success: false,
      method: 'fallback',
      message: `Impossible de sauvegarder le fichier : ${err?.message || 'Erreur inconnue'}`
    };
  }
}

/**
 * Safely trigger printing with native AndroidPrint bridge support in Capacitor WebView
 */
export function safeTriggerPrint(documentTitle?: string): { success: boolean; message: string } {
  try {
    // 1. Android Native Print Interface registered in MainActivity.java
    const androidPrint = (window as any).AndroidPrint;
    if (androidPrint) {
      if (typeof androidPrint.printDocument === 'function') {
        androidPrint.printDocument(documentTitle || 'Document_BM_TAHABORT');
        return {
          success: true,
          message: "Gestionnaire d'impression Android lancé avec succès."
        };
      } else if (typeof androidPrint.print === 'function') {
        androidPrint.print();
        return {
          success: true,
          message: "Gestionnaire d'impression Android lancé avec succès."
        };
      }
    }

    // 2. Standard browser window.print()
    if (typeof window !== 'undefined' && typeof window.print === 'function') {
      window.print();
      return {
        success: true,
        message: "Commande d'impression envoyée au système."
      };
    } else {
      return {
        success: false,
        message: "La fonction d'impression directe n'est pas supportée. Utilisez le bouton de partage ou l'aperçu PDF."
      };
    }
  } catch (err: any) {
    console.warn('safeTriggerPrint error:', err);
    return {
      success: false,
      message: "Erreur lors de l'appel à l'imprimante : " + (err?.message || 'Veuillez utiliser le bouton de partage ou de téléchargement.')
    };
  }
}

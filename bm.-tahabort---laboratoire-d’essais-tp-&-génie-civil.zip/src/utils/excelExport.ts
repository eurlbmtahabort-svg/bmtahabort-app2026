import * as XLSX from 'xlsx';
import { CompressionPV, ConcreteFormulation, LabReport, LabSettings, LabTest, Sample } from '../types';
import { saveExportFile } from './fileExportUtils';

/**
 * Utility to generate and download professional Excel workbooks (.xlsx)
 * using SheetJS with genuine spreadsheet table structures, numeric formats,
 * metadata headers and laboratory credentials for BM. TAHABORT.
 */

const DEFAULT_LAB_HEADER = (settings?: LabSettings) => [
  ['🏢 ' + (settings?.companyName || 'BM. TAHABORT')],
  [(settings?.laboratorySubtitle || 'LABORATOIRE D’ESSAIS DE TRAVAUX PUBLICS & GÉNIE CIVIL')],
  [
    `Wilaya : ${settings?.wilaya || '16 - Alger'} | Tél : ${settings?.phone || '+213 (0) 23 45 67 89'} | Email : ${settings?.email || 'eurlbmtahabort@gmail.com'}`
  ],
  [
    `NIF : ${settings?.nif || '001916012345678'} | RC : ${settings?.rc || '16/00-1234567B19'} | NIS : ${settings?.nis || '0019160123456'}`
  ],
  ['']
];

/**
 * EXPORT INDEPENDENT COMPRESSION TEST REPORT (7J, 14J, OR 28J) TO EXCEL (.xlsx)
 */
export async function exportCompressionPVToExcel(pv: CompressionPV, settings?: LabSettings) {
  const age = pv.concreteAgeDays || 28;
  const director = pv.directorName || settings?.directorName || 'Ing. B. Mourad (Directeur Technique)';
  const technician = pv.technicianName || pv.operator || settings?.technicianName || 'Technicien Supérieur Laboratoire';

  const rows: any[][] = [
    ...DEFAULT_LAB_HEADER(settings),
    [`PROCÈS-VERBAL D'ESSAI D'ÉCRASEMENT DU BÉTON À ${age} JOURS`],
    [`RÉFÉRENCE PV N° : ${pv.pvNumber}`, `NORME D'ESSAI : NF EN 12390-3 / NA 437`, `DATE ÉMISSION : ${pv.crushingDate || new Date().toISOString().split('T')[0]}`],
    [''],
    ['1. IDENTIFICATION DU PROJET & DU CLIENT'],
    ['Client / Demandeur :', pv.clientName || '—', 'Date de Prélèvement :', pv.samplingDate || '—'],
    ['Projet / Ouvrage :', pv.projectName || '—', 'Date de Confection :', pv.confectionDate || '—'],
    ['Chantier / Localisation :', pv.chantierName || '—', 'Date d\'Écrasement :', pv.crushingDate || '—'],
    ['N° Échantillon :', pv.sampleNumber || '—', 'Âge du Béton :', `${age} JOURS`],
    ['Classe de Résistance Visée :', pv.concreteClass || 'C25/30', 'Résistance Visée fck :', pv.targetStrengthMpa ? `${pv.targetStrengthMpa} MPa` : '—'],
    ['Type d\'Éprouvettes :', (pv.specimenType || '').replace(/_/g, ' '), 'Machine d\'Essai :', pv.machineUsed || 'Presse Hydraulique 2000 kN étalonnée'],
    [''],
    ['2. RÉSULTATS D\'ESSAIS D\'ÉCRASEMENT (NF EN 12390-3)'],
    ['N°', 'Dimensions & Format', 'Section S (mm²)', 'Masse (g)', 'Charge Max F (kN)', 'Résistance fc (MPa)', 'Mode de Rupture']
  ];

  pv.specimens.forEach(s => {
    rows.push([
      s.index,
      s.dimensionsDescription || 'Cylindre Ø160×320 mm',
      s.areaMm2 ? Number(s.areaMm2.toFixed(1)) : 20106.2,
      s.massG ? Number(s.massG.toFixed(0)) : '',
      s.maxLoadKn ? Number(s.maxLoadKn.toFixed(1)) : 0,
      s.strengthMpa ? Number(s.strengthMpa.toFixed(2)) : 0,
      s.failureMode || 'Rupture normale (cône satisfaisant)'
    ]);
  });

  rows.push(
    [''],
    [
      '',
      `RÉSISTANCE MOYENNE fcm (${age} JOURS) :`,
      '',
      '',
      '',
      pv.averageStrengthMpa ? `${pv.averageStrengthMpa.toFixed(2)} MPa` : '0.00 MPa',
      pv.standardDeviationMpa !== undefined ? `Écart-type s = ${pv.standardDeviationMpa.toFixed(2)} MPa` : ''
    ],
    [''],
    ['3. OBSERVATIONS & CONFORMITÉ TECHNIQUE'],
    ['Conditions de Conservation :', pv.observations || 'Conservation en eau saturée à 20°C ± 2°C conformément à la norme NF EN 12390-2.'],
    ['Observation de Conformité :', pv.complianceObservation || 'Résultats conformes aux exigences du cahier des charges et de la classe prescrite.'],
    ['Conclusion Finale :', pv.conclusion || 'Essai validé selon les critères métrologiques et normatifs.'],
    [''],
    ['4. SIGNATAIRES OFFICIELS (ARCHIVAGE IMMUABLE)'],
    ['Opérateur / Technicien Responsable :', technician],
    ['Directeur Technique du Laboratoire :', director],
    [''],
    ['Ce procès-verbal d\'essai ne concerne que les échantillons soumis aux essais. Reproduction interdite sans accord écrit de BM. TAHABORT.']
  );

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  ws['!cols'] = [
    { wch: 8 },
    { wch: 30 },
    { wch: 18 },
    { wch: 14 },
    { wch: 20 },
    { wch: 22 },
    { wch: 35 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, `PV_${age}J`);
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const filename = `PV_Ecrasement_${age}J_${pv.pvNumber}_${pv.crushingDate || 'Export'}.xlsx`;

  return await saveExportFile(
    wbout,
    filename,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
}

/**
 * EXPORT MULTI-SECTION CONCRETE FORMULATION DOSSIER TO EXCEL (.xlsx)
 */
export async function exportFormulationToExcel(form: ConcreteFormulation, settings?: LabSettings) {
  const director = form.approvedBy || settings?.directorName || 'Ing. B. Mourad (Directeur Technique)';
  const technician = form.preparedBy || settings?.technicianName || 'Technicien Supérieur Formulation Béton';

  const rows: any[][] = [
    ...DEFAULT_LAB_HEADER(settings),
    [`DOSSIER D'ÉTUDE DE FORMULATION DE BÉTON HYDRAULIQUE (MÉTHODE DREUX-GORISSE)`],
    [`RÉFÉRENCE FORMULATION N° : ${form.formulationNumber}`, `DATE DE L'ÉTUDE : ${form.date}`],
    [''],
    ['SECTION 1 : IDENTIFICATION DE L\'OUVRAGE & OBJECTIFS TECHNIQUES'],
    ['Projet / Ouvrage :', form.projectName || '—', 'Client / Demandeur :', form.clientName || '—'],
    ['Chantier :', form.chantierName || '—', 'Date de Conception :', form.date],
    ['Type de Béton :', form.concreteType, 'Classe de Résistance :', form.strengthClass],
    ['Consistance Ciblée :', `Classe ${form.consistency} (Affaissement visé : ${form.targetSlumpMm} mm)`],
    ['Dmax des Granulats :', `${form.dMaxMm} mm`, 'Type de Ciment :', form.cementType],
    ['Rapport E/C Théorique :', Number(form.wcRatio.toFixed(2))],
    [''],
    ['SECTION 2 : COMPOSITION & DOSAGE NOMINAL POUR 1,00 m³ DE BÉTON FRAIS'],
    ['Constituant', 'Spécification / Provenance', 'Dosage en Masse (kg/m³)', 'Unité'],
    ['Ciment', form.cementType, Number(form.cementDosageKg.toFixed(1)), 'kg/m³'],
    ['Eau Efficace', 'Eau de gâchage propre (NF EN 1008)', Number(form.waterLiter.toFixed(1)), 'Litres'],
    ['Sable', 'Sable d\'oued / concassé 0/4 mm', Number(form.sandKg.toFixed(1)), 'kg/m³'],
    ['Gravillon 1', 'Gravillon concassé 3/8 ou 4/10 mm', Number(form.gravel1Kg.toFixed(1)), 'kg/m³']
  ];

  if (form.gravel2Kg) {
    rows.push(['Gravillon 2', 'Gravillon concassé 8/15 ou 8/20 mm', Number(form.gravel2Kg.toFixed(1)), 'kg/m³']);
  }
  if (form.adjuvantType) {
    rows.push(['Adjuvant', form.adjuvantType, Number((form.adjuvantDosageKg || 0).toFixed(2)), 'kg/m³']);
  }
  if (form.otherConstituents && form.otherConstituents.length > 0) {
    form.otherConstituents.forEach(c => {
      rows.push([c.name, c.designation, Number(c.quantityKg.toFixed(1)), 'kg/m³']);
    });
  }

  rows.push(
    ['Masse Volumique Théorique Estimée', '', Number(form.theoreticalDensityKgM3.toFixed(0)), 'kg/m³'],
    [''],
    ['SECTION 3 : CONTRÔLE DES PERFORMANCES (CIBLES VS MESURÉES)'],
    ['Paramètre Métrologique', 'Valeur Ciblée', 'Valeur Mesurée en Laboratoire'],
    ['Affaissement au cône d\'Abrams', `${form.targetSlumpMm} mm`, form.measuredSlumpMm ? `${form.measuredSlumpMm} mm` : 'En cours d\'essai'],
    ['Résistance à la compression à 7 jours', form.targetStrength7jMpa ? `${form.targetStrength7jMpa} MPa` : '—', form.measuredStrength7jMpa ? `${form.measuredStrength7jMpa} MPa` : 'En cours'],
    ['Résistance caractéristique à 28 jours (fck)', form.targetStrength28jMpa ? `${form.targetStrength28jMpa} MPa` : '—', form.measuredStrength28jMpa ? `${form.measuredStrength28jMpa} MPa` : 'En cours'],
    [''],
    ['SECTION 4 : AVIS TECHNIQUE & SIGNATAIRES'],
    ['Observations Techniques :', form.observations || 'Étude de formulation optimisée selon la méthode Dreux-Gorisse et les granulats locaux.'],
    ['Étude Réalisée par (Technicien) :', technician],
    ['Validé et Approuvé par (Directeur) :', director]
  );

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  ws['!cols'] = [
    { wch: 32 },
    { wch: 36 },
    { wch: 26 },
    { wch: 14 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Formulation');
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const filename = `Etude_Formulation_Beton_${form.formulationNumber}_${form.date}.xlsx`;

  return await saveExportFile(
    wbout,
    filename,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
}

/**
 * EXPORT ALL FORMULATIONS TABLE TO EXCEL (.xlsx)
 */
export async function exportFormulationsListToExcel(forms: ConcreteFormulation[], settings?: LabSettings) {
  const rows: any[][] = [
    ...DEFAULT_LAB_HEADER(settings),
    ['REGISTRE CONSOLIDÉ DES ÉTUDES DE FORMULATION DE BÉTON (DREUX-GORISSE)'],
    [`Date d'exportation : ${new Date().toLocaleDateString('fr-FR')}`, `Nombre de formulations : ${forms.length}`],
    [''],
    [
      'N° Formulation',
      'Projet',
      'Client',
      'Chantier',
      'Date',
      'Type de Béton',
      'Classe de Résistance',
      'Consistance',
      'Affaissement Visé (mm)',
      'Dosage Ciment (kg/m³)',
      'Eau Efficace (L/m³)',
      'Rapport E/C',
      'Sable (kg/m³)',
      'Gravillon 1 (kg/m³)',
      'Gravillon 2 (kg/m³)',
      'Adjuvant',
      'fc28 Cible (MPa)',
      'fc28 Mesuré (MPa)',
      'Statut'
    ]
  ];

  forms.forEach(f => {
    rows.push([
      f.formulationNumber,
      f.projectName || '',
      f.clientName || '',
      f.chantierName || '',
      f.date,
      f.concreteType || '',
      f.strengthClass || '',
      f.consistency || '',
      f.targetSlumpMm || '',
      f.cementDosageKg ? Number(f.cementDosageKg.toFixed(1)) : '',
      f.waterLiter ? Number(f.waterLiter.toFixed(1)) : '',
      f.wcRatio ? Number(f.wcRatio.toFixed(2)) : '',
      f.sandKg ? Number(f.sandKg.toFixed(1)) : '',
      f.gravel1Kg ? Number(f.gravel1Kg.toFixed(1)) : '',
      f.gravel2Kg ? Number(f.gravel2Kg.toFixed(1)) : '',
      f.adjuvantType ? `${f.adjuvantType} (${f.adjuvantDosageKg || 0} kg)` : '',
      f.targetStrength28jMpa || '',
      f.measuredStrength28jMpa || '',
      f.status || 'VALIDE'
    ]);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  ws['!cols'] = [
    { wch: 18 },
    { wch: 28 },
    { wch: 24 },
    { wch: 20 },
    { wch: 14 },
    { wch: 20 },
    { wch: 18 },
    { wch: 14 },
    { wch: 18 },
    { wch: 18 },
    { wch: 16 },
    { wch: 14 },
    { wch: 14 },
    { wch: 16 },
    { wch: 16 },
    { wch: 22 },
    { wch: 16 },
    { wch: 16 },
    { wch: 14 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Formulations');
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const filename = `Registre_Formulations_Beton_BM_TAHABORT_${new Date().toISOString().split('T')[0]}.xlsx`;

  return await saveExportFile(
    wbout,
    filename,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
}

/**
 * EXPORT GENERAL REPORT TO EXCEL (.xlsx)
 */
export async function exportLabReportToExcel(report: LabReport, settings?: LabSettings) {
  const director = report.approvedBy || report.directorName || settings?.directorName || 'Ing. B. Mourad (Directeur Technique)';
  const technician = report.preparedBy || report.technicianName || settings?.technicianName || 'Technicien Supérieur Laboratoire';

  const rows: any[][] = [
    ...DEFAULT_LAB_HEADER(settings),
    [`RAPPORT TECHNIQUE & PROCÈS-VERBAL D'ESSAIS N° ${report.reportNumber}`],
    [`INTITULÉ : ${report.title}`, `DATE D'ÉMISSION : ${report.date}`],
    [''],
    ['1. IDENTIFICATION DU DOSSIER'],
    ['Projet Rattaché :', report.projectName || '—', 'Client / Demandeur :', report.clientName || '—'],
    ['Type de Rapport :', report.type, 'Statut du Document :', report.status],
    [''],
    ['2. CONTENU TECHNIQUE & SYNTHÈSE DES ESSAIS'],
    ['Synthèse des Mesures :', report.contentSummary || report.summary || 'Synthèse des essais géotechniques et contrôles normalisés.'],
    [''],
    ['3. CONCLUSION & AVIS TECHNIQUE DU LABORATOIRE'],
    ['Conclusion :', report.conclusion || 'Matériaux déclarés conformes aux exigences normatives.'],
    [''],
    ['4. SIGNATAIRES OFFICIELS'],
    ['Rédigé par (Technicien) :', technician],
    ['Approuvé par (Directeur Technique) :', director]
  ];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  ws['!cols'] = [
    { wch: 28 },
    { wch: 45 },
    { wch: 24 },
    { wch: 30 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Rapport');
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const filename = `Rapport_Technique_${report.reportNumber}_${report.date}.xlsx`;

  return await saveExportFile(
    wbout,
    filename,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
}

/**
 * EXPORT ALL COMPRESSION PVs TABLE TO EXCEL (.xlsx)
 */
export async function exportCompressionPVsListToExcel(pvs: CompressionPV[], settings?: LabSettings) {
  const rows: any[][] = [
    ...DEFAULT_LAB_HEADER(settings),
    ['REGISTRE CONSOLIDÉ DES PROCÈS-VERBAUX D\'ÉCRASEMENT DU BÉTON'],
    [`Date d'exportation : ${new Date().toLocaleDateString('fr-FR')}`, `Nombre de PV : ${pvs.length}`],
    [''],
    [
      'N° PV',
      'Projet',
      'Client',
      'Chantier',
      'Échéance (Jours)',
      'Classe de Béton',
      'Date Confection',
      'Date Écrasement',
      'Résistance Cible (MPa)',
      'Résistance Obtenue fcm (MPa)',
      'Écart-type s (MPa)',
      'Statut Conformité',
      'Opérateur',
      'Directeur Technique'
    ]
  ];

  pvs.forEach(pv => {
    rows.push([
      pv.pvNumber,
      pv.projectName || '',
      pv.clientName || '',
      pv.chantierName || '',
      pv.concreteAgeDays || 28,
      pv.concreteClass || '',
      pv.confectionDate || '',
      pv.crushingDate || '',
      pv.targetStrengthMpa ? Number(pv.targetStrengthMpa.toFixed(1)) : '',
      pv.averageStrengthMpa ? Number(pv.averageStrengthMpa.toFixed(2)) : '',
      pv.standardDeviationMpa !== undefined ? Number(pv.standardDeviationMpa.toFixed(2)) : '',
      pv.status || 'VALIDE',
      pv.technicianName || pv.operator || '',
      pv.directorName || ''
    ]);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  ws['!cols'] = [
    { wch: 18 },
    { wch: 28 },
    { wch: 24 },
    { wch: 20 },
    { wch: 16 },
    { wch: 16 },
    { wch: 14 },
    { wch: 14 },
    { wch: 18 },
    { wch: 22 },
    { wch: 16 },
    { wch: 18 },
    { wch: 24 },
    { wch: 24 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Registre_PV');
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const filename = `Registre_PV_Ecrasement_BM_TAHABORT_${new Date().toISOString().split('T')[0]}.xlsx`;

  return await saveExportFile(
    wbout,
    filename,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
}

/**
 * EXPORT ALL TESTS TABLE TO EXCEL (.xlsx)
 */
export async function exportTestsListToExcel(tests: LabTest[], settings?: LabSettings) {
  const rows: any[][] = [
    ...DEFAULT_LAB_HEADER(settings),
    ['REGISTRE OFFICIEL DES ESSAIS DE LABORATOIRE (GÉNIE CIVIL & TP)'],
    [`Date d'exportation : ${new Date().toLocaleDateString('fr-FR')}`, `Nombre d'essais : ${tests.length}`],
    [''],
    [
      'N° Essai',
      'Type d\'Essai',
      'Catégorie',
      'Norme de Référence',
      'Projet',
      'Client',
      'Chantier',
      'Date Réalisation',
      'Échantillon',
      'Résultat Obtenu',
      'Statut',
      'Opérateur',
      'Conclusion / Observation'
    ]
  ];

  tests.forEach(t => {
    rows.push([
      t.testNumber,
      t.testType,
      t.category,
      t.standardRef,
      t.projectName || '',
      t.clientName || '',
      t.chantierName || '',
      t.dateRealized,
      t.sampleNumber || '',
      t.resultValue !== undefined ? `${t.resultValue} ${t.resultUnit || ''}` : '',
      t.status,
      t.operator || '',
      t.conclusion || t.complianceObservation || ''
    ]);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  ws['!cols'] = [
    { wch: 16 },
    { wch: 30 },
    { wch: 16 },
    { wch: 18 },
    { wch: 26 },
    { wch: 22 },
    { wch: 20 },
    { wch: 14 },
    { wch: 16 },
    { wch: 18 },
    { wch: 16 },
    { wch: 20 },
    { wch: 35 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Registre_Essais');
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const filename = `Registre_Essais_Laboratoire_BM_TAHABORT_${new Date().toISOString().split('T')[0]}.xlsx`;

  return await saveExportFile(
    wbout,
    filename,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
}

/**
 * EXPORT ALL GENERAL REPORTS TO EXCEL (.xlsx)
 */
export async function exportReportsListToExcel(reports: LabReport[], settings?: LabSettings) {
  const rows: any[][] = [
    ...DEFAULT_LAB_HEADER(settings),
    ['REGISTRE GÉNÉRAL DES RAPPORTS & PROCÈS-VERBAUX TECHNIQUES'],
    [`Date d'exportation : ${new Date().toLocaleDateString('fr-FR')}`, `Nombre de rapports : ${reports.length}`],
    [''],
    [
      'N° Rapport',
      'Date',
      'Intitulé du Rapport',
      'Projet',
      'Client',
      'Type Document',
      'Statut',
      'Rédigé par',
      'Approuvé par',
      'Conclusion & Avis Technique'
    ]
  ];

  reports.forEach(r => {
    rows.push([
      r.reportNumber,
      r.date,
      r.title,
      r.projectName || '—',
      r.clientName || '—',
      r.type,
      r.status,
      r.technicianName || r.preparedBy || '—',
      r.directorName || r.approvedBy || '—',
      r.conclusion || '—'
    ]);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  ws['!cols'] = [
    { wch: 18 },
    { wch: 14 },
    { wch: 38 },
    { wch: 30 },
    { wch: 24 },
    { wch: 18 },
    { wch: 14 },
    { wch: 24 },
    { wch: 26 },
    { wch: 50 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Rapports');
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const filename = `Registre_Rapports_Techniques_BM_TAHABORT_${new Date().toISOString().split('T')[0]}.xlsx`;

  return await saveExportFile(
    wbout,
    filename,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
}

/**
 * EXPORT SAMPLES REGISTER TABLE TO EXCEL (.xlsx)
 */
export async function exportSamplesListToExcel(samples: Sample[], settings?: LabSettings) {
  const rows: any[][] = [
    ...DEFAULT_LAB_HEADER(settings),
    ['REGISTRE GÉNÉRAL DES PRÉLÈVEMENTS & ÉCHANTILLONS DE LABORATOIRE'],
    [`Date d'exportation : ${new Date().toLocaleDateString('fr-FR')}`, `Nombre de prélèvements : ${samples.length}`],
    [''],
    [
      'N° Échantillon',
      'Matériau',
      'Projet',
      'Client',
      'Chantier',
      'Date Prélèvement',
      'Lieu de Prélèvement',
      'Préleveur / Technicien',
      'Température (°C)',
      'Conditions de Conservation',
      'Statut',
      'Observations'
    ]
  ];

  samples.forEach(s => {
    rows.push([
      s.sampleNumber,
      s.materialType || '',
      s.projectName || '',
      s.clientName || '',
      s.chantierName || '',
      s.samplingDate,
      s.samplingLocation || '',
      s.sampledBy || s.samplerName || '',
      s.ambientTempC !== undefined ? s.ambientTempC : '',
      s.conservationConditions || '',
      s.status || 'RECU',
      s.observations || ''
    ]);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  ws['!cols'] = [
    { wch: 18 },
    { wch: 22 },
    { wch: 36 },
    { wch: 28 },
    { wch: 24 },
    { wch: 16 },
    { wch: 32 },
    { wch: 26 },
    { wch: 16 },
    { wch: 32 },
    { wch: 14 },
    { wch: 40 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Échantillons');
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const filename = `Registre_Echantillons_BM_TAHABORT_${new Date().toISOString().split('T')[0]}.xlsx`;

  return await saveExportFile(
    wbout,
    filename,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
}

import {
  Client,
  Chantier,
  Project,
  Sample,
  LabTest,
  ConcreteFormulation,
  CompressionPV,
  LabReport,
  ActivityLog,
  LabSettings,
  UserProfile
} from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_USERS,
  DEMO_CLIENTS,
  DEMO_CHANTIERS,
  DEMO_PROJECTS,
  DEMO_SAMPLES,
  DEMO_TESTS,
  DEMO_FORMULATIONS,
  DEMO_PVS,
  DEMO_REPORTS,
  DEMO_ACTIVITY_LOGS
} from '../data/demoData';
import { calculateStandardDeviation } from '../utils/engineeringCalculations';

const STORAGE_KEY_PREFIX = 'bmtahabort_lab_';

interface DatabaseSchema {
  settings: LabSettings;
  users: UserProfile[];
  currentUser: UserProfile;
  clients: Client[];
  chantiers: Chantier[];
  projects: Project[];
  samples: Sample[];
  tests: LabTest[];
  formulations: ConcreteFormulation[];
  compressionPVs: CompressionPV[];
  reports: LabReport[];
  activityLogs: ActivityLog[];
  isDemoData: boolean;
  version: string;
}

class DataService {
  private state: DatabaseSchema;
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.state = this.loadFromStorage();
  }

  private loadFromStorage(): DatabaseSchema {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_PREFIX + 'db');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && parsed.projects && parsed.settings) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Error loading data from localStorage', e);
    }

    // Default initial state with demo data
    const initial: DatabaseSchema = {
      settings: INITIAL_SETTINGS,
      users: INITIAL_USERS,
      currentUser: INITIAL_USERS[0],
      clients: DEMO_CLIENTS,
      chantiers: DEMO_CHANTIERS,
      projects: DEMO_PROJECTS,
      samples: DEMO_SAMPLES,
      tests: DEMO_TESTS,
      formulations: DEMO_FORMULATIONS,
      compressionPVs: DEMO_PVS,
      reports: DEMO_REPORTS,
      activityLogs: DEMO_ACTIVITY_LOGS,
      isDemoData: true,
      version: '1.0.0'
    };

    this.saveToStorage(initial);
    return initial;
  }

  private saveToStorage(stateToSave?: DatabaseSchema) {
    try {
      const data = stateToSave || this.state;
      localStorage.setItem(STORAGE_KEY_PREFIX + 'db', JSON.stringify(data));
      this.notifyListeners();
    } catch (e) {
      console.error('Error saving data to localStorage', e);
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners() {
    this.listeners.forEach(fn => fn());
  }

  // --- General Helpers ---
  public isDemoDataActive(): boolean {
    return this.state.isDemoData;
  }

  public clearAllDemoData() {
    this.state.clients = [];
    this.state.chantiers = [];
    this.state.projects = [];
    this.state.samples = [];
    this.state.tests = [];
    this.state.formulations = [];
    this.state.compressionPVs = [];
    this.state.reports = [];
    this.state.isDemoData = false;
    this.addLog({
      action: 'Réinitialisation de la base',
      documentType: 'SYSTEM',
      documentNumber: 'SYS-RESET',
      description: 'Suppression de toutes les données de démonstration. Base prête pour les données réelles.'
    });
    this.saveToStorage();
  }

  public restoreDemoData() {
    this.state.clients = [...DEMO_CLIENTS];
    this.state.chantiers = [...DEMO_CHANTIERS];
    this.state.projects = [...DEMO_PROJECTS];
    this.state.samples = [...DEMO_SAMPLES];
    this.state.tests = [...DEMO_TESTS];
    this.state.formulations = [...DEMO_FORMULATIONS];
    this.state.compressionPVs = [...DEMO_PVS];
    this.state.reports = [...DEMO_REPORTS];
    this.state.activityLogs = [...DEMO_ACTIVITY_LOGS];
    this.state.isDemoData = true;
    this.addLog({
      action: 'Chargement démo',
      documentType: 'SYSTEM',
      documentNumber: 'SYS-DEMO',
      description: 'Chargement du jeu complet de données de démonstration.'
    });
    this.saveToStorage();
  }

  // --- Document Number Generator ---
  public getNextDocumentNumber(type: 'project' | 'client' | 'chantier' | 'sample' | 'test' | 'formulation' | 'pvCompression' | 'report'): string {
    const year = new Date().getFullYear();
    const prefix = this.state.settings.numberingPrefixes[type] || type.toUpperCase();
    
    let currentCount = 0;
    switch (type) {
      case 'project':
        currentCount = this.state.projects.length;
        break;
      case 'client':
        currentCount = this.state.clients.length;
        break;
      case 'chantier':
        currentCount = this.state.chantiers.length;
        break;
      case 'sample':
        currentCount = this.state.samples.length;
        break;
      case 'test':
        currentCount = this.state.tests.length;
        break;
      case 'formulation':
        currentCount = this.state.formulations.length;
        break;
      case 'pvCompression':
        currentCount = this.state.compressionPVs.length;
        break;
      case 'report':
        currentCount = this.state.reports.length;
        break;
    }

    const nextIndex = currentCount + 1;
    const padded = String(nextIndex).padStart(4, '0');
    return `${prefix}-${year}-${padded}`;
  }

  // --- Logs ---
  public addLog(entry: { action: string; documentType: string; documentNumber: string; projectId?: string; description: string }) {
    const now = new Date();
    const formattedDate = now.toLocaleDateString('fr-FR') + ' ' + now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    const log: ActivityLog = {
      id: 'act-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      date: formattedDate,
      user: this.state.currentUser.name,
      userRole: this.state.currentUser.title,
      ...entry
    };
    this.state.activityLogs.unshift(log);
    // Keep max 200 logs
    if (this.state.activityLogs.length > 200) {
      this.state.activityLogs = this.state.activityLogs.slice(0, 200);
    }
  }

  public getActivityLogs(): ActivityLog[] {
    return [...this.state.activityLogs];
  }

  // --- Settings & User ---
  public getSettings(): LabSettings {
    return { ...this.state.settings };
  }

  public updateSettings(settings: LabSettings) {
    this.state.settings = { ...settings };
    this.addLog({
      action: 'Mise à jour des paramètres',
      documentType: 'PARAMETRES',
      documentNumber: 'CONF-LAB',
      description: 'Modification de la configuration générale du laboratoire.'
    });
    this.saveToStorage();
  }

  public getUsers(): UserProfile[] {
    return [...this.state.users];
  }

  public getCurrentUser(): UserProfile {
    return { ...this.state.currentUser };
  }

  public setCurrentUser(user: UserProfile) {
    this.state.currentUser = user;
    this.saveToStorage();
  }

  public saveUser(user: UserProfile) {
    const index = this.state.users.findIndex(u => u.id === user.id);
    if (index >= 0) {
      this.state.users[index] = user;
    } else {
      this.state.users.push(user);
    }
    if (this.state.currentUser.id === user.id) {
      this.state.currentUser = user;
    }
    this.saveToStorage();
  }

  // --- Clients ---
  public getClients(): Client[] {
    return [...this.state.clients];
  }

  public getClientById(id: string): Client | undefined {
    return this.state.clients.find(c => c.id === id);
  }

  public saveClient(client: Client) {
    const index = this.state.clients.findIndex(c => c.id === client.id);
    if (index >= 0) {
      this.state.clients[index] = client;
      this.addLog({
        action: 'Modification d’un client',
        documentType: 'CLIENT',
        documentNumber: client.code,
        description: `Mise à jour des coordonnées du client ${client.name}.`
      });
    } else {
      this.state.clients.unshift(client);
      this.addLog({
        action: 'Création d’un client',
        documentType: 'CLIENT',
        documentNumber: client.code,
        description: `Ajout du nouveau client ${client.name}.`
      });
    }
    this.saveToStorage();
  }

  public deleteClient(id: string) {
    const clt = this.state.clients.find(c => c.id === id);
    this.state.clients = this.state.clients.filter(c => c.id !== id);
    if (clt) {
      this.addLog({
        action: 'Suppression d’un client',
        documentType: 'CLIENT',
        documentNumber: clt.code,
        description: `Suppression du client ${clt.name}.`
      });
    }
    this.saveToStorage();
  }

  // --- Chantiers ---
  public getChantiers(): Chantier[] {
    return [...this.state.chantiers];
  }

  public saveChantier(chantier: Chantier) {
    const index = this.state.chantiers.findIndex(c => c.id === chantier.id);
    if (index >= 0) {
      this.state.chantiers[index] = chantier;
      this.addLog({
        action: 'Modification d’un chantier',
        documentType: 'CHANTIER',
        documentNumber: chantier.code,
        description: `Mise à jour des données du chantier ${chantier.name}.`
      });
    } else {
      this.state.chantiers.unshift(chantier);
      this.addLog({
        action: 'Création d’un chantier',
        documentType: 'CHANTIER',
        documentNumber: chantier.code,
        description: `Création du chantier ${chantier.name}.`
      });
    }
    this.saveToStorage();
  }

  public deleteChantier(id: string) {
    const item = this.state.chantiers.find(c => c.id === id);
    this.state.chantiers = this.state.chantiers.filter(c => c.id !== id);
    if (item) {
      this.addLog({
        action: 'Suppression d’un chantier',
        documentType: 'CHANTIER',
        documentNumber: item.code,
        description: `Suppression du chantier ${item.name}.`
      });
    }
    this.saveToStorage();
  }

  // --- Projects ---
  public getProjects(): Project[] {
    return [...this.state.projects];
  }

  public getProjectById(id: string): Project | undefined {
    return this.state.projects.find(p => p.id === id);
  }

  public saveProject(project: Project) {
    const index = this.state.projects.findIndex(p => p.id === project.id);
    if (index >= 0) {
      this.state.projects[index] = project;
      this.addLog({
        action: 'Modification d’un projet',
        documentType: 'PROJET',
        documentNumber: project.projectNumber,
        projectId: project.id,
        description: `Mise à jour du projet ${project.name} (${project.status}).`
      });
    } else {
      this.state.projects.unshift(project);
      this.addLog({
        action: 'Création d’un projet',
        documentType: 'PROJET',
        documentNumber: project.projectNumber,
        projectId: project.id,
        description: `Ouverture du nouveau projet ${project.name}.`
      });
    }
    this.saveToStorage();
  }

  public deleteProject(id: string) {
    const prj = this.state.projects.find(p => p.id === id);
    this.state.projects = this.state.projects.filter(p => p.id !== id);
    if (prj) {
      this.addLog({
        action: 'Suppression d’un projet',
        documentType: 'PROJET',
        documentNumber: prj.projectNumber,
        description: `Suppression du projet ${prj.name}.`
      });
    }
    this.saveToStorage();
  }

  // --- Samples ---
  public getSamples(): Sample[] {
    return [...this.state.samples];
  }

  public saveSample(sample: Sample) {
    const index = this.state.samples.findIndex(s => s.id === sample.id);
    if (index >= 0) {
      this.state.samples[index] = sample;
      this.addLog({
        action: 'Modification d’un échantillon',
        documentType: 'ECHANTILLON',
        documentNumber: sample.sampleNumber,
        projectId: sample.projectId,
        description: `Mise à jour de l’échantillon ${sample.sampleNumber} (${sample.materialCategory}).`
      });
    } else {
      this.state.samples.unshift(sample);
      this.addLog({
        action: 'Réception d’un échantillon',
        documentType: 'ECHANTILLON',
        documentNumber: sample.sampleNumber,
        projectId: sample.projectId,
        description: `Enregistrement du prélèvement ${sample.sampleNumber} (${sample.materialCategory}).`
      });
    }
    this.saveToStorage();
  }

  public deleteSample(id: string) {
    const ech = this.state.samples.find(s => s.id === id);
    this.state.samples = this.state.samples.filter(s => s.id !== id);
    if (ech) {
      this.addLog({
        action: 'Suppression d’un échantillon',
        documentType: 'ECHANTILLON',
        documentNumber: ech.sampleNumber,
        description: `Suppression de l’échantillon ${ech.sampleNumber}.`
      });
    }
    this.saveToStorage();
  }

  // --- Lab Tests ---
  public getTests(): LabTest[] {
    return [...this.state.tests];
  }

  public saveTest(test: LabTest) {
    const index = this.state.tests.findIndex(t => t.id === test.id);
    if (index >= 0) {
      this.state.tests[index] = test;
      this.addLog({
        action: 'Modification d’un essai',
        documentType: 'ESSAI',
        documentNumber: test.testNumber,
        projectId: test.projectId,
        description: `Mise à jour de l’essai ${test.testType} (${test.status}).`
      });
    } else {
      this.state.tests.unshift(test);
      this.addLog({
        action: 'Nouvel essai réalisé',
        documentType: 'ESSAI',
        documentNumber: test.testNumber,
        projectId: test.projectId,
        description: `Réalisation de l’essai ${test.testType} selon ${test.standardRef}.`
      });
    }
    this.saveToStorage();
  }

  public deleteTest(id: string) {
    const item = this.state.tests.find(t => t.id === id);
    this.state.tests = this.state.tests.filter(t => t.id !== id);
    if (item) {
      this.addLog({
        action: 'Suppression d’un essai',
        documentType: 'ESSAI',
        documentNumber: item.testNumber,
        description: `Suppression de l’essai ${item.testNumber}.`
      });
    }
    this.saveToStorage();
  }

  // --- Formulations ---
  public getFormulations(): ConcreteFormulation[] {
    return [...this.state.formulations];
  }

  public saveFormulation(formulation: ConcreteFormulation) {
    const toSave: ConcreteFormulation = {
      ...formulation,
      directorName: formulation.directorName || this.state.settings.directorName || 'Ing. B. Mourad (Directeur Technique)',
      technicianName: formulation.technicianName || formulation.preparedBy || this.state.settings.technicianName || 'Technicien Supérieur'
    };
    const index = this.state.formulations.findIndex(f => f.id === toSave.id);
    if (index >= 0) {
      this.state.formulations[index] = toSave;
      this.addLog({
        action: 'Modification d’une formulation',
        documentType: 'FORMULATION',
        documentNumber: toSave.formulationNumber,
        projectId: toSave.projectId,
        description: `Mise à jour de l'étude de formulation béton ${toSave.strengthClass}.`
      });
    } else {
      this.state.formulations.unshift(toSave);
      this.addLog({
        action: 'Création d’une formulation',
        documentType: 'FORMULATION',
        documentNumber: toSave.formulationNumber,
        projectId: toSave.projectId,
        description: `Nouvelle étude de formulation béton ${toSave.strengthClass} (${toSave.concreteType}).`
      });
    }
    this.saveToStorage();
  }

  public duplicateFormulation(id: string): ConcreteFormulation | null {
    const original = this.state.formulations.find(f => f.id === id);
    if (!original) return null;

    const newNumber = this.getNextDocumentNumber('formulation');
    const duplicated: ConcreteFormulation = {
      ...original,
      id: 'form-' + Date.now(),
      formulationNumber: newNumber,
      date: new Date().toISOString().split('T')[0],
      measuredSlumpMm: undefined,
      measuredStrength7jMpa: undefined,
      measuredStrength28jMpa: undefined,
      observations: `Dupliqué depuis ${original.formulationNumber}. ` + (original.observations || ''),
      createdAt: new Date().toISOString().split('T')[0]
    };
    this.saveFormulation(duplicated);
    return duplicated;
  }

  public deleteFormulation(id: string) {
    const item = this.state.formulations.find(f => f.id === id);
    this.state.formulations = this.state.formulations.filter(f => f.id !== id);
    if (item) {
      this.addLog({
        action: 'Suppression d’une formulation',
        documentType: 'FORMULATION',
        documentNumber: item.formulationNumber,
        description: `Suppression de l'étude de formulation ${item.formulationNumber}.`
      });
    }
    this.saveToStorage();
  }

  // --- Compression PVs ---
  public getCompressionPVs(): CompressionPV[] {
    return [...this.state.compressionPVs];
  }

  public saveCompressionPV(pv: CompressionPV) {
    const updatedPV: CompressionPV = {
      ...pv,
      directorName: pv.directorName || this.state.settings.directorName || 'Ing. B. Mourad (Directeur Technique)',
      technicianName: pv.technicianName || pv.operator || this.state.settings.technicianName || 'Technicien Supérieur'
    };
    if (updatedPV.specimens && updatedPV.specimens.length > 0) {
      const strengths = updatedPV.specimens.map(s => s.strengthMpa).filter(s => typeof s === 'number' && s > 0);
      if (strengths.length > 1) {
        updatedPV.standardDeviationMpa = calculateStandardDeviation(strengths);
      }
    }

    const index = this.state.compressionPVs.findIndex(p => p.id === updatedPV.id);
    if (index >= 0) {
      this.state.compressionPVs[index] = updatedPV;
      this.addLog({
        action: 'Modification d’un PV d’écrasement',
        documentType: 'PV_ECRASEMENT',
        documentNumber: updatedPV.pvNumber,
        projectId: updatedPV.projectId,
        description: `Mise à jour du PV d’écrasement béton ${updatedPV.concreteClass} à ${updatedPV.concreteAgeDays} jours.`
      });
    } else {
      this.state.compressionPVs.unshift(updatedPV);
      this.addLog({
        action: 'Création d’un PV d’écrasement',
        documentType: 'PV_ECRASEMENT',
        documentNumber: updatedPV.pvNumber,
        projectId: updatedPV.projectId,
        description: `Enregistrement de l'essai de compression béton ${updatedPV.concreteClass} à ${updatedPV.concreteAgeDays} jours (Moyenne = ${updatedPV.averageStrengthMpa} MPa).`
      });
    }
    this.saveToStorage();
  }

  public isDocumentNumberTaken(
    type: 'project' | 'pv' | 'formulation' | 'report' | 'sample' | 'test',
    num: string,
    excludeId?: string
  ): boolean {
    const cleanNum = (num || '').trim().toLowerCase();
    if (!cleanNum) return false;
    if (type === 'project') return this.state.projects.some(p => p.id !== excludeId && (p.projectNumber || '').trim().toLowerCase() === cleanNum);
    if (type === 'pv') return this.state.compressionPVs.some(p => p.id !== excludeId && (p.pvNumber || '').trim().toLowerCase() === cleanNum);
    if (type === 'formulation') return this.state.formulations.some(f => f.id !== excludeId && (f.formulationNumber || '').trim().toLowerCase() === cleanNum);
    if (type === 'report') return this.state.reports.some(r => r.id !== excludeId && (r.reportNumber || '').trim().toLowerCase() === cleanNum);
    if (type === 'sample') return this.state.samples.some(s => s.id !== excludeId && (s.sampleNumber || '').trim().toLowerCase() === cleanNum);
    if (type === 'test') return this.state.tests.some(t => t.id !== excludeId && (t.testNumber || '').trim().toLowerCase() === cleanNum);
    return false;
  }

  public deleteCompressionPV(id: string) {
    const item = this.state.compressionPVs.find(p => p.id === id);
    this.state.compressionPVs = this.state.compressionPVs.filter(p => p.id !== id);
    if (item) {
      this.addLog({
        action: 'Suppression d’un PV d’écrasement',
        documentType: 'PV_ECRASEMENT',
        documentNumber: item.pvNumber,
        description: `Suppression du PV d’écrasement ${item.pvNumber}.`
      });
    }
    this.saveToStorage();
  }

  // --- Reports ---
  public getReports(): LabReport[] {
    return [...this.state.reports];
  }

  public saveReport(report: LabReport) {
    const toSave: LabReport = {
      ...report,
      directorName: report.directorName || this.state.settings.directorName || 'Ing. B. Mourad (Directeur Technique)',
      technicianName: report.technicianName || report.preparedBy || report.author || this.state.settings.technicianName || 'Technicien Supérieur'
    };
    const index = this.state.reports.findIndex(r => r.id === toSave.id);
    if (index >= 0) {
      this.state.reports[index] = toSave;
      this.addLog({
        action: 'Modification d’un rapport',
        documentType: 'RAPPORT',
        documentNumber: toSave.reportNumber,
        projectId: toSave.projectId,
        description: `Mise à jour du rapport ${toSave.title}.`
      });
    } else {
      this.state.reports.unshift(toSave);
      this.addLog({
        action: 'Génération d’un rapport',
        documentType: 'RAPPORT',
        documentNumber: toSave.reportNumber,
        projectId: toSave.projectId,
        description: `Création du rapport officiel ${toSave.reportNumber} : ${toSave.title}.`
      });
    }
    this.saveToStorage();
  }

  public deleteReport(id: string) {
    const item = this.state.reports.find(r => r.id === id);
    this.state.reports = this.state.reports.filter(r => r.id !== id);
    if (item) {
      this.addLog({
        action: 'Suppression d’un rapport',
        documentType: 'RAPPORT',
        documentNumber: item.reportNumber,
        description: `Suppression du rapport ${item.reportNumber}.`
      });
    }
    this.saveToStorage();
  }

  // --- Document Number Generator Helpers ---
  public getNextProjectNumber(): string {
    return this.getNextDocumentNumber('project');
  }
  public getNextClientNumber(): string {
    return this.getNextDocumentNumber('client');
  }
  public getNextChantierNumber(): string {
    return this.getNextDocumentNumber('chantier');
  }
  public getNextSampleNumber(): string {
    return this.getNextDocumentNumber('sample');
  }
  public getNextTestNumber(): string {
    return this.getNextDocumentNumber('test');
  }
  public getNextFormulationNumber(): string {
    return this.getNextDocumentNumber('formulation');
  }
  public getNextPVNumber(): string {
    return this.getNextDocumentNumber('pvCompression');
  }
  public getNextReportNumber(): string {
    return this.getNextDocumentNumber('report');
  }
  public saveSettings(settings: LabSettings) {
    this.updateSettings(settings);
  }
  public resetToDemoData() {
    this.restoreDemoData();
  }

  // --- Backup Export / Import ---
  public compileFullLocalStorageBackup(): {
    backupJson: string;
    summary: {
      totalRecords: number;
      projects: number;
      compressionPVs: number;
      formulations: number;
      tests: number;
      clients: number;
      chantiers: number;
      date: string;
    };
  } {
    // Collect all raw items in localStorage safely
    const rawStorageDump: Record<string, string> = {};
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        for (let i = 0; i < window.localStorage.length; i++) {
          const key = window.localStorage.key(i);
          if (key) {
            const val = window.localStorage.getItem(key);
            if (val !== null) {
              rawStorageDump[key] = val;
            }
          }
        }
      }
    } catch (storageErr) {
      console.warn('Unable to read all raw localStorage keys:', storageErr);
    }

    const counts = {
      projects: this.state.projects?.length || 0,
      clients: this.state.clients?.length || 0,
      chantiers: this.state.chantiers?.length || 0,
      samples: this.state.samples?.length || 0,
      tests: this.state.tests?.length || 0,
      formulations: this.state.formulations?.length || 0,
      compressionPVs: this.state.compressionPVs?.length || 0,
      reports: this.state.reports?.length || 0,
      activityLogs: this.state.activityLogs?.length || 0
    };

    const totalRecords = Object.values(counts).reduce((a, b) => a + b, 0);

    const fullBackupPayload = {
      _metadata: {
        application: "BM. TAHABORT - Laboratoire d'Essais TP & Génie Civil",
        laboratoryName: this.state.settings?.companyName || 'BM. TAHABORT',
        wilaya: this.state.settings?.wilaya || '16 - Alger',
        exportDate: new Date().toISOString(),
        exportDateFormatted: new Date().toLocaleString('fr-FR'),
        schemaVersion: '2.0.0',
        totalRecords,
        counts
      },
      database: this.state,
      rawLocalStorage: rawStorageDump
    };

    const backupJson = JSON.stringify(fullBackupPayload, null, 2);

    return {
      backupJson,
      summary: {
        totalRecords,
        projects: counts.projects,
        compressionPVs: counts.compressionPVs,
        formulations: counts.formulations,
        tests: counts.tests,
        clients: counts.clients,
        chantiers: counts.chantiers,
        date: new Date().toISOString().split('T')[0]
      }
    };
  }

  public exportDatabaseJson(): string {
    return this.compileFullLocalStorageBackup().backupJson;
  }

  public importDatabaseJson(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);

      // Support both envelope format (_metadata + database) and direct database state
      let targetState: DatabaseSchema | null = null;

      if (parsed && parsed.database && parsed.database.settings && Array.isArray(parsed.database.projects)) {
        targetState = parsed.database;
      } else if (parsed && parsed.settings && Array.isArray(parsed.projects)) {
        targetState = parsed;
      }

      if (targetState) {
        this.state = targetState;
        this.saveToStorage();

        // If rawLocalStorage was bundled, optionally restore auxiliary keys
        if (parsed.rawLocalStorage && typeof parsed.rawLocalStorage === 'object') {
          try {
            Object.entries(parsed.rawLocalStorage).forEach(([k, v]) => {
              if (k !== STORAGE_KEY_PREFIX + 'db' && typeof v === 'string') {
                localStorage.setItem(k, v);
              }
            });
          } catch (auxErr) {
            console.warn('Auxiliary localStorage restore non-fatal error:', auxErr);
          }
        }

        this.addLog({
          action: 'Restauration de base de données',
          documentType: 'SYSTEM',
          documentNumber: 'SYS-RESTORE',
          description: 'Importation et restauration d’une sauvegarde JSON du laboratoire.'
        });
        return true;
      }
      return false;
    } catch (e) {
      console.error('Import database failed', e);
      return false;
    }
  }
}

export const dataService = new DataService();

import {
  Client,
  Chantier,
  Project,
  Sample,
  LabTest,
  ConcreteFormulation,
  CompressionPV,
  LabReport,
  ActivityLog,
  LabSettings,
  UserProfile
} from '../types';

export const INITIAL_SETTINGS: LabSettings = {
  companyName: 'BM. TAHABORT',
  laboratorySubtitle: 'Laboratoire d’Essais de Travaux Publics & Génie Civil',
  address: 'Cité Industrielle, Zone des Activités',
  wilaya: '16 - Alger',
  phone: '+213 (0) 23 45 67 89 / +213 (0) 550 12 34 56',
  email: 'contact@bmtahabort-labo.dz',
  nif: '001916012345678',
  rc: '16/00-1234567B19',
  nis: '0019160123456',
  directorName: 'Ing. B. Mourad (Directeur Technique)',
  technicianName: 'Y. Amrani (Technicien Supérieur Essais Béton)',
  qualityManagerName: 'K. Hadj (Responsable Contrôle Qualité)',
  defaultUnits: {
    load: 'kN',
    strength: 'MPa',
    mass: 'g',
    dimensions: 'mm'
  },
  numberingPrefixes: {
    project: 'PRJ',
    client: 'CLT',
    chantier: 'CHT',
    sample: 'ECH',
    test: 'ESSAI',
    formulation: 'FORM',
    pvCompression: 'PV-ECR',
    report: 'RAP'
  },
  tracking14DayDefaultDays: 14,
  language: 'fr'
};

export const INITIAL_USERS: UserProfile[] = [
  {
    id: 'usr-1',
    name: 'Mourad Benali',
    email: 'm.benali@bmtahabort-labo.dz',
    role: 'ADMIN',
    title: 'Ingénieur en Chef / Directeur de Laboratoire',
    phone: '+213 550 11 22 33',
    active: true
  },
  {
    id: 'usr-2',
    name: 'Karim Hadj',
    email: 'k.hadj@bmtahabort-labo.dz',
    role: 'LAB_MANAGER',
    title: 'Responsable Technique Section Béton & Liants',
    phone: '+213 555 22 33 44',
    active: true
  },
  {
    id: 'usr-3',
    name: 'Yacine Amrani',
    email: 'y.amrani@bmtahabort-labo.dz',
    role: 'TECHNICIAN',
    title: 'Technicien Supérieur Essais Mécaniques',
    phone: '+213 560 33 44 55',
    active: true
  },
  {
    id: 'usr-4',
    name: 'Amina Saidi',
    email: 'a.saidi@bmtahabort-labo.dz',
    role: 'VIEWER',
    title: 'Assistante Contrôle Qualité / Consultation',
    phone: '+213 552 44 55 66',
    active: true
  }
];

// Calculation of realistic dates relative to current date
const now = new Date();
const formatDate = (offsetDays: number) => {
  const d = new Date(now);
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().split('T')[0];
};

export const DEMO_CLIENTS: Client[] = [
  {
    id: 'clt-1',
    code: 'CLT-2026-0001',
    name: 'COSIDER Travaux Publics',
    type: 'ENTREPRISE',
    address: 'Route Nationale N°5, Dar El Beïda',
    wilaya: '16 - Alger',
    commune: 'Dar El Beïda',
    phone: '+213 (0) 23 85 41 00',
    email: 'contact@cosider-tp.dz',
    nif: '000216001234567',
    rc: '16/00-0012485B02',
    contactPerson: 'M. Slimani (Directeur de Projet)',
    notes: 'Entreprise publique majeure de réalisation travaux publics.',
    createdAt: formatDate(-45)
  },
  {
    id: 'clt-2',
    code: 'CLT-2026-0002',
    name: 'DTP Direction des Travaux Publics',
    type: 'MAITRE_OUVRAGE',
    address: 'Boulevard Colonel Amirouche',
    wilaya: '09 - Blida',
    commune: 'Blida',
    phone: '+213 (0) 25 39 12 14',
    email: 'dtp-blida@mtp.gov.dz',
    contactPerson: 'Mme Boumedienne (Chef de Service Suivi)',
    notes: 'Maître d’ouvrage étatique pour les infrastructures routières.',
    createdAt: formatDate(-30)
  },
  {
    id: 'clt-3',
    code: 'CLT-2026-0003',
    name: 'BET Génie & Structures Algérie',
    type: 'BUREAU_ETUDES',
    address: 'Résidence Sahraoui, Val d’Hydra',
    wilaya: '16 - Alger',
    commune: 'Hydra',
    phone: '+213 (0) 21 60 70 80',
    email: 'contact@bet-structures.dz',
    contactPerson: 'Ing. Chérif Kaci',
    notes: 'Bureau d’études partenaire pour dimensionnement et auscultation.',
    createdAt: formatDate(-20)
  }
];

export const DEMO_CHANTIERS: Chantier[] = [
  {
    id: 'cht-1',
    code: 'CHT-2026-0001',
    name: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    wilaya: '09 - Blida',
    commune: 'Chiffa',
    location: 'PK 34+500 vers Médéa',
    entreprise: 'COSIDER Travaux Publics',
    maitreOuvrage: 'DTP Wilaya de Blida',
    maitreOeuvre: 'SAETI / CTC Centre',
    supervisor: 'Ing. Redouane T.',
    description: 'Chantier de construction d’un viaduc en poutres précontraintes (Béton C35/45).',
    observations: 'Prélèvements réguliers pour suivi 7j, 14j et 28j.',
    createdAt: formatDate(-40)
  },
  {
    id: 'cht-2',
    code: 'CHT-2026-0002',
    name: 'Zone Logistique & Plateforme Oued Smar',
    wilaya: '16 - Alger',
    commune: 'Oued Smar',
    location: 'Zone d’Activités Lot 45',
    entreprise: 'SARL Bati-Maghreb',
    maitreOuvrage: 'Groupe Logistique Centre',
    maitreOeuvre: 'BET Génie & Structures Algérie',
    supervisor: 'M. Belkacem',
    description: 'Dallage industriel en béton armé forte charge et radiers.',
    observations: 'Contrôle formulation C25/30 et essais d’équivalent de sable.',
    createdAt: formatDate(-25)
  }
];

export const DEMO_PROJECTS: Project[] = [
  {
    id: 'prj-1',
    projectNumber: 'PRJ-2026-0001',
    name: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    maitreOuvrage: 'DTP Direction des Travaux Publics',
    maitreOeuvre: 'SAETI / CTC Centre',
    entreprise: 'COSIDER Travaux Publics',
    bureauEtudes: 'BET Génie & Structures Algérie',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    wilaya: '09 - Blida',
    commune: 'Chiffa',
    address: 'PK 34+500 Chiffa',
    startDate: formatDate(-10), // Started 10 days ago (14-day alert approaching: 4 days left!)
    status: 'EN_COURS',
    description: 'Contrôle extérieur des bétons hydrauliques (C35/45) des piles et chevêtres.',
    observations: 'Délai d’échéance contractuel de 14 jours pour validation des lots béton.',
    tracking14Days: {
      enabled: true,
      startDate: formatDate(-10),
      targetDurationDays: 14,
      notes: 'Suivi de la maturation 14 jours des éprouvettes béton témoin lot #B04'
    },
    createdAt: formatDate(-40)
  },
  {
    id: 'prj-2',
    projectNumber: 'PRJ-2026-0002',
    name: 'Contrôle Plateforme et Dallage Industriel Oued Smar',
    clientId: 'clt-3',
    clientName: 'BET Génie & Structures Algérie',
    maitreOuvrage: 'Groupe Logistique Centre',
    entreprise: 'SARL Bati-Maghreb',
    bureauEtudes: 'BET Génie & Structures Algérie',
    chantierId: 'cht-2',
    chantierName: 'Zone Logistique & Plateforme Oued Smar',
    wilaya: '16 - Alger',
    commune: 'Oued Smar',
    address: 'Zone Industrielle Oued Smar',
    startDate: formatDate(-14), // Reached 14 days today!
    status: 'EN_COURS',
    description: 'Étude de formulation béton C25/30 et contrôle de portance du sol support (CBR, Proctor).',
    observations: 'Échéance des 14 jours de contrôle atteinte.',
    tracking14Days: {
      enabled: true,
      startDate: formatDate(-14),
      targetDurationDays: 14,
      notes: 'Période de stabilisation 14 jours du sol compacté avant dallage'
    },
    createdAt: formatDate(-25)
  }
];

export const DEMO_SAMPLES: Sample[] = [
  {
    id: 'ech-1',
    sampleNumber: 'ECH-2026-0001',
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    materialCategory: 'BETON',
    customMaterialName: 'Béton prêt à l’emploi C35/45',
    samplingDate: formatDate(-10),
    receptionDate: formatDate(-9),
    samplingLocation: 'Goulotte toupie BPE N°04 sur pile P2',
    samplerName: 'Yacine Amrani (Technicien)',
    quantity: '6 éprouvettes cylindriques 16x32 cm',
    conditionOnReception: 'CONFORME',
    observations: 'Confection selon NF EN 12390-2, conservation en bac d’eau à 20°C ± 2°C.',
    createdAt: formatDate(-9)
  },
  {
    id: 'ech-2',
    sampleNumber: 'ECH-2026-0002',
    projectId: 'prj-2',
    projectName: 'Contrôle Plateforme et Dallage Industriel Oued Smar',
    chantierId: 'cht-2',
    chantierName: 'Zone Logistique & Plateforme Oued Smar',
    clientId: 'clt-3',
    clientName: 'BET Génie & Structures Algérie',
    materialCategory: 'SABLE',
    customMaterialName: 'Sable d’oued 0/4 lavé',
    samplingDate: formatDate(-12),
    receptionDate: formatDate(-12),
    samplingLocation: 'Stock central carrière Chlef',
    samplerName: 'Mourad Benali',
    quantity: '3 sacs de 25 kg',
    conditionOnReception: 'CONFORME',
    observations: 'Pour analyse granulométrique et équivalent de sable.',
    createdAt: formatDate(-12)
  },
  {
    id: 'ech-3',
    sampleNumber: 'ECH-2026-0003',
    projectId: 'prj-2',
    projectName: 'Contrôle Plateforme et Dallage Industriel Oued Smar',
    chantierId: 'cht-2',
    chantierName: 'Zone Logistique & Plateforme Oued Smar',
    clientId: 'clt-3',
    clientName: 'BET Génie & Structures Algérie',
    materialCategory: 'SOL',
    customMaterialName: 'Grave non traitée GNT 0/31.5',
    samplingDate: formatDate(-15),
    receptionDate: formatDate(-15),
    samplingLocation: 'Plateforme secteur Nord',
    samplerName: 'Karim Hadj',
    quantity: '50 kg en fûts hermétiques',
    conditionOnReception: 'CONFORME',
    observations: 'Pour essai Proctor modifié et CBR.',
    createdAt: formatDate(-15)
  }
];

export const DEMO_TESTS: LabTest[] = [
  {
    id: 'tst-1',
    testNumber: 'ESSAI-2026-0001',
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    sampleId: 'ech-1',
    sampleNumber: 'ECH-2026-0001',
    materialCategory: 'BETON',
    testType: "Affaissement au cône d'Abrams (Slump Test)",
    standardRef: 'NF EN 12350-2',
    testDate: formatDate(-10),
    operator: 'Yacine Amrani',
    results: {
      slumpValue: 140,
      targetValue: 130,
      slumpClass: 'S3 (Très plastique)'
    },
    units: {
      slumpValue: 'mm'
    },
    observations: 'Béton homogène, absence de ressuage ou de ségrégation visible.',
    conclusion: 'Affaissement mesuré conforme aux exigences de la classe de consistance S3 prescrite.',
    status: 'VALIDE',
    createdAt: formatDate(-10)
  },
  {
    id: 'tst-2',
    testNumber: 'ESSAI-2026-0002',
    projectId: 'prj-2',
    projectName: 'Contrôle Plateforme et Dallage Industriel Oued Smar',
    chantierId: 'cht-2',
    chantierName: 'Zone Logistique & Plateforme Oued Smar',
    sampleId: 'ech-2',
    sampleNumber: 'ECH-2026-0002',
    materialCategory: 'SABLE',
    testType: 'Équivalent de sable (ES / ES10)',
    standardRef: 'NF EN 933-8',
    testDate: formatDate(-11),
    operator: 'Karim Hadj',
    results: {
      h1_pist: 86,
      h2_vis: 112,
      es_piston: 76.8,
      es_visuel: 81.2
    },
    units: {
      es_piston: '%'
    },
    observations: 'Sable d’oued propre avec très faible pourcentage de fines argileuses.',
    conclusion: 'Sable convenable pour béton hydraulique armé (ES > 70%).',
    status: 'VALIDE',
    createdAt: formatDate(-11)
  }
];

export const DEMO_FORMULATIONS: ConcreteFormulation[] = [
  {
    id: 'form-1',
    formulationNumber: 'FORM-2026-0001',
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    date: formatDate(-30),
    concreteType: 'Béton armé pour éléments précontraints (Piles et Chevêtres)',
    strengthClass: 'C35/45',
    consistency: 'S3',
    dMaxMm: 20,
    cementType: 'CPA-CEM I 42.5 (GICA)',
    cementDosageKg: 400,
    waterLiter: 175,
    wcRatio: 0.44, // 175 / 400
    sandKg: 680,
    gravel1Kg: 450, // Gravillon 3/8
    gravel2Kg: 720, // Gravillon 8/20
    adjuvantType: 'Superplastifiant Haut Réducteur d’Eau (Glenium / Sika ViscoCrete)',
    adjuvantDosageKg: 4.2,
    theoreticalDensityKgM3: 2429,
    theoreticalVolumeM3: 1.0,
    targetSlumpMm: 140,
    measuredSlumpMm: 145,
    targetStrength7jMpa: 28.0,
    measuredStrength7jMpa: 30.5,
    targetStrength28jMpa: 45.0,
    measuredStrength28jMpa: 48.2,
    observations: 'Formulation optimisée selon la méthode Dreux-Gorisse avec ajustement granulaire.',
    preparedBy: 'Ing. Mourad Benali',
    approvedBy: 'Karim Hadj',
    createdAt: formatDate(-30)
  }
];

export const DEMO_PVS: CompressionPV[] = [
  // 1. PV INDÉPENDANT 7 JOURS
  {
    id: 'pv-7j',
    pvNumber: 'PV-ECR-2026-0001',
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    sampleId: 'ech-1',
    sampleNumber: 'ECH-2026-0001',
    samplingDate: formatDate(-7),
    receptionDate: formatDate(-6),
    confectionDate: formatDate(-7),
    crushingDate: formatDate(0),
    concreteAgeDays: 7, // 7-day independent test
    concreteClass: 'C35/45',
    specimenType: 'CYLINDRIQUE_16_32',
    machineUsed: 'Presse Hydraulique Automatique 3000 kN (NF EN 12390-4)',
    operator: 'Y. Amrani (Technicien)',
    technicianName: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    directorName: 'Ing. B. Mourad (Directeur Technique)',
    specimens: [
      {
        id: 'sp-7j-1',
        index: 1,
        ageDays: 7,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12840,
        maxLoadKn: 546.0,
        areaMm2: 20106.19,
        strengthMpa: 27.16,
        failureMode: 'Rupture normale (cône double)',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      },
      {
        id: 'sp-7j-2',
        index: 2,
        ageDays: 7,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12880,
        maxLoadKn: 560.5,
        areaMm2: 20106.19,
        strengthMpa: 27.88,
        failureMode: 'Rupture normale (cône double)',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      },
      {
        id: 'sp-7j-3',
        index: 3,
        ageDays: 7,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12820,
        maxLoadKn: 552.0,
        areaMm2: 20106.19,
        strengthMpa: 27.45,
        failureMode: 'Rupture normale',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      }
    ],
    averageStrengthMpa: 27.50,
    targetStrengthMpa: 24.5,
    complianceObservation: 'Résistance moyenne à 7 jours (27.50 MPa) conforme aux prévisions de durcissement (>= 70% de fck).',
    observations: 'Conservation en eau saturée à 20°C ± 2°C (NF EN 12390-2).',
    conclusion: 'Résultats satisfaisants pour l’échéance contractuelle de 7 jours.',
    status: 'VALIDE',
    validatedBy: 'Ing. B. Mourad (Directeur Technique)',
    createdAt: formatDate(0)
  },

  // 2. PV INDÉPENDANT 14 JOURS
  {
    id: 'pv-14j',
    pvNumber: 'PV-ECR-2026-0002',
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    sampleId: 'ech-1',
    sampleNumber: 'ECH-2026-0001',
    samplingDate: formatDate(-14),
    receptionDate: formatDate(-13),
    confectionDate: formatDate(-14),
    crushingDate: formatDate(0),
    concreteAgeDays: 14, // 14-day independent test
    concreteClass: 'C35/45',
    specimenType: 'CYLINDRIQUE_16_32',
    machineUsed: 'Presse Hydraulique Automatique 3000 kN (NF EN 12390-4)',
    operator: 'Y. Amrani (Technicien)',
    technicianName: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    directorName: 'Ing. B. Mourad (Directeur Technique)',
    specimens: [
      {
        id: 'sp-14j-1',
        index: 1,
        ageDays: 14,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12850,
        maxLoadKn: 692.5,
        areaMm2: 20106.19,
        strengthMpa: 34.44,
        failureMode: 'Rupture normale (cône double)',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      },
      {
        id: 'sp-14j-2',
        index: 2,
        ageDays: 14,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12900,
        maxLoadKn: 710.0,
        areaMm2: 20106.19,
        strengthMpa: 35.31,
        failureMode: 'Rupture normale (cône double)',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      },
      {
        id: 'sp-14j-3',
        index: 3,
        ageDays: 14,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12820,
        maxLoadKn: 704.2,
        areaMm2: 20106.19,
        strengthMpa: 35.02,
        failureMode: 'Rupture semi-pyramidale',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      }
    ],
    averageStrengthMpa: 34.92,
    targetStrengthMpa: 32.0,
    complianceObservation: 'Résistance moyenne à 14 jours (34.92 MPa) supérieure au seuil indicatif requis (32.00 MPa).',
    observations: 'Conservation des éprouvettes en chambre humide à 20°C ± 2°C et HR > 95%.',
    conclusion: 'Les résultats d’écrasement à 14 jours démontrent une cinétique de durcissement normale du béton.',
    status: 'VALIDE',
    validatedBy: 'Ing. B. Mourad (Directeur Technique)',
    createdAt: formatDate(0)
  },

  // 3. PV INDÉPENDANT 28 JOURS
  {
    id: 'pv-28j',
    pvNumber: 'PV-ECR-2026-0003',
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    sampleId: 'ech-1',
    sampleNumber: 'ECH-2026-0001',
    samplingDate: formatDate(-28),
    receptionDate: formatDate(-27),
    confectionDate: formatDate(-28),
    crushingDate: formatDate(0),
    concreteAgeDays: 28, // 28-day independent test
    concreteClass: 'C35/45',
    specimenType: 'CYLINDRIQUE_16_32',
    machineUsed: 'Presse Hydraulique Automatique 3000 kN (NF EN 12390-4)',
    operator: 'Y. Amrani (Technicien)',
    technicianName: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    directorName: 'Ing. B. Mourad (Directeur Technique)',
    specimens: [
      {
        id: 'sp-28j-1',
        index: 1,
        ageDays: 28,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12890,
        maxLoadKn: 932.0,
        areaMm2: 20106.19,
        strengthMpa: 46.35,
        failureMode: 'Rupture normale (cône double satisfaisant)',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      },
      {
        id: 'sp-28j-2',
        index: 2,
        ageDays: 28,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12940,
        maxLoadKn: 955.0,
        areaMm2: 20106.19,
        strengthMpa: 47.50,
        failureMode: 'Rupture normale (cône double satisfaisant)',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      },
      {
        id: 'sp-28j-3',
        index: 3,
        ageDays: 28,
        dimensionsDescription: 'Cylindre Ø160mm x H320mm',
        massG: 12870,
        maxLoadKn: 941.5,
        areaMm2: 20106.19,
        strengthMpa: 46.83,
        failureMode: 'Rupture normale (cône double satisfaisant)',
        observations: 'Surfaçage au soufre conforme NF P 18-416'
      }
    ],
    averageStrengthMpa: 46.89,
    targetStrengthMpa: 45.0,
    complianceObservation: 'Résistance moyenne à 28 jours (46.89 MPa) supérieure à la résistance caractéristique fck (45.00 MPa).',
    observations: 'Conservation des éprouvettes en chambre humide à 20°C ± 2°C selon NF EN 12390-2.',
    conclusion: 'Béton déclaré conforme à la classe de résistance C35/45 selon la norme NF EN 206+A2/CN.',
    status: 'VALIDE',
    validatedBy: 'Ing. B. Mourad (Directeur Technique)',
    createdAt: formatDate(0)
  }
];

export const DEMO_REPORTS: LabReport[] = [
  {
    id: 'rap-1',
    reportNumber: 'RAP-2026-0001',
    title: 'Procès-Verbal d’Essai d’Écrasement à 7 Jours - Viaduc V02 Chiffa',
    type: 'PV_ECRASEMENT',
    entityId: 'pv-7j',
    concreteAgeDays: 7,
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    date: formatDate(0),
    author: 'Yacine Amrani',
    preparedBy: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    approvedBy: 'Ing. B. Mourad (Directeur Technique)',
    directorName: 'Ing. B. Mourad (Directeur Technique)',
    technicianName: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    summary: 'Rapport officiel d’écrasement de 3 éprouvettes cylindriques 16x32 cm à l’âge de 7 jours.',
    conclusion: 'Résistance moyenne obtenue : 27.50 MPa. Évolution cinétique conforme.',
    status: 'VALIDE',
    createdAt: formatDate(0)
  },
  {
    id: 'rap-2',
    reportNumber: 'RAP-2026-0002',
    title: 'Procès-Verbal d’Essai d’Écrasement à 14 Jours - Viaduc V02 Chiffa',
    type: 'PV_ECRASEMENT',
    entityId: 'pv-14j',
    concreteAgeDays: 14,
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    date: formatDate(0),
    author: 'Yacine Amrani',
    preparedBy: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    approvedBy: 'Ing. B. Mourad (Directeur Technique)',
    directorName: 'Ing. B. Mourad (Directeur Technique)',
    technicianName: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    summary: 'Rapport officiel d’écrasement de 3 éprouvettes cylindriques 16x32 cm à l’âge de 14 jours.',
    conclusion: 'Résistance moyenne obtenue : 34.92 MPa. Béton de classe C35/45 conforme à la cinétique d’évolution.',
    status: 'VALIDE',
    createdAt: formatDate(0)
  },
  {
    id: 'rap-3',
    reportNumber: 'RAP-2026-0003',
    title: 'Procès-Verbal d’Essai d’Écrasement Réglementaire à 28 Jours - Viaduc V02 Chiffa',
    type: 'PV_ECRASEMENT',
    entityId: 'pv-28j',
    concreteAgeDays: 28,
    projectId: 'prj-1',
    projectName: 'Contrôle Qualité Ouvrages d’Art - Viaduc V02 RN 01',
    chantierId: 'cht-1',
    chantierName: 'Viaduc V02 - Dédoublement RN 01 Chiffa',
    clientId: 'clt-1',
    clientName: 'COSIDER Travaux Publics',
    date: formatDate(0),
    author: 'Yacine Amrani',
    preparedBy: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    approvedBy: 'Ing. B. Mourad (Directeur Technique)',
    directorName: 'Ing. B. Mourad (Directeur Technique)',
    technicianName: 'Y. Amrani (Technicien Supérieur Essais Béton)',
    summary: 'Rapport officiel d’écrasement de 3 éprouvettes cylindriques 16x32 cm à l’âge réglementaire de 28 jours.',
    conclusion: 'Résistance moyenne obtenue : 46.89 MPa (fck visée : 45.00 MPa). Béton conforme C35/45.',
    status: 'VALIDE',
    createdAt: formatDate(0)
  }
];

export const DEMO_ACTIVITY_LOGS: ActivityLog[] = [
  {
    id: 'act-1',
    date: formatDate(0) + ' 11:30',
    user: 'Yacine Amrani',
    userRole: 'Technicien',
    action: 'Création d’un PV d’écrasement',
    documentType: 'PV_ECRASEMENT',
    documentNumber: 'PV-ECR-2026-0001',
    projectId: 'prj-1',
    description: 'Enregistrement de l’essai d’écrasement à 14 jours sur 3 éprouvettes cylindriques.'
  },
  {
    id: 'act-2',
    date: formatDate(0) + ' 11:45',
    user: 'Mourad Benali',
    userRole: 'Directeur',
    action: 'Validation d’un rapport',
    documentType: 'RAPPORT',
    documentNumber: 'RAP-2026-0001',
    projectId: 'prj-1',
    description: 'Validation et approbation du PV d’écrasement N° PV-ECR-2026-0001.'
  },
  {
    id: 'act-3',
    date: formatDate(-10) + ' 14:15',
    user: 'Yacine Amrani',
    userRole: 'Technicien',
    action: 'Nouvel essai réalisé',
    documentType: 'ESSAI',
    documentNumber: 'ESSAI-2026-0001',
    projectId: 'prj-1',
    description: 'Essai d’affaissement au cône d’Abrams sur béton frais.'
  },
  {
    id: 'act-4',
    date: formatDate(-30) + ' 09:00',
    user: 'Mourad Benali',
    userRole: 'Directeur',
    action: 'Création d’une formulation',
    documentType: 'FORMULATION',
    documentNumber: 'FORM-2026-0001',
    projectId: 'prj-1',
    description: 'Étude de formulation béton C35/45 selon Dreux-Gorisse.'
  }
];

export interface WilayaInfo {
  code: string;
  name: string;
}

export const ALGERIAN_WILAYAS: WilayaInfo[] = [
  { code: '01', name: 'Adrar' },
  { code: '02', name: 'Chlef' },
  { code: '03', name: 'Laghouat' },
  { code: '04', name: 'Oum El Bouaghi' },
  { code: '05', name: 'Batna' },
  { code: '06', name: 'Béjaïa' },
  { code: '07', name: 'Biskra' },
  { code: '08', name: 'Béchar' },
  { code: '09', name: 'Blida' },
  { code: '10', name: 'Bouira' },
  { code: '11', name: 'Tamanrasset' },
  { code: '12', name: 'Tébessa' },
  { code: '13', name: 'Tlemcen' },
  { code: '14', name: 'Tiaret' },
  { code: '15', name: 'Tizi Ouzou' },
  { code: '16', name: 'Alger' },
  { code: '17', name: 'Djelfa' },
  { code: '18', name: 'Jijel' },
  { code: '19', name: 'Sétif' },
  { code: '20', name: 'Saïda' },
  { code: '21', name: 'Skikda' },
  { code: '22', name: 'Sidi Bel Abbès' },
  { code: '23', name: 'Annaba' },
  { code: '24', name: 'Guelma' },
  { code: '25', name: 'Constantine' },
  { code: '26', name: 'Médéa' },
  { code: '27', name: 'Mostaganem' },
  { code: '28', name: "M'Sila" },
  { code: '29', name: 'Mascara' },
  { code: '30', name: 'Ouargla' },
  { code: '31', name: 'Oran' },
  { code: '32', name: 'El Bayadh' },
  { code: '33', name: 'Illizi' },
  { code: '34', name: 'Bordj Bou Arreridj' },
  { code: '35', name: 'Boumerdès' },
  { code: '36', name: 'El Tarf' },
  { code: '37', name: 'Tindouf' },
  { code: '38', name: 'Tissemsilt' },
  { code: '39', name: 'El Oued' },
  { code: '40', name: 'Khenchela' },
  { code: '41', name: 'Souk Ahras' },
  { code: '42', name: 'Tipaza' },
  { code: '43', name: 'Mila' },
  { code: '44', name: 'Aïn Defla' },
  { code: '45', name: 'Naâma' },
  { code: '46', name: 'Aïn Témouchent' },
  { code: '47', name: 'Ghardaïa' },
  { code: '48', name: 'Relizane' },
  { code: '49', name: 'Timimoun' },
  { code: '50', name: 'Bordj Badji Mokhtar' },
  { code: '51', name: 'Ouled Djellal' },
  { code: '52', name: 'Béni Abbès' },
  { code: '53', name: 'In Salah' },
  { code: '54', name: 'In Guezzam' },
  { code: '55', name: 'Touggourt' },
  { code: '56', name: 'Djanet' },
  { code: '57', name: "El M'Ghair" },
  { code: '58', name: 'El Meniaa' }
];

export const ALGERIAN_WILAYA_NAMES: string[] = ALGERIAN_WILAYAS.map(w => `${w.code} - ${w.name}`);

export const CONCRETE_STRENGTH_CLASSES = [
  { code: 'C12/15', fckCyl: 12, fckCube: 15, desc: 'Béton de remplissage / propreté' },
  { code: 'C16/20', fckCyl: 16, fckCube: 20, desc: 'Béton non armé / semelles simples' },
  { code: 'C20/25', fckCyl: 20, fckCube: 25, desc: 'Béton armé standard (dalles, dallages)' },
  { code: 'C25/30', fckCyl: 25, fckCube: 30, desc: 'Béton armé usuel (poteaux, poutres, voiles)' },
  { code: 'C30/37', fckCyl: 30, fckCube: 37, desc: 'Génie civil / Ouvrages d’art / Travaux exigeants' },
  { code: 'C35/45', fckCyl: 35, fckCube: 45, desc: 'Béton haute résistance / Précontraint' },
  { code: 'C40/50', fckCyl: 40, fckCube: 50, desc: 'BHP Ouvrages maritimes / Ponts' }
];

export const SLUMP_CONSISTENCY_CLASSES = [
  { code: 'S1', range: '10 à 40 mm', label: 'Ferme (béton extrudé, chaussées)' },
  { code: 'S2', range: '50 à 90 mm', label: 'Plastique (fondations, radiers, dallages)' },
  { code: 'S3', range: '100 à 150 mm', label: 'Très plastique (ouvrages courants, banchés)' },
  { code: 'S4', range: '160 à 210 mm', label: 'Fluide (ferraillage dense)' },
  { code: 'S5', range: '≥ 220 mm', label: 'Très fluide / Autoplaçant' }
];

export const CEMENT_TYPES_ALGERIA = [
  'CPJ-CEM II/A 42.5',
  'CPJ-CEM II/B 42.5',
  'CPA-CEM I 42.5',
  'CPA-CEM I 52.5',
  'CRS (Ciment Résistant aux Sulfates)',
  'CEM II/A-L 42.5 N (GICA / Lafarge Algérie)',
  'Autre type'
];

export const COMMON_LAB_TEST_TYPES = [
  {
    category: 'BETON',
    name: "Affaissement au cône d'Abrams (Slump Test)",
    standard: 'NF EN 12350-2 / NA 5071',
    defaultUnit: 'mm'
  },
  {
    category: 'BETON',
    name: 'Essai de compression sur éprouvettes durcies',
    standard: 'NF EN 12390-3 / NA 437',
    defaultUnit: 'MPa'
  },
  {
    category: 'BETON',
    name: 'Masse volumique du béton durci',
    standard: 'NF EN 12390-7',
    defaultUnit: 'kg/m³'
  },
  {
    category: 'BETON',
    name: 'Essai de traction par fendage (Brésilien)',
    standard: 'NF EN 12390-6',
    defaultUnit: 'MPa'
  },
  {
    category: 'GRANULATS',
    name: 'Analyse granulométrique par tamisage',
    standard: 'NF EN 933-1 / NA 255',
    defaultUnit: '% passant'
  },
  {
    category: 'GRANULATS',
    name: 'Équivalent de sable (ES / ES10)',
    standard: 'NF EN 933-8 / NA 452',
    defaultUnit: '%'
  },
  {
    category: 'GRANULATS',
    name: 'Essai Los Angeles (résistance aux chocs)',
    standard: 'NF EN 1097-2 / NA 261',
    defaultUnit: '%'
  },
  {
    category: 'GRANULATS',
    name: 'Micro-Deval (usure par frottement)',
    standard: 'NF EN 1097-1 / NA 260',
    defaultUnit: '%'
  },
  {
    category: 'SOL',
    name: 'Limites d’Atterberg (WL, WP, IP)',
    standard: 'NF P 94-051 / NA 16226',
    defaultUnit: '%'
  },
  {
    category: 'SOL',
    name: 'Essai Proctor Normal / Modifié (OPM)',
    standard: 'NF P 94-093 / NA 16228',
    defaultUnit: 't/m³ et % w'
  },
  {
    category: 'SOL',
    name: 'Indice Portant CBR immédiat / après immersion',
    standard: 'NF P 94-078 / NA 16229',
    defaultUnit: '%'
  },
  {
    category: 'SOL',
    name: 'Teneur en eau naturelle par étuvage',
    standard: 'NF P 94-050',
    defaultUnit: '%'
  },
  {
    category: 'MATERIAUX_ROUTIERS',
    name: 'Essai Marshall sur enrobés',
    standard: 'NF EN 12697-34',
    defaultUnit: 'kN / mm'
  },
  {
    category: 'CIMENT',
    name: 'Temps de prise et consistance (Aiguille de Vicat)',
    standard: 'NF EN 196-3',
    defaultUnit: 'min / mm'
  },
  {
    category: 'ACIER',
    name: 'Essai de traction sur ronds à béton (Re, Rm, A%)',
    standard: 'NF EN ISO 6892-1',
    defaultUnit: 'MPa / %'
  }
];

export const FAILURE_MODES_LIST = [
  'Rupture normale (cône double / sablier)',
  'Rupture semi-pyramidale satisfaisante',
  'Rupture par cisaillement oblique',
  'Rupture colonnaire (clivage vertical)',
  'Rupture d’angle / arête',
  'Rupture atypique / dissymétrique'
];

export const CIVIL_ENGINEERING_TESTS_STANDARDS = COMMON_LAB_TEST_TYPES;

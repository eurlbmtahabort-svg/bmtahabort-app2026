package dz.bmtahabort.labo;

import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Register the Android Print Javascript Interface on the Bridge WebView
        if (this.bridge != null && this.bridge.getWebView() != null) {
            WebView webView = this.bridge.getWebView();
            webView.addJavascriptInterface(new AndroidPrintInterface(this, webView), "AndroidPrint");
        }
    }

    public static class AndroidPrintInterface {
        private final Context context;
        private final WebView webView;

        public AndroidPrintInterface(Context context, WebView webView) {
            this.context = context;
            this.webView = webView;
        }

        @JavascriptInterface
        public void print() {
            printDocument("Document_BM_TAHABORT");
        }

        @JavascriptInterface
        public void printDocument(final String documentTitle) {
            if (context instanceof MainActivity) {
                ((MainActivity) context).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            PrintManager printManager = (PrintManager) context.getSystemService(Context.PRINT_SERVICE);
                            if (printManager != null && webView != null) {
                                String jobName = (documentTitle != null && !documentTitle.trim().isEmpty())
                                        ? documentTitle.trim()
                                        : "Document_BM_TAHABORT";
                                PrintDocumentAdapter printAdapter = webView.createPrintDocumentAdapter(jobName);
                                printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        }
    }
}

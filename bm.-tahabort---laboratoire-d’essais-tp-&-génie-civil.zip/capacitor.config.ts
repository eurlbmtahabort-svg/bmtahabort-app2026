import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'dz.bmtahabort.labo',
  appName: 'BM. TAHABORT',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    Share: {},
    Filesystem: {}
  }
};

export default config;
